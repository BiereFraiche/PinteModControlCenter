﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ConfigPath,
    [Parameter(Mandatory = $true)][string]$PackageDir
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-PropValue {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) { return $Default }
    return $property.Value
}

function Get-SafeServerId {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return 'server' }
    $safe = [regex]::Replace($Value, '[^A-Za-z0-9_.-]', '_')
    if ($safe.Length -gt 48) { $safe = $safe.Substring(0,48) }
    return $safe
}

$configPathFull = [IO.Path]::GetFullPath($ConfigPath.Trim('"'))
$packageFull = [IO.Path]::GetFullPath($PackageDir.Trim('"'))
if (-not (Test-Path -LiteralPath $configPathFull -PathType Leaf)) { throw 'Configuration locale introuvable.' }

$ranksSource = Join-Path $packageFull 'ezz_admin_ranks.gsc'
$eeSource = Join-Path $packageFull 'ezz_admin_ee_records.gsc'
if (-not (Test-Path -LiteralPath $ranksSource -PathType Leaf)) { throw 'ezz_admin_ranks.gsc source introuvable.' }
if (-not (Test-Path -LiteralPath $eeSource -PathType Leaf)) { throw 'ezz_admin_ee_records.gsc source introuvable.' }

$config = ([IO.File]::ReadAllText($configPathFull) | ConvertFrom-Json)
$servers = @()
foreach ($server in @($config.servers)) {
    $enabled = [bool](Get-PropValue $server 'enabled' $false)
    $mode = [string](Get-PropValue $server 'mode' '')
    $root = [string](Get-PropValue $server 'server_root' '')
    if (-not $enabled -or $mode -ne 'local' -or [string]::IsNullOrWhiteSpace($root)) { continue }
    $servers += [PSCustomObject]@{ id=(Get-SafeServerId ([string](Get-PropValue $server 'id' 'server'))); root=$root }
}
if ($servers.Count -lt 1) { throw 'Aucun serveur local active dans la configuration.' }

$stamp = [DateTime]::Now.ToString('yyyyMMdd_HHmmss')
$expectedRanks = (Get-FileHash -LiteralPath $ranksSource -Algorithm SHA256).Hash
$expectedEe = (Get-FileHash -LiteralPath $eeSource -Algorithm SHA256).Hash
$failed = 0

foreach ($server in $servers) {
    try {
        $custom = Join-Path $server.root 'boiii\custom_scripts'
        if (-not (Test-Path -LiteralPath $custom -PathType Container)) { throw 'custom_scripts introuvable' }
        $backup = Join-Path $custom ('_recordhub_backup_' + $stamp)
        New-Item -ItemType Directory -Path $backup -Force | Out-Null

        $ranksTarget = Join-Path $custom 'ezz_admin_ranks.gsc'
        $eeTarget = Join-Path $custom 'ezz_admin_ee_records.gsc'
        if (Test-Path -LiteralPath $ranksTarget -PathType Leaf) { Copy-Item -LiteralPath $ranksTarget -Destination (Join-Path $backup 'ezz_admin_ranks.gsc') -Force }
        if (Test-Path -LiteralPath $eeTarget -PathType Leaf) { Copy-Item -LiteralPath $eeTarget -Destination (Join-Path $backup 'ezz_admin_ee_records.gsc') -Force }

        Copy-Item -LiteralPath $ranksSource -Destination $ranksTarget -Force
        Copy-Item -LiteralPath $eeSource -Destination $eeTarget -Force

        $actualRanks = (Get-FileHash -LiteralPath $ranksTarget -Algorithm SHA256).Hash
        $actualEe = (Get-FileHash -LiteralPath $eeTarget -Algorithm SHA256).Hash
        if ($actualRanks -ne $expectedRanks -or $actualEe -ne $expectedEe) { throw 'verification SHA256 echouee' }

        Write-Host ('[OK] ' + $server.id + ' | GSC installes + backup cree') -ForegroundColor Green
    }
    catch {
        $failed++
        Write-Host ('[ERREUR] ' + $server.id + ' | ' + $_.Exception.Message) -ForegroundColor Red
    }
}

if ($failed -gt 0) { exit 1 }
Write-Host ('[OK] Deploiement termine sur ' + $servers.Count + ' serveur(s).') -ForegroundColor Green
exit 0
