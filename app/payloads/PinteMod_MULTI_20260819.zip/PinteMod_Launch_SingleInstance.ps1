param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Server1','Server2','Server3')]
    [string]$InstanceName
)

$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = "PinteMod - Launch $InstanceName"

function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-SourceConfigPath {
    $candidates = @(
        (Join-Path $PSScriptRoot 'START_3_ALL_IN_ONE.local.json'),
        (Join-Path $PSScriptRoot 'PinteMod_MultiServer.local.json')
    )

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return [System.IO.Path]::GetFullPath($candidate)
        }
    }

    throw 'Configuration de lancement MultiServer introuvable. START_3_ALL_IN_ONE.local.json est attendu.'
}

function Test-PlainSecretInObject {
    param($Object)
    $json = $Object | ConvertTo-Json -Depth 20 -Compress
    return [bool]($json -match '(?i)"(?:rcon_password|password|secret_value|api_key|token)"\s*:\s*"[^\"]+"')
}

function New-SingleInstanceConfig {
    param(
        [string]$SourcePath,
        [string]$WantedInstance,
        [string]$OutputPath
    )

    $config = Get-Content -LiteralPath $SourcePath -Raw -ErrorAction Stop |
        ConvertFrom-Json -ErrorAction Stop

    if ($null -eq $config.schema_version -or [int]$config.schema_version -ne 4) {
        throw 'Configuration MultiServer invalide : schema_version=4 attendu.'
    }

    $selected = @($config.servers | Where-Object {
        [string]::Equals(
            ([string]$_.id).Trim(),
            $WantedInstance,
            [System.StringComparison]::OrdinalIgnoreCase
        )
    }) | Select-Object -First 1

    if (-not $selected) {
        throw "Instance '$WantedInstance' absente de la configuration de lancement des 3 serveurs."
    }

    if (([string]$selected.mode).Trim().ToLowerInvariant() -ne 'local') {
        throw "L'instance '$WantedInstance' n'est pas en mode local."
    }

    $single = ($config | ConvertTo-Json -Depth 20) | ConvertFrom-Json
    $entry = @($single.servers | Where-Object {
        [string]::Equals(
            ([string]$_.id).Trim(),
            $WantedInstance,
            [System.StringComparison]::OrdinalIgnoreCase
        )
    }) | Select-Object -First 1

    # Un lancement individuel doit fournir exactement les mêmes services que
    # le lancement complet, mais uniquement pour l'instance demandée.
    $entry.enabled = $true
    $entry.launch_server = $true
    $entry.supervisor = $true
    $entry.ban_service = $true
    $entry.geoip = $true
    $entry.live_console = $false
    $entry.rcon = $false
    $single.servers = @($entry)

    if (Test-PlainSecretInObject -Object $single) {
        throw 'Refus de creer la configuration temporaire : un secret en clair semble present.'
    }

    Ensure-Directory (Split-Path -Parent $OutputPath)
    [System.IO.File]::WriteAllText(
        $OutputPath,
        ($single | ConvertTo-Json -Depth 20),
        [System.Text.UTF8Encoding]::new($false)
    )

    return $OutputPath
}

$mutex = $null
$mutexOwned = $false
try {
    $safeInstance = $InstanceName -replace '[^A-Za-z0-9_.-]', '_'
    $mutex = New-Object System.Threading.Mutex($false, "Global\PinteMod_MultiSingleLauncher_$safeInstance")
    try { $mutexOwned = $mutex.WaitOne(0, $false) }
    catch [System.Threading.AbandonedMutexException] { $mutexOwned = $true }

    if (-not $mutexOwned) {
        Write-Host "[SKIP] Un lancement individuel $InstanceName est deja en cours." -ForegroundColor Yellow
        exit 0
    }

    $controlPath = Join-Path $PSScriptRoot 'PinteMod_MultiServer_Control.ps1'
    if (-not (Test-Path -LiteralPath $controlPath -PathType Leaf)) {
        throw 'PinteMod_MultiServer_Control.ps1 est absent.'
    }

    $sourceConfig = Get-SourceConfigPath
    $runtimeRoot = Join-Path (Join-Path $PSScriptRoot 'runtime\single') $safeInstance
    $singleConfig = Join-Path $runtimeRoot 'PinteMod_MultiServer.single.json'
    [void](New-SingleInstanceConfig -SourcePath $sourceConfig -WantedInstance $InstanceName -OutputPath $singleConfig)

    Clear-Host
    Write-Host '============================================================' -ForegroundColor DarkCyan
    Write-Host (" PinteMod - lancement individuel {0}" -f $InstanceName) -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor DarkCyan
    Write-Host 'Le Control MultiServer existant reste l unique orchestrateur.' -ForegroundColor Gray
    Write-Host 'Worker/Supervisor/Ban/GeoIP sont limites a cette instance. Live/RCON standalone sont desactives par le Control Center.' -ForegroundColor Gray
    Write-Host ''

    # IMPORTANT:
    # Ne pas utiliser Start-Process -Wait ici. Sous Windows PowerShell, -Wait
    # peut attendre l'arbre de processus complet. Le Control lance justement
    # des outils persistants (Worker/Ban/GeoIP), ce qui
    # laisserait cette fenetre de lancement ouverte indefiniment.
    #
    # L'appel direct attend uniquement la fin du processus Control. Le Control
    # peut alors terminer normalement apres avoir lance les outils persistants.
    & powershell.exe `
        -NoLogo `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -File $controlPath `
        -ConfigPath $singleConfig

    $controlExitCode = $LASTEXITCODE
    if ($controlExitCode -ne 0) {
        throw "Le Control MultiServer a termine avec le code $controlExitCode."
    }
}
finally {
    if ($mutex) {
        try { if ($mutexOwned) { $mutex.ReleaseMutex() | Out-Null } } catch { }
        $mutex.Dispose()
    }
}
