# Control Center Bridge — conception BOIII générique sûre

Statut : fondation de développement, non stable.

## But

Permettre au Control Center de fonctionner progressivement sur un serveur BOIII Zombies sans PinteMod, tout en gardant PinteMod comme provider le plus riche lorsqu'il est présent.

Le Bridge n'est pas un système de plugins et n'injecte jamais du code dans un GSC tiers. Il possède uniquement ses propres fichiers versionnés.

## Modes

- `Simulation` : aucune commande.
- `BOIII Native` : commandes natives fermées dont la grammaire est prouvée.
- `GSC Catalog` : analyse statique read-only de fichiers explicitement choisis.
- `Generic Bridge` : producteurs first-party minimaux et feedback structuré.
- `PinteMod Adapter` : capacités PinteMod riches, sans duplication du Generic Bridge.

## Installation sûre

L'installateur final suivra :

1. préflight read-only ;
2. dry-run par défaut ;
3. vérification de la racine BOIII choisie explicitement ;
4. inventaire borné de `boiii/custom_scripts` ;
5. détection PinteMod / Bridge existant ;
6. contrôle des collisions de noms réservés ;
7. affichage exact des fichiers qui seraient ajoutés ;
8. consentement explicite ;
9. copie uniquement de fichiers first-party ;
10. manifeste versionné + SHA-256 ;
11. aucun redémarrage automatique.

Une collision avec un nom réservé et une empreinte inconnue bloque l'installation. Aucun fichier tiers n'est écrasé, même avec sauvegarde.

## Mise à jour / retrait

Une mise à jour ne remplace qu'un fichier identifié comme Bridge first-party par son manifeste et son empreinte connue. Un uninstall refuse de supprimer un fichier qui a été modifié depuis l'installation afin de ne jamais détruire une modification tierce.

## Capacités génériques initiales

Le premier Bridge autonome devra se limiter aux capacités démontrables sans dépendance map-specific : heartbeat/session/map, identité publique neutralisée, capabilities fermées, feedback local et Change Map avec allowlist opérateur.

Les joueurs ne deviennent exploitables que lorsqu'un BOIII_XUID stable est réellement disponible. Les boss, événements, perks ou armes ne sont jamais activés génériquement sur la base d'un nom de fonction trouvé dans un GSC.

## Catalogue GSC read-only

L'analyseur ne compile ni n'exécute les fichiers. Il détecte uniquement des patterns statiques audités et retourne des candidats avec fichier, ligne, pattern et confiance. Une commande découverte reste inactive tant qu'un descripteur fermé first-party n'a pas été approuvé.

## Compatibilité PinteMod

Si PinteMod est présent et fournit une capacité équivalente, le Control Center choisit la source PinteMod fraîche et n'installe pas un producteur générique concurrent. Un petit `PinteMod Adapter` pourra exposer les contrats nécessaires au Control Center sans modifier les modules historiques stables.
