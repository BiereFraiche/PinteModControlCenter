[CmdletBinding()]
param(
    [switch]$Apply
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($PSScriptRoot)

function Get-ActivePinteModToolProcesses {
    $escapedRoot = [regex]::Escape($root)
    try {
        return @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
            Where-Object {
                $_.CommandLine -and
                $_.CommandLine -match $escapedRoot -and
                $_.CommandLine -notmatch '(?i)Cleanup_PinteMod_Multi_Safe\.ps1'
            })
    }
    catch {
        return @()
    }
}

$obsoleteNames = @(
    'PORTABLE_2.local.json',
    'PORTABLE_3.local.json',
    'TEST_PORTABLE_2.bat',
    'TEST_PORTABLE_3.bat',
    'STATIC_CHECKS.txt'
)

$candidates = @()
foreach ($name in $obsoleteNames) {
    $path = Join-Path $root $name
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $candidates += $path
    }
}

$runtimeRoot = Join-Path $root 'runtime'
if (Test-Path -LiteralPath $runtimeRoot -PathType Container) {
    foreach ($file in @(Get-ChildItem -LiteralPath $runtimeRoot -File -Recurse -ErrorAction SilentlyContinue)) {
        if ($file.FullName -like (Join-Path $runtimeRoot 'secrets\*')) {
            continue
        }
        if ($file.Extension -ieq '.log' -or
            $file.Name -ieq 'PinteMod_MultiServer.single.json') {
            $candidates += $file.FullName
        }
    }
}

Write-Host '============================================================' -ForegroundColor DarkCyan
Write-Host ' PinteMod Multi - nettoyage reproductible' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor DarkCyan
Write-Host ('Mode       : ' + $(if ($Apply) { 'APPLY' } else { 'AUDIT ONLY' })) -ForegroundColor Gray
Write-Host ('Candidates : ' + $candidates.Count) -ForegroundColor Gray
Write-Host 'Preserve    : START_3_ALL_IN_ONE, ATTACH_3_RUNNING, FIXE_3, TEST_1, TEST_2, TEST_FIXE_3' -ForegroundColor Green
Write-Host 'Preserve    : runtime\secrets (DPAPI) et tous les fichiers *.secret.txt' -ForegroundColor Green
Write-Host ''

foreach ($candidate in $candidates | Sort-Object -Unique) {
    $relative = $candidate.Substring($root.Length).TrimStart('\')
    Write-Host ('  ' + $relative) -ForegroundColor DarkGray
}

if (-not $Apply) {
    Write-Host ''
    Write-Host '[AUDIT] Aucun fichier supprime.' -ForegroundColor Yellow
    exit 0
}

$active = @(Get-ActivePinteModToolProcesses)
if ($active.Count -gt 0) {
    throw 'Nettoyage refuse : au moins un outil PinteMod Multi utilise encore ce dossier. Ferme les fenetres Multi/Live/RCON puis relance.'
}

$removed = 0
foreach ($candidate in $candidates | Sort-Object -Unique) {
    if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        Remove-Item -LiteralPath $candidate -Force -ErrorAction Stop
        $removed++
    }
}

# Supprime seulement les dossiers runtime devenus vides, jamais runtime\secrets.
if (Test-Path -LiteralPath $runtimeRoot -PathType Container) {
    $directories = @(Get-ChildItem -LiteralPath $runtimeRoot -Directory -Recurse -ErrorAction SilentlyContinue |
        Sort-Object { $_.FullName.Length } -Descending)
    foreach ($directory in $directories) {
        if ($directory.FullName -eq (Join-Path $runtimeRoot 'secrets')) { continue }
        $items = @(Get-ChildItem -LiteralPath $directory.FullName -Force -ErrorAction SilentlyContinue)
        if ($items.Count -eq 0) {
            Remove-Item -LiteralPath $directory.FullName -Force -ErrorAction SilentlyContinue
        }
    }
}

Write-Host ''
Write-Host ("[PASS] Nettoyage termine : {0} fichier(s) supprime(s)." -f $removed) -ForegroundColor Green
Write-Host 'Les secrets DPAPI ont ete preserves.' -ForegroundColor Green
