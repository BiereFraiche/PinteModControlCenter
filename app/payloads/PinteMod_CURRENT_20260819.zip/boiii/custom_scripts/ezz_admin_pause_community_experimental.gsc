// ============================================================
// PinteMod — Community Pause EXPERIMENTAL v0.4
// File: ezz_admin_pause_community_experimental.gsc
//
// Base: PinteMod v2.1.1 FINAL
//
// Real-server validated foundations reused here:
// - cooperative player freeze;
// - native temporary invulnerability + health fallback;
// - zombie ignore stacking;
// - ai_DisableSpawn preservation;
// - literal waitrealtime up to 180 seconds;
// - spectator spawn blocking for ezzspawn/ezzjoin.
//
// This file is intentionally standalone and reversible:
// NO stable PinteMod file is modified.
//
// Public chat:
//   .pause / !pause   -> 20s majority vote for a 3-minute pause
//   .resume / !resume -> 15s majority vote to resume early
//   .pauseowner / .resumeowner -> Owner-only indefinite pause/resume
// Existing .yes/.no vote commands are reused.
//
// Limits:
// - 1 pause proposal per BOIII_XUID per map/match;
// - maximum 2 successful pauses per map/match;
// - 60s pause-vote cooldown after a completed pause vote;
// - 30s resume-vote cooldown after a failed/completed resume vote.
//
// Safety:
// - pause refused while a player is downed;
// - temporary God Mode protects frozen players;
// - spectator respawn is blocked while paused;
// - admin/server emergency resume: ezzresume;
// - automatic resume after 180 real seconds for Community Pause;
// - Owner pause has no timer and requires explicit Owner/server resume;
// - standard Community votes are blocked while paused.
//
// IMPORTANT:
// This remains a SOFT pause. Generic map/EE script timers are not frozen.
// ============================================================

#using scripts\shared\util_shared;
#using scripts\shared\laststand_shared;
#using scripts\zm\_zm;
#using scripts\zm\_zm_utility;

#using custom_scripts\ezz_admin_chat;
#using custom_scripts\ezz_admin_commands;
#using custom_scripts\ezz_admin_community;
#using custom_scripts\ezz_admin_identity;
#using custom_scripts\ezz_admin_heathcliff;
#using custom_scripts\ezz_admin_localization;
#using custom_scripts\ezz_admin_moderation;


// ------------------------------------------------------------
// Init / state
// ------------------------------------------------------------

autoexec function init()
{
    addcommand("ezzvotepause", ::cmd_ezzvotepause);
    addcommand("ezzvoteresume", ::cmd_ezzvoteresume);
    addcommand("ezzresume", ::cmd_ezzresume);
    addcommand("ezzpauseforce", ::cmd_ezzpauseforce);
    addcommand("ezzpauseowner", ::cmd_ezzpauseowner);
    addcommand("ezzresumeowner", ::cmd_ezzresumeowner);
    addcommand("ezzpausestatus", ::cmd_ezzpausestatus);

    level.pintemod_pause_module_loaded = true;
    level.pintemod_pause_module_version = "0.4-experimental";

    level.pintemod_pause_active = false;
    level.pintemod_pause_owner_infinite = false;
    level.pintemod_pause_owner_name = "";
    level.pintemod_pause_block_spectator_spawns = false;
    level.pintemod_pause_id = 0;
    level.pintemod_pause_started_at = 0;
    level.pintemod_pause_end_at = 0;
    level.pintemod_pause_old_ai_disable_spawn = 0;

    level.pintemod_pause_duration = 180;
    level.pintemod_pause_vote_duration = 20;
    level.pintemod_resume_vote_duration = 15;

    level.pintemod_pause_max_successes = 2;
    level.pintemod_pause_success_count = 0;

    level.pintemod_pause_vote_cooldown = 60;
    level.pintemod_pause_vote_cooldown_until = 0;

    level.pintemod_resume_vote_cooldown = 30;
    level.pintemod_resume_vote_cooldown_until = 0;

    // Occasional public reminder. First reminder after 5 minutes, then
    // every 12 minutes while the feature is available and idle.
    level.pintemod_pause_tip_first_delay = 300;
    level.pintemod_pause_tip_interval = 720;

    // One entry per stable XUID. Cleared naturally on map/restart.
    level.pintemod_pause_requester_xuids = [];

    mkdir("pintemod");
    mkdir("pintemod/logs");
    mkdir("pintemod/remote");

    level thread pause_game_ended_monitor();
    level thread pause_end_game_monitor();
    level thread pause_public_tip_monitor();

    println(
        "^5[PinteMod]^7 Community Pause EXPERIMENTAL v0.4 loaded"
    );
}


// ------------------------------------------------------------
// Occasional public reminder
// ------------------------------------------------------------

function pause_public_tip_monitor()
{
    wait 300;

    for (;;)
    {
        players = GetPlayers();
        vote_active = isdefined(level.pintemod_vote) &&
            level.pintemod_vote.active;

        if (players.size > 0 &&
            !level.pintemod_pause_active &&
            !vote_active &&
            level.pintemod_pause_success_count <
                level.pintemod_pause_max_successes)
        {
            pause_broadcast_compact_chat(
                "pause_tip",
                ""
            );
        }

        wait 720;
    }
}


// ------------------------------------------------------------
// Generic helpers
// ------------------------------------------------------------

function pause_broadcast(message)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player iprintln(message);
    }
}

function pause_broadcast_localized(key)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player iprintln(ezz_admin_localization::text(player, key));
    }
}

function pause_localized_parts(
    player,
    prefix_key,
    value1,
    middle_key,
    value2,
    suffix_key
)
{
    message = "";

    if (isdefined(prefix_key) && prefix_key != "")
        message = message + ezz_admin_localization::text(player, prefix_key);

    if (isdefined(value1) && value1 != "")
        message = message + value1;

    if (isdefined(middle_key) && middle_key != "")
        message = message + ezz_admin_localization::text(player, middle_key);

    if (isdefined(value2) && value2 != "")
        message = message + value2;

    if (isdefined(suffix_key) && suffix_key != "")
        message = message + ezz_admin_localization::text(player, suffix_key);

    return message;
}

function pause_broadcast_chat_localized(key)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        message = ezz_admin_localization::text(player, key);

        if (!isdefined(message) || message == "")
            continue;

        ezz_admin_community::community_private_chat(
            player,
            message
        );
    }
}

function pause_compact_chat_text(player, message_type, actor_name)
{
    language = ezz_admin_localization::get_player_language(player);

    if (!isdefined(actor_name))
        actor_name = "";

    if (language == "fr")
    {
        switch (message_type)
        {
            case "pause_tip":
                return "^5[PinteMod]^7 Besoin d'une pause ? Tapez ^2.pause ^7puis votez avec ^2.yes ^7/ ^1.no^7.";

            case "pause_vote_start":
                return "^5[PinteMod]^7 " + actor_name +
                    " demande une pause. Vote: ^2.yes ^7/ ^1.no ^7(20s).";

            case "resume_vote_start":
                return "^5[PinteMod]^7 " + actor_name +
                    " demande la reprise. Vote: ^2.yes ^7/ ^1.no ^7(15s).";

            case "pause_active_3m":
                return "Pause active - 3 min restantes. Reprendre avant: .resume puis .yes / .no.";

            case "pause_active_2m":
                return "Pause active - 2 min restantes. Reprendre avant: .resume puis .yes / .no.";

            case "pause_active_1m":
                return "Pause active - 1 min restante. Reprendre avant: .resume puis .yes / .no.";

            case "pause_active_30s":
                return "Pause active - 30 sec restantes. Reprendre avant: .resume puis .yes / .no.";

            case "pause_active_10s":
                return "Pause active - 10 sec restantes. Reprendre avant: .resume puis .yes / .no.";

            case "owner_active":
                return "^2[PinteMod]^7 Pause Owner active. Reprendre: ^2.resumeowner^7.";

            case "pause_resumed":
                return "^2[PinteMod]^7 Partie reprise.";

            case "owner_resumed":
                return "^2[PinteMod]^7 Pause Owner terminee. Partie reprise.";

            case "pause_vote_failed":
                return "^1[PinteMod]^7 Vote pause refuse.";

            case "resume_vote_failed":
                return "^1[PinteMod]^7 Vote reprise refuse.";

            case "auto_resume_30":
                return "^3[PinteMod]^7 Reprise automatique dans 30s. Reprendre maintenant: ^2.resume^7.";
        }
    }
    else if (language == "es")
    {
        switch (message_type)
        {
            case "pause_tip":
                return "^5[PinteMod]^7 Necesitas una pausa ? Escribe ^2.pause ^7y vota con ^2.yes ^7/ ^1.no^7.";

            case "pause_vote_start":
                return "^5[PinteMod]^7 " + actor_name +
                    " solicita una pausa. Vota: ^2.yes ^7/ ^1.no ^7(20s).";

            case "resume_vote_start":
                return "^5[PinteMod]^7 " + actor_name +
                    " solicita reanudar. Vota: ^2.yes ^7/ ^1.no ^7(15s).";

            case "pause_active_3m":
                return "Pausa activa - quedan 3 min. Reanudar antes: .resume y luego .yes / .no.";

            case "pause_active_2m":
                return "Pausa activa - quedan 2 min. Reanudar antes: .resume y luego .yes / .no.";

            case "pause_active_1m":
                return "Pausa activa - queda 1 min. Reanudar antes: .resume y luego .yes / .no.";

            case "pause_active_30s":
                return "Pausa activa - quedan 30 s. Reanudar antes: .resume y luego .yes / .no.";

            case "pause_active_10s":
                return "Pausa activa - quedan 10 s. Reanudar antes: .resume y luego .yes / .no.";

            case "owner_active":
                return "^2[PinteMod]^7 Pausa Owner activa. Reanudar: ^2.resumeowner^7.";

            case "pause_resumed":
                return "^2[PinteMod]^7 Partida reanudada.";

            case "owner_resumed":
                return "^2[PinteMod]^7 Pausa Owner terminada. Partida reanudada.";

            case "pause_vote_failed":
                return "^1[PinteMod]^7 Votacion de pausa rechazada.";

            case "resume_vote_failed":
                return "^1[PinteMod]^7 Votacion de reanudacion rechazada.";

            case "auto_resume_30":
                return "^3[PinteMod]^7 Reanudacion automatica en 30s. Reanudar ahora: ^2.resume^7.";
        }
    }

    switch (message_type)
    {
        case "pause_tip":
            return "^5[PinteMod]^7 Need a pause ? Type ^2.pause ^7then vote with ^2.yes ^7/ ^1.no^7.";

        case "pause_vote_start":
            return "^5[PinteMod]^7 " + actor_name +
                " requests a pause. Vote: ^2.yes ^7/ ^1.no ^7(20s).";

        case "resume_vote_start":
            return "^5[PinteMod]^7 " + actor_name +
                " requests resume. Vote: ^2.yes ^7/ ^1.no ^7(15s).";

        case "pause_active_3m":
            return "Pause active - 3 min remaining. Resume early: .resume then .yes / .no.";

        case "pause_active_2m":
            return "Pause active - 2 min remaining. Resume early: .resume then .yes / .no.";

        case "pause_active_1m":
            return "Pause active - 1 min remaining. Resume early: .resume then .yes / .no.";

        case "pause_active_30s":
            return "Pause active - 30 sec remaining. Resume early: .resume then .yes / .no.";

        case "pause_active_10s":
            return "Pause active - 10 sec remaining. Resume early: .resume then .yes / .no.";

        case "owner_active":
            return "^2[PinteMod]^7 Owner pause active. Resume: ^2.resumeowner^7.";

        case "pause_resumed":
            return "^2[PinteMod]^7 Game resumed.";

        case "owner_resumed":
            return "^2[PinteMod]^7 Owner pause ended. Game resumed.";

        case "pause_vote_failed":
            return "^1[PinteMod]^7 Pause vote rejected.";

        case "resume_vote_failed":
            return "^1[PinteMod]^7 Resume vote rejected.";

        case "auto_resume_30":
            return "^3[PinteMod]^7 Automatic resume in 30s. Resume now: ^2.resume^7.";
    }

    return "";
}


function pause_broadcast_compact_chat(message_type, actor_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        message = pause_compact_chat_text(
            player,
            message_type,
            actor_name
        );

        if (message == "")
            continue;

        ezz_admin_community::community_private_chat(
            player,
            message
        );
    }
}


function pause_announce_text(player, message_type, actor_name)
{
    language = ezz_admin_localization::get_player_language(player);

    if (!isdefined(actor_name))
        actor_name = "";

    if (language == "fr")
    {
        switch (message_type)
        {
            case "pause_vote_start":
                return actor_name +
                    " demande une pause. Vote: .yes / .no (20s).";

            case "resume_vote_start":
                return actor_name +
                    " demande la reprise. Vote: .yes / .no (15s).";

            case "pause_active":
                return "Pause active (3 min). Pour reprendre avant: .resume puis .yes / .no.";

            case "owner_active":
                return "Pause Owner active. Pour reprendre: .resumeowner.";

            case "auto_resume_30":
                return "Reprise automatique dans 30s. Pour reprendre maintenant: .resume.";
        }
    }
    else if (language == "es")
    {
        switch (message_type)
        {
            case "pause_vote_start":
                return actor_name +
                    " solicita una pausa. Vota: .yes / .no (20s).";

            case "resume_vote_start":
                return actor_name +
                    " solicita reanudar. Vota: .yes / .no (15s).";

            case "pause_active":
                return "Pausa activa (3 min). Para reanudar antes: .resume y luego .yes / .no.";

            case "owner_active":
                return "Pausa Owner activa. Para reanudar: .resumeowner.";

            case "auto_resume_30":
                return "Reanudacion automatica en 30s. Para reanudar ahora: .resume.";
        }
    }

    switch (message_type)
    {
        case "pause_vote_start":
            return actor_name +
                " requests a pause. Vote: .yes / .no (20s).";

        case "resume_vote_start":
            return actor_name +
                " requests resume. Vote: .yes / .no (15s).";

        case "pause_active":
            return "Pause active (3 min). Resume early: .resume then .yes / .no.";

        case "owner_active":
            return "Owner pause active. Resume: .resumeowner.";

        case "auto_resume_30":
            return "Automatic resume in 30s. Resume now: .resume.";
    }

    return "";
}


function pause_broadcast_announce(message_type, actor_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        message = pause_announce_text(
            player,
            message_type,
            actor_name
        );

        if (message == "")
            continue;

        // Reuse the exact native display path behind ezzannounce.
        // Do not invoke the console command itself: this avoids treating an
        // automatic Pause notice as a voluntary operator ANNOUNCE in operator.log.
        player thread ezz_admin_heathcliff::heathcliff_display(message);
    }
}


function pause_broadcast_heathcliff_once(message_type, actor_name)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        message = pause_announce_text(
            player,
            message_type,
            actor_name
        );

        if (message == "")
            continue;

        // Same visible format as ezzannounce, but one refresh only.
        // The monitor below repeats it while the state is still active.
        player iprintln("^3Heathcliff:^7 " + message);
    }
}


function pause_vote_announce_monitor(vote_id, vote_type)
{
    for (;;)
    {
        if (!isdefined(level.pintemod_vote) ||
            !level.pintemod_vote.active ||
            level.pintemod_vote.id != vote_id ||
            level.pintemod_vote.type != vote_type)
        {
            return;
        }

        actor_name = level.pintemod_vote.initiator_name;

        if (vote_type == "pause")
        {
            pause_broadcast_heathcliff_once(
                "pause_vote_start",
                actor_name
            );
        }
        else if (vote_type == "resume")
        {
            pause_broadcast_heathcliff_once(
                "resume_vote_start",
                actor_name
            );
        }

        // Refresh before the native game-message line disappears.
        waitrealtime 4;
    }
}


function pause_active_countdown_message_type()
{
    if (!isdefined(level.pintemod_pause_end_at) ||
        level.pintemod_pause_end_at <= 0)
    {
        return "pause_active_3m";
    }

    remaining = pause_remaining_seconds(
        level.pintemod_pause_end_at
    );

    if (remaining <= 10)
        return "pause_active_10s";

    if (remaining <= 30)
        return "pause_active_30s";

    if (remaining <= 60)
        return "pause_active_1m";

    if (remaining <= 120)
        return "pause_active_2m";

    return "pause_active_3m";
}


function pause_active_announce_monitor(pause_id, owner_infinite)
{
    for (;;)
    {
        if (!level.pintemod_pause_active ||
            level.pintemod_pause_id != pause_id)
        {
            return;
        }

        // While a resume vote is active, its dedicated monitor owns the
        // Heathcliff line so players see .yes/.no instead of another .resume hint.
        resume_vote_active =
            isdefined(level.pintemod_vote) &&
            level.pintemod_vote.active &&
            level.pintemod_vote.type == "resume";

        if (!resume_vote_active)
        {
            if (owner_infinite)
            {
                pause_broadcast_heathcliff_once(
                    "owner_active",
                    ""
                );
            }
            else
            {
                pause_broadcast_heathcliff_once(
                    pause_active_countdown_message_type(),
                    ""
                );
            }
        }

        waitrealtime 4;
    }
}


function pause_broadcast_localized_parts(
    prefix_key,
    value1,
    middle_key,
    value2,
    suffix_key
)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        player iprintln(
            pause_localized_parts(
                player,
                prefix_key,
                value1,
                middle_key,
                value2,
                suffix_key
            )
        );
    }
}


function pause_log(event_name, details)
{
    line = "[" + GetTime() + "] " + event_name;

    if (isdefined(details) && details != "")
        line = line + " | " + details;

    appendfile("pintemod/logs/pause.log", line + "\n");

    if (isdefined(level.pintemod_server_console_verbose) &&
        level.pintemod_server_console_verbose)
    {
        println("^5[PinteMod][PAUSE]^7 " + line);
    }
}


function pause_player_is_active(player)
{
    if (!isdefined(player))
        return false;

    if (!isdefined(player.sessionstate))
        return false;

    return player.sessionstate == "playing";
}


function pause_count_active_players()
{
    players = GetPlayers();
    count = 0;

    for (i = 0; i < players.size; i++)
    {
        if (pause_player_is_active(players[i]))
            count++;
    }

    return count;
}


function pause_any_player_downed()
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!pause_player_is_active(player))
            continue;

        if (player laststand::player_is_in_laststand())
            return true;
    }

    return false;
}


function pause_get_xuid(player)
{
    if (!isdefined(player))
        return "";

    return ezz_admin_identity::get_player_xuid(player);
}


function pause_xuid_array_contains(values, xuid)
{
    if (!isdefined(values) ||
        !ezz_admin_identity::is_valid_xuid(xuid))
    {
        return false;
    }

    normalized = ezz_admin_identity::normalize_xuid(xuid);

    for (i = 0; i < values.size; i++)
    {
        if (values[i] == normalized)
            return true;
    }

    return false;
}


function pause_xuid_array_add_unique(values, xuid)
{
    if (!isdefined(values))
        values = [];

    if (!ezz_admin_identity::is_valid_xuid(xuid))
        return values;

    normalized = ezz_admin_identity::normalize_xuid(xuid);

    if (!pause_xuid_array_contains(values, normalized))
        values[values.size] = normalized;

    return values;
}


function pause_remaining_seconds(end_time)
{
    remaining = end_time - GetTime();

    if (remaining <= 0)
        return 0;

    return int((remaining + 999) / 1000);
}


function pause_majority_required(required_count)
{
    if (required_count <= 0)
        return 0;

    return int(required_count / 2) + 1;
}


function pause_vote_type_active()
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active ||
        !isdefined(level.pintemod_vote.type))
    {
        return false;
    }

    return level.pintemod_vote.type == "pause" ||
        level.pintemod_vote.type == "resume";
}


// ------------------------------------------------------------
// Pause safety / player protection
// ------------------------------------------------------------

function pause_can_activate(requester, show_message)
{
    if (level.pintemod_pause_active)
    {
        if (show_message && isdefined(requester))
        {
            requester iprintln(
                ezz_admin_localization::text(requester, "pause_already")
            );
        }

        return false;
    }

    if (pause_count_active_players() <= 0)
    {
        if (show_message && isdefined(requester))
        {
            requester iprintln(
                ezz_admin_localization::text(requester, "pause_no_active_player")
            );
        }

        return false;
    }

    if (pause_any_player_downed())
    {
        if (show_message && isdefined(requester))
        {
            requester iprintln(
                ezz_admin_localization::text(requester, "pause_downed")
            );
        }

        return false;
    }

    return true;
}


function pause_apply_player(player)
{
    if (!pause_player_is_active(player))
        return;

    if (isdefined(player.pintemod_pause_applied) &&
        player.pintemod_pause_applied)
    {
        return;
    }

    player.pintemod_pause_saved_health = player.health;
    player.pintemod_pause_saved_maxhealth = player.maxhealth;

    // Preserve other ignore effects through BO3's native counter.
    player zm_utility::increment_ignoreme();

    // Validated cooperative freeze.
    player util::freeze_player_controls(true);

    // Validated temporary protection against environmental/map damage.
    player EnableInvulnerability();
    player.maxhealth = 99999;
    player.health = 99999;

    player.pintemod_pause_applied = true;
}


function pause_release_player(player)
{
    if (!isdefined(player))
        return;

    if (!isdefined(player.pintemod_pause_applied) ||
        !player.pintemod_pause_applied)
    {
        return;
    }

    player util::freeze_player_controls(false);
    player zm_utility::decrement_ignoreme();

    keep_admin_god = false;

    if (isdefined(player.admin_god) && player.admin_god)
        keep_admin_god = true;

    if (!keep_admin_god)
    {
        player DisableInvulnerability();

        if (isdefined(player.pintemod_pause_saved_maxhealth))
            player.maxhealth = player.pintemod_pause_saved_maxhealth;

        if (isdefined(player.pintemod_pause_saved_health))
            player.health = player.pintemod_pause_saved_health;

        if (player.health <= 0)
            player.health = player.maxhealth;
    }

    player.pintemod_pause_applied = false;
}


function pause_player_monitor(pause_id)
{
    while (level.pintemod_pause_active &&
           level.pintemod_pause_id == pause_id)
    {
        players = GetPlayers();

        for (i = 0; i < players.size; i++)
            pause_apply_player(players[i]);

        // Fail-safe: no survivor remains to protect.
        if (pause_count_active_players() <= 0)
        {
            pause_resume_internal("no active players remain");
            return;
        }

        wait 0.1;
    }
}


function pause_auto_resume_timer(pause_id)
{
    // 150 + 20 + 10 = 180 real seconds.
    waitrealtime 150;

    if (!level.pintemod_pause_active ||
        level.pintemod_pause_id != pause_id)
    {
        return;
    }

    // The persistent Heathcliff countdown already switches to 30s
    // and then 10s, so no extra announcement is needed here.
    waitrealtime 30;

    if (!level.pintemod_pause_active ||
        level.pintemod_pause_id != pause_id)
    {
        return;
    }

    pause_resume_internal("automatic 180-second timeout");
}


function pause_start_internal(source, owner_infinite)
{
    if (!pause_can_activate(undefined, false))
        return false;

    level.pintemod_pause_id++;
    pause_id = level.pintemod_pause_id;

    level.pintemod_pause_old_ai_disable_spawn =
        GetDvarInt("ai_DisableSpawn");

    level.pintemod_pause_active = true;
    level.pintemod_pause_owner_infinite = owner_infinite;
    level.pintemod_pause_block_spectator_spawns = true;
    level.pintemod_pause_started_at = GetTime();

    if (owner_infinite)
        level.pintemod_pause_end_at = 0;
    else
    {
        level.pintemod_pause_end_at =
            GetTime() + (level.pintemod_pause_duration * 1000);
    }

    SetDvar("ai_DisableSpawn", 1);

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
        pause_apply_player(players[i]);

    pause_mode = "community_timed";

    if (owner_infinite)
        pause_mode = "owner_infinite";

    pause_log(
        "PAUSE_START",
        "source=" + source +
        " | mode=" + pause_mode +
        " | successful_before=" + level.pintemod_pause_success_count +
        "/" + level.pintemod_pause_max_successes +
        " | active_players=" + pause_count_active_players()
    );

    level thread pause_player_monitor(pause_id);
    level thread pause_active_announce_monitor(
        pause_id,
        owner_infinite
    );

    if (!owner_infinite)
        level thread pause_auto_resume_timer(pause_id);

    return true;
}


function pause_cancel_resume_vote_if_active(reason)
{
    if (!pause_vote_type_active())
        return;

    if (level.pintemod_vote.type != "resume")
        return;

    pause_finish_vote(false, reason);
}


function pause_resume_internal(reason)
{
    if (!level.pintemod_pause_active)
        return false;

    was_owner_infinite = level.pintemod_pause_owner_infinite;

    // Prevent a stale resume vote surviving after automatic/admin resume.
    pause_cancel_resume_vote_if_active("Pause ended before resume vote result");

    level.pintemod_pause_active = false;
    level.pintemod_pause_owner_infinite = false;
    level.pintemod_pause_owner_name = "";
    level.pintemod_pause_block_spectator_spawns = false;
    level.pintemod_pause_end_at = 0;

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
        pause_release_player(players[i]);

    SetDvar(
        "ai_DisableSpawn",
        level.pintemod_pause_old_ai_disable_spawn
    );

    if (was_owner_infinite)
    {
        pause_broadcast_compact_chat(
            "owner_resumed",
            ""
        );
    }
    else
    {
        pause_broadcast_compact_chat(
            "pause_resumed",
            ""
        );
    }

    pause_log(
        "PAUSE_END",
        "reason=" + reason +
        " | owner_infinite=" + was_owner_infinite +
        " | active_players=" + pause_count_active_players()
    );

    return true;
}


function pause_game_ended_monitor()
{
    level waittill("game_ended");

    if (level.pintemod_pause_active)
        pause_resume_internal("game transition: game_ended");
}


function pause_end_game_monitor()
{
    level waittill("end_game");

    if (level.pintemod_pause_active)
        pause_resume_internal("game transition: end_game");
}


// ------------------------------------------------------------
// Community vote electorate / result
// ------------------------------------------------------------

function pause_vote_add_active_players()
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!pause_player_is_active(player))
            continue;

        xuid = pause_get_xuid(player);

        if (!ezz_admin_identity::is_valid_xuid(xuid))
            continue;

        level.pintemod_vote.required_xuids =
            ezz_admin_community::community_array_add_unique(
                level.pintemod_vote.required_xuids,
                xuid
            );

        ezz_admin_community::community_vote_add_voter_entry(
            level.pintemod_vote,
            xuid,
            player.name
        );
    }
}


function pause_vote_summary_text(player, vote, passed)
{
    threshold = pause_majority_required(vote.required_xuids.size);
    prefix = "^1[PinteMod]^7 " + toUpper(vote.type);
    middle_key = "pause_vote_summary_fail_mid";

    if (passed)
    {
        prefix = "^2[PinteMod]^7 " + toUpper(vote.type);
        middle_key = "pause_vote_summary_pass_mid";
    }

    summary = prefix + ezz_admin_localization::text(player, middle_key) +
        vote.yes_xuids.size;

    if (passed)
        summary = summary + "/" + vote.required_xuids.size;

    summary = summary + ezz_admin_localization::text(
        player,
        "community_vote_yes_label"
    );

    if (!passed)
    {
        summary = summary + "^7, ^1" + vote.no_xuids.size +
            ezz_admin_localization::text(
                player,
                "community_vote_no_label"
            );
    }

    return summary + ezz_admin_localization::text(
        player,
        "pause_vote_summary_majority"
    ) + threshold + ")";
}

function pause_broadcast_vote_summary(vote, passed)
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player iprintln(pause_vote_summary_text(player, vote, passed));
    }
}


function pause_finish_vote(passed, result_reason)
{
    if (!pause_vote_type_active())
        return;

    vote = level.pintemod_vote;
    vote_type = vote.type;

    // Revalidate the gameplay state at the exact moment a pause is applied.
    if (passed && vote_type == "pause" &&
        !pause_can_activate(undefined, false))
    {
        passed = false;
        result_reason = "Pause became unsafe before activation";
    }

    if (passed && vote_type == "resume" &&
        !level.pintemod_pause_active)
    {
        passed = false;
        result_reason = "Game is no longer paused";
    }

    ezz_admin_community::community_vote_add_event(
        "Result: " + result_reason + " | passed=" + passed
    );

    vote.active = false;

    result_text = "FAILED";

    if (passed)
        result_text = "PASSED";

    summary = result_text + " | type=" + vote_type +
        " | initiator=" + vote.initiator_name +
        " [" + vote.initiator_xuid + "]" +
        " | yes=" + vote.yes_xuids.size +
        "/" + vote.required_xuids.size +
        " | no=" + vote.no_xuids.size +
        " | reason=" + result_reason;

    level.pintemod_last_vote_summary = summary;

    appendfile(
        "pintemod/logs/vote_summary.log",
        "[" + GetTime() + "] " + summary + "\n"
    );

    pause_log(
        "VOTE_RESULT",
        summary
    );

    if (!passed)
    {
        if (vote_type == "pause")
        {
            pause_broadcast_compact_chat(
                "pause_vote_failed",
                ""
            );
        }
        else
        {
            pause_broadcast_compact_chat(
                "resume_vote_failed",
                ""
            );
        }
    }

    level.pintemod_vote = SpawnStruct();
    level.pintemod_vote.active = false;

    if (vote_type == "pause")
    {
        level.pintemod_pause_vote_cooldown_until =
            GetTime() + (level.pintemod_pause_vote_cooldown * 1000);

        if (passed)
        {
            if (pause_start_internal("community majority vote", false))
            {
                level.pintemod_pause_success_count++;

                pause_log(
                    "PAUSE_COUNT",
                    "successful=" + level.pintemod_pause_success_count +
                    "/" + level.pintemod_pause_max_successes
                );
            }
        }

        return;
    }

    if (vote_type == "resume")
    {
        level.pintemod_resume_vote_cooldown_until =
            GetTime() + (level.pintemod_resume_vote_cooldown * 1000);

        if (passed)
            pause_resume_internal("community majority resume vote");
    }
}


function pause_check_vote_resolution()
{
    if (!pause_vote_type_active())
        return;

    required = level.pintemod_vote.required_xuids.size;
    yes_count = level.pintemod_vote.yes_xuids.size;
    no_count = level.pintemod_vote.no_xuids.size;
    threshold = pause_majority_required(required);

    if (required <= 0 || threshold <= 0)
    {
        pause_finish_vote(false, "No eligible active voters");
        return;
    }

    if (yes_count >= threshold)
    {
        pause_finish_vote(true, "Majority approval");
        return;
    }

    // Enough NO votes that reaching the majority is mathematically impossible.
    if (no_count > (required - threshold))
    {
        pause_finish_vote(false, "Majority can no longer be reached");
    }
}


function pause_vote_timer(vote_id)
{
    for (;;)
    {
        wait 1;

        if (!pause_vote_type_active() ||
            level.pintemod_vote.id != vote_id)
        {
            return;
        }

        remaining = pause_remaining_seconds(
            level.pintemod_vote.end_time
        );

        if (remaining <= 0)
        {
            pause_finish_vote(false, "Vote timed out");
            return;
        }

    }
}


// ------------------------------------------------------------
// Pause / resume vote creation
// ------------------------------------------------------------

function pause_requester_is_valid(player)
{
    if (!isdefined(player))
        return false;

    if (!pause_player_is_active(player))
    {
        player iprintln(
            ezz_admin_localization::text(player, "pause_spectator_vote")
        );
        return false;
    }

    xuid = pause_get_xuid(player);

    if (!ezz_admin_identity::is_valid_xuid(xuid))
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_vote_identity_unavailable"
            )
        );
        return false;
    }

    return true;
}


function pause_start_pause_vote(requester)
{
    if (!pause_requester_is_valid(requester))
        return;

    if (level.pintemod_pause_active)
    {
        if (level.pintemod_pause_owner_infinite)
        {
            requester iprintln(
                ezz_admin_localization::text(
                    requester,
                    "pause_owner_active_resume_only"
                )
            );
        }
        else
        {
            requester iprintln(
                ezz_admin_localization::text(
                    requester,
                    "pause_game_already_resume"
                )
            );
        }

        return;
    }

    if (level.pintemod_pause_success_count >=
        level.pintemod_pause_max_successes)
    {
        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_limit_prefix"
            ) + level.pintemod_pause_max_successes
        );
        return;
    }

    if (!pause_can_activate(requester, true))
        return;

    requester_xuid = pause_get_xuid(requester);

    if (pause_xuid_array_contains(
        level.pintemod_pause_requester_xuids,
        requester_xuid
    ))
    {
        requester iprintln(
            ezz_admin_localization::text(requester, "pause_proposal_used")
        );
        return;
    }

    if (GetTime() < level.pintemod_pause_vote_cooldown_until)
    {
        remaining = pause_remaining_seconds(
            level.pintemod_pause_vote_cooldown_until
        );

        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_vote_cooldown_prefix"
            ) + remaining + "s"
        );
        return;
    }

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        requester iprintln(
            ezz_admin_localization::text(requester, "pause_another_vote")
        );
        return;
    }

    // Proposal quota is consumed when the vote is actually started.
    level.pintemod_pause_requester_xuids =
        pause_xuid_array_add_unique(
            level.pintemod_pause_requester_xuids,
            requester_xuid
        );

    if (!ezz_admin_community::community_create_vote(
        "pause",
        requester
    ))
    {
        return;
    }

    level.pintemod_vote.end_time =
        GetTime() + (level.pintemod_pause_vote_duration * 1000);
    level.pintemod_vote.last_notice = -1;

    pause_vote_add_active_players();

    level.pintemod_vote.yes_xuids =
        ezz_admin_community::community_array_add_unique(
            level.pintemod_vote.yes_xuids,
            requester_xuid
        );

    ezz_admin_community::community_vote_add_event(
        requester.name + " [" + requester_xuid +
        "] automatically voted YES"
    );

    threshold = pause_majority_required(
        level.pintemod_vote.required_xuids.size
    );

    pause_log(
        "PAUSE_VOTE_START",
        "initiator=" + requester.name +
        " | xuid=" +
        ezz_admin_identity::identity_log_xuid_value(requester_xuid) +
        " | required=" + level.pintemod_vote.required_xuids.size +
        " | majority=" + threshold
    );

    vote_id = level.pintemod_vote.id;
    level thread pause_vote_announce_monitor(
        vote_id,
        "pause"
    );
    level thread pause_vote_timer(vote_id);
    pause_check_vote_resolution();
}


function pause_start_resume_vote(requester)
{
    if (!pause_requester_is_valid(requester))
        return;

    if (!level.pintemod_pause_active)
    {
        requester iprintln(
            ezz_admin_localization::text(requester, "pause_not_paused")
        );
        return;
    }

    if (level.pintemod_pause_owner_infinite)
    {
        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_owner_active_resume_only"
            )
        );
        return;
    }

    if (GetTime() < level.pintemod_resume_vote_cooldown_until)
    {
        remaining = pause_remaining_seconds(
            level.pintemod_resume_vote_cooldown_until
        );

        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_resume_cooldown_prefix"
            ) + remaining + "s"
        );
        return;
    }

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        requester iprintln(
            ezz_admin_localization::text(requester, "pause_another_vote")
        );
        return;
    }

    requester_xuid = pause_get_xuid(requester);

    if (!ezz_admin_community::community_create_vote(
        "resume",
        requester
    ))
    {
        return;
    }

    level.pintemod_vote.end_time =
        GetTime() + (level.pintemod_resume_vote_duration * 1000);
    level.pintemod_vote.last_notice = -1;

    pause_vote_add_active_players();

    level.pintemod_vote.yes_xuids =
        ezz_admin_community::community_array_add_unique(
            level.pintemod_vote.yes_xuids,
            requester_xuid
        );

    ezz_admin_community::community_vote_add_event(
        requester.name + " [" + requester_xuid +
        "] automatically voted YES"
    );

    threshold = pause_majority_required(
        level.pintemod_vote.required_xuids.size
    );

    pause_log(
        "RESUME_VOTE_START",
        "initiator=" + requester.name +
        " | xuid=" +
        ezz_admin_identity::identity_log_xuid_value(requester_xuid) +
        " | required=" + level.pintemod_vote.required_xuids.size +
        " | majority=" + threshold
    );

    vote_id = level.pintemod_vote.id;
    level thread pause_vote_announce_monitor(
        vote_id,
        "resume"
    );
    level thread pause_vote_timer(vote_id);
    pause_check_vote_resolution();
}


// ------------------------------------------------------------
// RCON / console commands
// ------------------------------------------------------------

function cmd_ezzvotepause(args)
{
    if (args.size < 1)
    {
        println(
            "^5[PinteMod]^7 Usage: ezzvotepause " +
            "<PlayerName|BOIII_XUID|ClientNumber>"
        );
        return;
    }

    requester =
        ezz_admin_identity::identity_find_player(args[0]);

    if (!isdefined(requester))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    pause_start_pause_vote(requester);
}


function cmd_ezzvoteresume(args)
{
    if (args.size < 1)
    {
        println(
            "^5[PinteMod]^7 Usage: ezzvoteresume " +
            "<PlayerName|BOIII_XUID|ClientNumber>"
        );
        return;
    }

    requester =
        ezz_admin_identity::identity_find_player(args[0]);

    if (!isdefined(requester))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    pause_start_resume_vote(requester);
}


function cmd_ezzresume(args)
{
    if (!level.pintemod_pause_active)
    {
        println("^3[PinteMod]^7 Game is not paused");
        return;
    }

    pause_resume_internal("server/admin emergency resume");
}


function cmd_ezzpauseforce(args)
{
    if (level.pintemod_pause_active)
    {
        println("^3[PinteMod]^7 Game is already paused");
        return;
    }

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        println("^3[PinteMod]^7 Force pause refused: a Community vote is active");
        return;
    }

    if (!pause_can_activate(undefined, false))
    {
        println(
            "^1[PinteMod]^7 Force pause refused: no active player or a player is downed"
        );
        return;
    }

    pause_start_internal("server/admin force", false);
}


function pause_owner_requester_from_args(args)
{
    if (args.size <= 0)
        return undefined;

    requester =
        ezz_admin_identity::identity_find_player(args[0]);

    return requester;
}


function pause_owner_request_is_allowed(args)
{
    // No actor selector means trusted dedicated-server/RCON console.
    if (args.size <= 0)
        return true;

    requester = pause_owner_requester_from_args(args);

    if (!isdefined(requester))
    {
        println("^1[PinteMod]^7 Owner pause requester not found");
        return false;
    }

    if (ezz_admin_identity::get_player_role(requester) < 4)
    {
        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_owner_role_required_infinite"
            )
        );
        println(
            "^1[PinteMod]^7 Infinite pause denied: requester is not Owner"
        );
        return false;
    }

    return true;
}


function cmd_ezzpauseowner(args)
{
    if (!pause_owner_request_is_allowed(args))
        return;

    if (level.pintemod_pause_active)
    {
        println("^3[PinteMod]^7 Game is already paused");
        return;
    }

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        println(
            "^3[PinteMod]^7 Owner pause refused: a Community vote is active"
        );
        return;
    }

    if (!pause_can_activate(undefined, false))
    {
        println(
            "^1[PinteMod]^7 Owner pause refused: no active player or a player is downed"
        );
        return;
    }

    requester = pause_owner_requester_from_args(args);

    if (isdefined(requester))
        level.pintemod_pause_owner_name = requester.name;
    else
        level.pintemod_pause_owner_name = "server";

    pause_start_internal("owner infinite", true);
}


function cmd_ezzresumeowner(args)
{
    if (!pause_owner_request_is_allowed(args))
        return;

    if (!level.pintemod_pause_active)
    {
        println("^3[PinteMod]^7 Game is not paused");
        return;
    }

    if (!level.pintemod_pause_owner_infinite)
    {
        println(
            "^3[PinteMod]^7 Current pause is not an Owner infinite pause"
        );
        return;
    }

    pause_resume_internal("owner explicit resume");
}


function pause_write_remote_status_feedback()
{
    remaining = 0;
    remaining_text = "0s";
    pause_mode = "inactive";
    temp_god = "OFF";
    spawn_guard = "OFF";
    ai_spawn = "normal";
    vote_status = "none";

    if (level.pintemod_pause_active)
    {
        pause_mode = "community_timed";

        if (level.pintemod_pause_owner_infinite)
        {
            pause_mode = "owner_infinite";
            remaining_text = "INFINITE";
        }
        else
        {
            remaining = pause_remaining_seconds(
                level.pintemod_pause_end_at
            );
            remaining_text = remaining + "s";
        }

        temp_god = "ON";
        spawn_guard = "ON";
        ai_spawn = "blocked";
    }

    if (pause_vote_type_active())
    {
        threshold = pause_majority_required(
            level.pintemod_vote.required_xuids.size
        );

        vote_status =
            level.pintemod_vote.type +
            " | YES=" + level.pintemod_vote.yes_xuids.size +
            " | NO=" + level.pintemod_vote.no_xuids.size +
            " | majority=" + threshold;
    }

    feedback =
        "PINTEMOD_REMOTE_FEEDBACK_V1\n" +
        "command=ezzpausestatus\n" +
        "generated_gettime=" + GetTime() + "\n" +
        "---\n" +
        "PinteMod Community Pause - EXPERIMENTAL v0.3\n" +
        "Active: " + level.pintemod_pause_active + "\n" +
        "Mode: " + pause_mode + "\n" +
        "Automatic resume in: " + remaining_text + "\n" +
        "Successful pauses: " +
            level.pintemod_pause_success_count + "/" +
            level.pintemod_pause_max_successes + "\n" +
        "Pause proposals used: " +
            level.pintemod_pause_requester_xuids.size + "\n" +
        "Pause vote: " +
            level.pintemod_pause_vote_duration +
            "s | majority\n" +
        "Resume vote: " +
            level.pintemod_resume_vote_duration +
            "s | majority\n" +
        "Public reminder: first=" +
            level.pintemod_pause_tip_first_delay +
            "s | every=" +
            level.pintemod_pause_tip_interval + "s\n" +
        "Active vote: " + vote_status + "\n" +
        "Temporary God Mode: " + temp_god + "\n" +
        "Spectator spawn guard: " + spawn_guard + "\n" +
        "New AI spawning: " + ai_spawn + "\n" +
        "Soft pause: map/EE script timers are NOT frozen\n" +
        "END\n";

    writefile(
        "pintemod/remote/feedback.latest.txt",
        feedback
    );
}


function cmd_ezzpausestatus(args)
{
    remaining = 0;

    if (level.pintemod_pause_active &&
        !level.pintemod_pause_owner_infinite)
    {
        remaining = pause_remaining_seconds(
            level.pintemod_pause_end_at
        );
    }

    println("^5===== PINTEMOD COMMUNITY PAUSE =====");
    println("^7Module: EXPERIMENTAL v0.4");
    println("^7Active: " + level.pintemod_pause_active);
    println(
        "^7Successful pauses: " +
        level.pintemod_pause_success_count + "/" +
        level.pintemod_pause_max_successes
    );
    println(
        "^7Pause proposals used: " +
        level.pintemod_pause_requester_xuids.size
    );
    println(
        "^7Pause vote: " +
        level.pintemod_pause_vote_duration + "s | majority"
    );
    println(
        "^7Resume vote: " +
        level.pintemod_resume_vote_duration + "s | majority"
    );
    println(
        "^7Public reminder: first=" +
        level.pintemod_pause_tip_first_delay + "s | every=" +
        level.pintemod_pause_tip_interval + "s"
    );

    if (level.pintemod_pause_active)
    {
        if (level.pintemod_pause_owner_infinite)
        {
            println("^7Mode: OWNER INFINITE");
            println("^7Owner source: " + level.pintemod_pause_owner_name);
            println("^7Automatic resume: disabled");
            println("^7Resume: .resumeowner / ezzresumeowner");
        }
        else
        {
            println("^7Mode: COMMUNITY TIMED");
            println(
                "^7Automatic resume in: " + remaining + "s"
            );
        }

        println("^7Temporary God Mode: ON");
        println("^7Spectator spawn guard: ON");
        println("^7New AI spawning: blocked");
    }
    else
    {
        println("^7Temporary God Mode: OFF");
        println("^7Spectator spawn guard: OFF");
    }

    if (pause_vote_type_active())
    {
        threshold = pause_majority_required(
            level.pintemod_vote.required_xuids.size
        );

        println(
            "^7Active vote: " + level.pintemod_vote.type +
            " | YES=" + level.pintemod_vote.yes_xuids.size +
            " | NO=" + level.pintemod_vote.no_xuids.size +
            " | majority=" + threshold
        );
    }

    println("^7Log: boiii/scriptdata/pintemod/logs/pause.log");
    println("^7Remote feedback: boiii/scriptdata/pintemod/remote/feedback.latest.txt");
    println("^3Soft pause: map/EE script timers are NOT frozen");
    println("^5====================================");

    pause_write_remote_status_feedback();

    pause_log(
        "STATUS",
        "active=" + level.pintemod_pause_active +
        " | remaining=" + remaining +
        " | owner_infinite=" + level.pintemod_pause_owner_infinite +
        " | successful=" +
        level.pintemod_pause_success_count + "/" +
        level.pintemod_pause_max_successes +
        " | proposals=" +
        level.pintemod_pause_requester_xuids.size
    );
}


// ------------------------------------------------------------
// Detour: existing .yes/.no vote casting
//
// Existing next-map/restart/kick behaviour is preserved.
// Pause/resume votes use majority instead of unanimity.
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_community::community_cast_vote(
    player,
    vote_yes
)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        player iprintln(ezz_admin_localization::text(player, "community_vote_none"));
        return;
    }

    player_xuid =
        ezz_admin_community::community_get_xuid(player);

    if (!ezz_admin_identity::is_valid_xuid(player_xuid))
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_vote_identity_unavailable"
            )
        );
        return;
    }

    if (!ezz_admin_community::community_array_contains(
        level.pintemod_vote.required_xuids,
        player_xuid
    ))
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_vote_not_eligible"
            )
        );
        return;
    }

    if (ezz_admin_community::community_array_contains(
        level.pintemod_vote.yes_xuids,
        player_xuid
    ) || ezz_admin_community::community_array_contains(
        level.pintemod_vote.no_xuids,
        player_xuid
    ))
    {
        player iprintln(ezz_admin_localization::text(player, "community_vote_already_voted"));
        return;
    }

    ezz_admin_community::community_vote_add_voter_entry(
        level.pintemod_vote,
        player_xuid,
        player.name
    );

    if (!vote_yes)
    {
        level.pintemod_vote.no_xuids =
            ezz_admin_community::community_array_add_unique(
                level.pintemod_vote.no_xuids,
                player_xuid
            );

        ezz_admin_community::community_vote_add_event(
            player.name + " [" + player_xuid + "] voted NO"
        );

        if (pause_vote_type_active())
        {
            threshold = pause_majority_required(
                level.pintemod_vote.required_xuids.size
            );

            players = GetPlayers();

            for (i = 0; i < players.size; i++)
            {
                viewer = players[i];

                if (!isdefined(viewer))
                    continue;

                viewer iprintln(
                    "^1[PinteMod]^7 " + player.name +
                    ezz_admin_localization::text(
                        viewer,
                        "community_voted_no_mid"
                    ) + " ^2" + level.pintemod_vote.yes_xuids.size +
                    ezz_admin_localization::text(
                        viewer,
                        "community_vote_yes_label"
                    ) + "^7 / ^1" + level.pintemod_vote.no_xuids.size +
                    ezz_admin_localization::text(
                        viewer,
                        "community_vote_no_label"
                    ) + " ^7| " +
                    ezz_admin_localization::text(
                        viewer,
                        "pause_vote_summary_majority"
                    ) + threshold + ")"
                );
            }

            pause_check_vote_resolution();
            return;
        }

        // Original PinteMod behaviour: standard Community votes are unanimous.
        pause_broadcast_localized_parts(
            "",
            "^1[PinteMod]^7 " + player.name,
            "community_voted_no_mid",
            "",
            ""
        );

        ezz_admin_community::community_finish_vote(
            false,
            player.name + " voted NO"
        );
        return;
    }

    level.pintemod_vote.yes_xuids =
        ezz_admin_community::community_array_add_unique(
            level.pintemod_vote.yes_xuids,
            player_xuid
        );

    ezz_admin_community::community_vote_add_event(
        player.name + " [" + player_xuid + "] voted YES"
    );

    if (pause_vote_type_active())
    {
        threshold = pause_majority_required(
            level.pintemod_vote.required_xuids.size
        );

        players = GetPlayers();

        for (i = 0; i < players.size; i++)
        {
            viewer = players[i];

            if (!isdefined(viewer))
                continue;

            viewer iprintln(
                "^2[PinteMod]^7 " + player.name +
                ezz_admin_localization::text(
                    viewer,
                    "community_voted_yes_mid"
                ) + level.pintemod_vote.yes_xuids.size + "/" +
                level.pintemod_vote.required_xuids.size +
                " ^7| " + ezz_admin_localization::text(
                    viewer,
                    "pause_vote_summary_majority"
                ) + threshold + ")"
            );
        }

        pause_check_vote_resolution();
        return;
    }

    // Original PinteMod behaviour for all existing vote types.
    pause_broadcast_localized_parts(
        "",
        "^2[PinteMod]^7 " + player.name,
        "community_voted_yes_mid",
        level.pintemod_vote.yes_xuids.size + "/" +
            level.pintemod_vote.required_xuids.size,
        ""
    );

    ezz_admin_community::community_check_unanimity();
}


// ------------------------------------------------------------
// Detour: unanimity checker
//
// Disconnect handling in Community calls this helper. For pause/resume,
// recalculate majority after the electorate changes.
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_community::community_check_unanimity()
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        return;
    }

    if (pause_vote_type_active())
    {
        pause_check_vote_resolution();
        return;
    }

    required = level.pintemod_vote.required_xuids.size;
    yes_count = level.pintemod_vote.yes_xuids.size;

    if (required > 0 && yes_count >= required)
    {
        ezz_admin_community::community_finish_vote(
            true,
            "Unanimous approval"
        );
    }
}


// ------------------------------------------------------------
// Detour: standard Community vote availability
//
// While gameplay is paused, only the dedicated resume vote may start.
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_community::community_vote_is_available(
    requester
)
{
    ezz_admin_community::community_apply_defaults();

    if (level.pintemod_pause_active)
    {
        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "pause_vote_standard_blocked"
            )
        );
        return false;
    }

    if (isdefined(level.pintemod_vote) &&
        level.pintemod_vote.active)
    {
        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "community_vote_already_active"
            )
        );
        return false;
    }

    if (GetTime() < level.pintemod_vote_cooldown_until)
    {
        remaining =
            ezz_admin_community::community_get_remaining_seconds(
                level.pintemod_vote_cooldown_until
            );

        requester iprintln(
            ezz_admin_localization::text(
                requester,
                "community_vote_cooldown_prefix"
            ) + remaining + "s"
        );
        return false;
    }

    return true;
}


// ------------------------------------------------------------
// Detour: player-facing vote status
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_community::community_show_vote_status(
    player
)
{
    if (!isdefined(level.pintemod_vote) ||
        !level.pintemod_vote.active)
    {
        player iprintln(ezz_admin_localization::text(player, "community_vote_none"));

        if (isdefined(level.pintemod_next_map_code) &&
            level.pintemod_next_map_code != "")
        {
            player iprintln(
                ezz_admin_localization::text(
                    player,
                    "community_status_scheduled_nextmap_prefix"
                ) + level.pintemod_next_map_display
            );
        }

        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_status_last_result_prefix"
            ) + level.pintemod_last_vote_summary
        );
        return;
    }

    vote = level.pintemod_vote;
    remaining =
        ezz_admin_community::community_get_remaining_seconds(
            vote.end_time
        );

    if (vote.type == "pause" || vote.type == "resume")
    {
        threshold = pause_majority_required(
            vote.required_xuids.size
        );

        player iprintln(
            "^5[PinteMod]^7 " + toUpper(vote.type) +
            ezz_admin_localization::text(
                player,
                "pause_status_vote_mid"
            ) + threshold
        );

        player iprintln(
            ezz_admin_localization::text(
                player,
                "pause_status_yes_prefix"
            ) + vote.yes_xuids.size +
            ezz_admin_localization::text(
                player,
                "pause_status_no_mid"
            ) + vote.no_xuids.size +
            ezz_admin_localization::text(
                player,
                "pause_status_voters_mid"
            ) + vote.required_xuids.size +
            ezz_admin_localization::text(
                player,
                "pause_status_time_mid"
            ) + remaining + "s"
        );
        return;
    }

    // Original PinteMod display for existing vote types.
    if (vote.type == "nextmap")
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_status_nextmap_vote_prefix"
            ) + vote.map_display
        );
    }
    else if (vote.type == "restart")
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_status_restart_vote_prefix"
            ) + vote.map_display
        );
    }
    else
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_status_kick_vote_prefix"
            ) + vote.target_name
        );
        player iprintln(
            ezz_admin_localization::text(
                player,
                "community_reason_prefix"
            ) + "^3" + vote.reason
        );
    }

    player iprintln(
        ezz_admin_localization::text(
            player,
            "community_status_counts_prefix"
        ) + vote.yes_xuids.size + "/" + vote.required_xuids.size +
        ezz_admin_localization::text(
            player,
            "community_status_counts_mid1"
        ) + vote.no_xuids.size +
        ezz_admin_localization::text(
            player,
            "community_status_counts_mid2"
        ) + remaining + "s"
    );
}


// ------------------------------------------------------------
// Public chat routing
//
// .pause/.resume/.pauseowner/.resumeowner are handled directly by
// ezz_admin_chat.gsc v0.18.0 compatibility patch. Do not detour the local
// chat_handle_message function here: BOIII may bind same-script calls before
// this module's cross-script detour is installed.
// ------------------------------------------------------------


// ------------------------------------------------------------
// Detour: .help / !help
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_chat::chat_show_help(player)
{
    role = ezz_admin_chat::chat_get_player_role(player);

    player iprintln("^5=== PinteMod CHAT v0.18.0 ===");
    player iprintln(ezz_admin_localization::text(player, "pause_help_menu"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_pause"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_language"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_shortcuts"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_votemap"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_votekick"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_ranks"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_ee"));
    player iprintln(ezz_admin_localization::text(player, "pause_help_info"));

    if (role >= 4)
    {
        player iprintln(
            ezz_admin_localization::text(player, "pause_help_owner")
        );
    }

    if (role <= 0)
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "pause_help_public_only"
            )
        );
        return;
    }

    player iprintln(
        ezz_admin_localization::text(player, "pause_help_admin")
    );
    player iprintln(
        ezz_admin_localization::text(
            player,
            "pause_help_role_prefix"
        ) + ezz_admin_chat::chat_get_role_name(role)
    );
}


// ------------------------------------------------------------
// Detour: ezzspawn guard
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_commands::cmd_ezzspawn(args)
{
    player =
        ezz_admin_commands::get_safe_spawn_target(args);

    if (!isdefined(player))
    {
        if (args.size > 0)
            ezz_admin_commands::print_player_not_found(args[0]);
        else if (GetPlayers().size <= 0)
            ezz_admin_commands::print_no_players();

        return;
    }

    if (level.pintemod_pause_active &&
        level.pintemod_pause_block_spectator_spawns)
    {
        player iprintln(
            ezz_admin_localization::text(player, "pause_respawn_blocked")
        );
        println(
            "^3[PinteMod]^7 Spectator respawn blocked by pause | source=ezzspawn"
        );
        return;
    }

    if (!isdefined(player.sessionstate) ||
        player.sessionstate != "spectator")
    {
        println(
            "^3[PinteMod]^7 " + player.name +
            " is not a spectator"
        );
        player iprintln(ezz_admin_localization::text(player, "latejoin_already_active"));
        return;
    }

    if (!isdefined(player.spectator_respawn))
    {
        println(
            "^1[PinteMod] Native spectator respawn data unavailable for " +
            player.name
        );
        player iprintln(ezz_admin_localization::text(player, "latejoin_not_ready"));
        return;
    }

    player zm::spectator_respawn_player();

    wait 0.1;

    if (isdefined(player.sessionstate) &&
        player.sessionstate != "spectator")
    {
        ezz_admin_commands::commands_mark_gameplay_command(
            "admin respawn",
            player.name
        );

        println(
            "^2[PinteMod] Spectator respawned: " + player.name
        );
        player iprintln(ezz_admin_localization::text(player, "latejoin_success"));

        pause_broadcast_localized_parts(
            "",
            "^2[PinteMod]^7 " + player.name,
            "community_player_joined_suffix",
            "",
            ""
        );
    }
    else
    {
        println(
            "^1[PinteMod] Native spectator respawn did not complete"
        );
        player iprintln(
            ezz_admin_localization::text(player, "latejoin_failed")
        );
    }
}


// ------------------------------------------------------------
// Detour: public late-join guard
// ------------------------------------------------------------

detour custom_scripts\ezz_admin_community::cmd_ezzjoin(args)
{
    ezz_admin_community::community_apply_defaults();

    if (!level.pintemod_late_join_enabled)
    {
        println("^3[PinteMod]^7 Late-join spawn is disabled");
        return;
    }

    if (args.size < 1)
    {
        println(
            "^5[PinteMod]^7 Usage: ezzjoin " +
            "<PlayerName|BOIII_XUID|ClientNumber>"
        );
        return;
    }

    player =
        ezz_admin_community::community_find_player(args[0]);

    if (!isdefined(player))
    {
        println("^1[PinteMod] Player not found: " + args[0]);
        return;
    }

    if (level.pintemod_pause_active &&
        level.pintemod_pause_block_spectator_spawns)
    {
        player iprintln(
            ezz_admin_localization::text(player, "pause_respawn_blocked")
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=pause-active | round=" +
            ezz_admin_community::community_get_round()
        );

        return;
    }

    ezz_admin_community::community_log_action(
        "LATE_JOIN_ATTEMPT",
        player.name,
        "xuid=" +
        ezz_admin_community::community_get_xuid(player) +
        " | round=" +
        ezz_admin_community::community_get_round()
    );

    if (!isdefined(player.pintemod_presence_ready) ||
        !player.pintemod_presence_ready)
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_identity"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            "reason=identity-unavailable"
        );
        return;
    }

    ezz_admin_community::community_refresh_late_join_eligibility(
        player,
        "command-refresh"
    );

    if (player.pintemod_late_join_normal_death)
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_normal_death"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            ezz_admin_community::community_late_join_state_details(
                player,
                "normal-death"
            )
        );
        return;
    }

    if (!player.pintemod_late_join_eligible ||
        player.pintemod_late_join_consumed)
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_not_eligible"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            ezz_admin_community::community_late_join_state_details(
                player,
                "not-eligible"
            )
        );
        return;
    }

    if (!isdefined(player.sessionstate) ||
        player.sessionstate != "spectator")
    {
        player.pintemod_late_join_eligible = false;
        player.pintemod_late_join_consumed = true;
        player.pintemod_has_been_active = true;

        ezz_admin_community::community_presence_sync_from_player(
            player
        );

        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_already_active"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            ezz_admin_community::community_late_join_state_details(
                player,
                "already-active"
            )
        );
        return;
    }

    if (!isdefined(player.spectator_respawn))
    {
        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_not_ready"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_REJECTED",
            player.name,
            ezz_admin_community::community_late_join_state_details(
                player,
                "respawn-not-ready"
            )
        );
        return;
    }

    player.pintemod_join_in_progress = true;
    player zm::spectator_respawn_player();

    wait 0.25;

    if (isdefined(player.sessionstate) &&
        player.sessionstate != "spectator")
    {
        player.pintemod_late_join_eligible = false;
        player.pintemod_late_join_consumed = true;
        player.pintemod_late_join_spawned = true;
        player.pintemod_has_been_active = true;
        player.pintemod_join_in_progress = false;

        ezz_admin_community::community_presence_sync_from_player(
            player
        );

        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_success"
            )
        );

        pause_broadcast_localized_parts(
            "",
            "^2[PinteMod]^7 " + player.name,
            "community_player_joined_suffix",
            "",
            ""
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_SUCCESS",
            player.name,
            "map=" +
            ezz_admin_community::community_get_map_name() +
            " | round=" +
            ezz_admin_community::community_get_round()
        );
    }
    else
    {
        player.pintemod_join_in_progress = false;

        player iprintln(
            ezz_admin_localization::text(
                player,
                "latejoin_failed"
            )
        );

        ezz_admin_community::community_log_action(
            "LATE_JOIN_FAILED",
            player.name,
            ezz_admin_community::community_late_join_state_details(
                player,
                "respawn-verification"
            )
        );
    }
}
