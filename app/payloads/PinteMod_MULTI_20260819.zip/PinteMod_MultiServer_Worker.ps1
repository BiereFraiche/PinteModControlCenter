param(
    [Parameter(Mandatory=$true)]
    [string]$InstanceId,

    [string]$DisplayName = "",

    [Parameter(Mandatory=$true)]
    [string]$ServerRoot,

    [string]$ServerAddress = "127.0.0.1",

    [Parameter(Mandatory=$true)]
    [int]$ServerPort,

    [string]$SharedSecretPath = "",

    [switch]$LaunchBanService,
    [switch]$LaunchGeoIP,
    [switch]$DisableSupervisorHeartbeat,

    [int]$StartupGraceSeconds = 90
)

$ErrorActionPreference = 'Stop'
# SERVER_RETURN_FIX_v2 preserved: worker stays alive indefinitely after confirmed BOIII loss.
# HEARTBEAT_IO_FIX_v2: PS5.1/.NET-compatible heartbeat replacement + non-fatal recovery.
# SERVICE_ADOPTION_FIX_v3: adopt existing per-instance Ban/GeoIP runtime processes after Worker restart.

function Get-SafeId {
    param([string]$Value)
    $safe = ([string]$Value).Trim() -replace '[^A-Za-z0-9_.-]', '_'
    if ([string]::IsNullOrWhiteSpace($safe)) {
        throw 'Invalid or empty InstanceId.'
    }
    return $safe
}

function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-Utf8NoBom {
    param([string]$Path, [string]$Text)
    [System.IO.File]::WriteAllText(
        $Path,
        $Text,
        [System.Text.UTF8Encoding]::new($false)
    )
}

function Write-JsonAtomic {
    param([string]$Path, $Value)

    $parent = Split-Path -Parent $Path
    Ensure-Directory $parent

    # Keep the staging file beside the destination so File.Replace stays on
    # the same volume. Include PID to avoid stale/colliding .tmp names.
    $temp = "$Path.tmp.$PID"
    $json = $Value | ConvertTo-Json -Depth 8 -Compress

    try {
        Write-Utf8NoBom -Path $temp -Text $json
        [void](Get-Content -LiteralPath $temp -Raw -ErrorAction Stop |
            ConvertFrom-Json -ErrorAction Stop)

        # Windows PowerShell 5.1 Move-Item -Force can intermittently throw
        # "Cannot create a file when that file already exists" when replacing
        # an existing heartbeat. File.Replace is reliable on the same volume,
        # but .NET Framework on the target host requires a valid backup path
        # instead of $null for the 4-argument overload.
        $backup = "$Path.bak.$PID"

        for ($attempt = 1; $attempt -le 5; $attempt++) {
            try {
                if (Test-Path -LiteralPath $Path -PathType Leaf) {
                    Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
                    [System.IO.File]::Replace($temp, $Path, $backup, $true)
                    Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
                }
                else {
                    Move-Item -LiteralPath $temp -Destination $Path -Force
                }

                return
            }
            catch [System.IO.IOException] {
                if ($attempt -ge 5) {
                    throw
                }

                Start-Sleep -Milliseconds (40 * $attempt)
            }
        }
    }
    finally {
        if (Test-Path -LiteralPath $temp -PathType Leaf) {
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        }

        if (Get-Variable -Name backup -Scope Local -ErrorAction SilentlyContinue) {
            if (Test-Path -LiteralPath $backup -PathType Leaf) {
                Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

function Write-SupervisorLog {
    param([string]$Level, [string]$Message)

    $safeMessage = (([string]$Message -replace '[\r\n]+', ' ').Trim())
    $line = "[{0}][{1}][{2}] {3}" -f `
        (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),
        $script:InstanceToken,
        ([string]$Level).ToUpperInvariant(),
        $safeMessage

    Add-Content -LiteralPath $script:SupervisorLogPath -Value $line -Encoding UTF8
}

function Write-SupervisorHeartbeat {
    param(
        [string]$State = 'monitoring',
        [string]$LastErrorCode = ''
    )

    if ($DisableSupervisorHeartbeat) {
        return
    }

    $script:HeartbeatSequence++
    $value = [ordered]@{
        schema_version = 1
        tool = 'supervisor'
        version = '2.1.1-multi'
        instance_id = $script:InstanceToken
        state = $State
        sequence = $script:HeartbeatSequence
        updated_utc = [DateTime]::UtcNow.ToString('o')
        server_port = $ServerPort
        last_error_code = $LastErrorCode
        privacy = 'No RCON password or player IP'
    }

    try {
        Write-JsonAtomic -Path $script:SupervisorHeartbeatPath -Value $value

        if ($script:SupervisorHeartbeatWriteFailed) {
            $script:SupervisorHeartbeatWriteFailed = $false
            Write-SupervisorLog -Level 'INFO' -Message 'Supervisor heartbeat write recovered.'
        }
    }
    catch {
        # A transient heartbeat I/O collision must never kill the Worker and,
        # by consequence, Ban/GeoIP. Log once per failure streak and continue.
        if (-not $script:SupervisorHeartbeatWriteFailed) {
            $script:SupervisorHeartbeatWriteFailed = $true
            Write-SupervisorLog -Level 'WARN' -Message (
                'Supervisor heartbeat write failed; worker remains active. ' +
                $_.Exception.Message
            )
        }
    }
}

function Get-UdpPortOwnerProcessId {
    param([int]$Port)

    try {
        $endpoint = Get-NetUDPEndpoint -LocalPort $Port -ErrorAction Stop |
            Select-Object -First 1
        if ($endpoint -and [int]$endpoint.OwningProcess -gt 0) {
            return [int]$endpoint.OwningProcess
        }
    }
    catch { }

    try {
        foreach ($line in (netstat -ano -p udp 2>$null)) {
            if ($line -notmatch '^\s*UDP\s+') {
                continue
            }

            $parts = @($line -split '\s+' | Where-Object { $_ -ne '' })
            if ($parts.Count -lt 4) {
                continue
            }

            $localEndpoint = [string]$parts[1]
            $pidText = [string]$parts[$parts.Count - 1]

            if ($localEndpoint -notmatch (':' + [regex]::Escape([string]$Port) + '$')) {
                continue
            }

            $owner = 0
            if ([int]::TryParse($pidText, [ref]$owner) -and $owner -gt 0) {
                return $owner
            }
        }
    }
    catch { }

    return 0
}

function Find-ExistingPowerShellTool {
    param([string]$ScriptPath)

    try {
        # The absolute script path already identifies the server clone because
        # each local server owns its own boiii\tools directory. Do not require
        # -ServerRoot in the command line: the legacy mono-server supervisor
        # intentionally starts bundled tools without forwarding that argument.
        $escapedScript = [regex]::Escape([System.IO.Path]::GetFullPath($ScriptPath))

        return Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
            Where-Object {
                $_.CommandLine -and
                $_.CommandLine -match $escapedScript
            } |
            Select-Object -First 1
    }
    catch {
        return $null
    }
}

function New-PatchedToolCopy {
    param(
        [string]$SourcePath,
        [string]$DestinationPath,
        [string]$OldMutex,
        [string]$NewMutex,
        [switch]$HardenBanAtomicWrite
    )

    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "Required stable tool is missing: $SourcePath"
    }

    $text = [System.IO.File]::ReadAllText($SourcePath)
    if ($text.IndexOf($OldMutex, [System.StringComparison]::Ordinal) -lt 0) {
        throw "Expected mutex marker not found in stable tool: $SourcePath"
    }

    $patched = $text.Replace($OldMutex, $NewMutex)

    if ($HardenBanAtomicWrite) {
        $atomicPattern = '(?ms)^function Write-JsonAtomic \{.*?^\}'
        $atomicRegex = [regex]::new($atomicPattern)
        if (-not $atomicRegex.IsMatch($patched)) {
            throw "Ban Service atomic writer not found in stable tool: $SourcePath"
        }

        $safeAtomic = @'
function Write-JsonAtomic {
    param([string]$Path, $Value)
    $directory = Split-Path -Parent $Path
    Ensure-Directory $directory
    $token = [Guid]::NewGuid().ToString('N')
    $temp = "{0}.tmp.{1}.{2}" -f $Path, $PID, $token
    $backup = "{0}.bak.{1}.{2}" -f $Path, $PID, $token
    $json = $Value | ConvertTo-Json -Depth 10

    try {
        Write-Utf8NoBom -Path $temp -Content $json

        for ($attempt = 1; $attempt -le 5; $attempt++) {
            try {
                if (Test-Path -LiteralPath $Path -PathType Leaf) {
                    Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
                    [System.IO.File]::Replace($temp, $Path, $backup, $true)
                    Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
                }
                else {
                    Move-Item -LiteralPath $temp -Destination $Path -Force
                }
                return
            }
            catch [System.IO.IOException] {
                if ($attempt -ge 5) { throw }
                Start-Sleep -Milliseconds (40 * $attempt)
            }
        }
    }
    finally {
        Remove-Item -LiteralPath $temp, $backup -Force -ErrorAction SilentlyContinue
    }
}
'@
        $patched = $atomicRegex.Replace($patched, $safeAtomic, 1)
    }

    Write-Utf8NoBom -Path $DestinationPath -Text $patched
}

function Prepare-GeoIpRuntime {
    param(
        [string]$SourceToolsRoot,
        [string]$RuntimeRoot,
        [string]$SecretPath,
        [string]$Address,
        [int]$Port
    )

    if ([string]::IsNullOrWhiteSpace($SecretPath) -or
        -not (Test-Path -LiteralPath $SecretPath -PathType Leaf)) {
        throw 'GeoIP requires a local DPAPI RCON secret.'
    }

    $localConfig = Join-Path $SourceToolsRoot 'PinteMod_GeoIP_Bridge.local.json'
    $exampleConfig = Join-Path $SourceToolsRoot 'PinteMod_GeoIP_Bridge.example.json'

    $sourceConfig = ''
    if (Test-Path -LiteralPath $localConfig -PathType Leaf) {
        $sourceConfig = $localConfig
    }
    elseif (Test-Path -LiteralPath $exampleConfig -PathType Leaf) {
        $sourceConfig = $exampleConfig
    }
    else {
        throw 'GeoIP configuration/example is missing from the server tools folder.'
    }

    $config = Get-Content -LiteralPath $sourceConfig -Raw -ErrorAction Stop |
        ConvertFrom-Json -ErrorAction Stop

    $config.server_address = $Address
    $config.server_port = $Port

    $runtimeConfig = Join-Path $RuntimeRoot 'PinteMod_GeoIP_Bridge.local.json'
    Write-Utf8NoBom -Path $runtimeConfig -Text ($config | ConvertTo-Json -Depth 8)

    $runtimeSecret = Join-Path $RuntimeRoot 'PinteMod_GeoIP_Bridge.secret.txt'
    Copy-Item -LiteralPath $SecretPath -Destination $runtimeSecret -Force
}

function Start-ChildPowerShell {
    param(
        [string]$Name,
        [string]$ScriptPath,
        [string[]]$Arguments,
        [string]$OutputLog,
        [string]$ErrorLog
    )

    Remove-Item -LiteralPath $OutputLog, $ErrorLog -Force -ErrorAction SilentlyContinue

    $allArgs = @(
        '-NoLogo',
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        ('"' + $ScriptPath + '"')
    ) + $Arguments

    $process = Start-Process `
        -FilePath 'powershell.exe' `
        -ArgumentList $allArgs `
        -WorkingDirectory (Split-Path -Parent $ScriptPath) `
        -WindowStyle Hidden `
        -RedirectStandardOutput $OutputLog `
        -RedirectStandardError $ErrorLog `
        -PassThru

    Start-Sleep -Milliseconds 1200
    $process.Refresh()

    if ($process.HasExited) {
        $tail = ''
        if (Test-Path -LiteralPath $ErrorLog) {
            $tail = @(Get-Content -LiteralPath $ErrorLog -Tail 8 -ErrorAction SilentlyContinue) -join ' | '
        }
        if ([string]::IsNullOrWhiteSpace($tail) -and (Test-Path -LiteralPath $OutputLog)) {
            $tail = @(Get-Content -LiteralPath $OutputLog -Tail 8 -ErrorAction SilentlyContinue) -join ' | '
        }
        throw "$Name stopped during startup. $tail"
    }

    return $process
}

$script:InstanceToken = Get-SafeId -Value $InstanceId
if ([string]::IsNullOrWhiteSpace($DisplayName)) {
    $DisplayName = $script:InstanceToken
}

if ($ServerPort -lt 1 -or $ServerPort -gt 65535) {
    throw "Invalid server port: $ServerPort"
}

try {
    $script:ServerRoot = [System.IO.Path]::GetFullPath($ServerRoot.Trim('"'))
}
catch {
    throw "Invalid ServerRoot: $ServerRoot"
}

$script:BoiiiRoot = Join-Path $script:ServerRoot 'boiii'
$script:ToolsRoot = Join-Path $script:BoiiiRoot 'tools'

if (-not (Test-Path -LiteralPath $script:BoiiiRoot -PathType Container)) {
    throw "Server root does not contain boiii: $($script:ServerRoot)"
}
if (-not (Test-Path -LiteralPath $script:ToolsRoot -PathType Container)) {
    throw "Server tools folder is missing: $($script:ToolsRoot)"
}

$script:ServerRuntimeRoot = Join-Path $script:ToolsRoot 'runtime'
$script:InstanceRuntimeRoot = Join-Path `
    (Join-Path $script:ServerRuntimeRoot 'multi') `
    $script:InstanceToken

$script:HealthRoot = Join-Path $script:BoiiiRoot 'scriptdata\pintemod\health'
$script:SupervisorHeartbeatPath = Join-Path $script:HealthRoot 'supervisor.json'
$script:SupervisorLogPath = Join-Path $script:ServerRuntimeRoot 'PinteMod_Supervisor.log'
$script:HeartbeatSequence = 0
$script:SupervisorHeartbeatWriteFailed = $false

foreach ($path in @(
    $script:ServerRuntimeRoot,
    $script:InstanceRuntimeRoot,
    $script:HealthRoot
)) {
    Ensure-Directory $path
}

$mutexName = "Global\PinteMod_v2_1_MultiWorker_$($script:InstanceToken)"
$mutex = New-Object System.Threading.Mutex($false, $mutexName)
$mutexOwned = $false

try {
    $mutexOwned = $mutex.WaitOne(0, $false)
}
catch [System.Threading.AbandonedMutexException] {
    $mutexOwned = $true
}

if (-not $mutexOwned) {
    Write-Host "[SKIP] Multi worker already active for $($script:InstanceToken)."
    $mutex.Dispose()
    exit 0
}

$Host.UI.RawUI.WindowTitle = "PinteMod v2.1.1 - Worker [$DisplayName]"
$children = New-Object System.Collections.Generic.List[object]

function Get-TrackedChild {
    param(
        [System.Collections.Generic.List[object]]$Children,
        [string]$Name
    )

    foreach ($child in $Children) {
        if ($child.Name -ne $Name) {
            continue
        }

        $process = Get-Process -Id ([int]$child.ProcessId) -ErrorAction SilentlyContinue
        if ($process) {
            return $child
        }
    }

    return $null
}

function Remove-StoppedTrackedChildren {
    param([System.Collections.Generic.List[object]]$Children)

    for ($i = $Children.Count - 1; $i -ge 0; $i--) {
        $child = $Children[$i]
        $process = Get-Process -Id ([int]$child.ProcessId) -ErrorAction SilentlyContinue
        if (-not $process) {
            $Children.RemoveAt($i)
        }
    }
}

function Stop-OwnedServices {
    param([System.Collections.Generic.List[object]]$Children)

    for ($i = $Children.Count - 1; $i -ge 0; $i--) {
        $child = $Children[$i]

        if (-not $child.Owned) {
            continue
        }

        try {
            $process = Get-Process -Id ([int]$child.ProcessId) -ErrorAction SilentlyContinue
            if ($process) {
                Stop-Process -Id ([int]$child.ProcessId) -Force -ErrorAction SilentlyContinue
                Write-SupervisorLog -Level 'INFO' -Message (
                    "$($child.Name) stopped because BOIII is offline | pid=$($child.ProcessId)"
                )
            }
        }
        catch { }

        $Children.RemoveAt($i)
    }
}

function Ensure-BanService {
    param([System.Collections.Generic.List[object]]$Children)

    if (-not $LaunchBanService) {
        return
    }

    if (Get-TrackedChild -Children $Children -Name 'Ban Service') {
        return
    }

    Remove-StoppedTrackedChildren -Children $Children

    $sourceBan = Join-Path $script:ToolsRoot 'PinteMod_Ban_Service.ps1'
    $runtimeBan = Join-Path $script:InstanceRuntimeRoot 'PinteMod_Ban_Service.multi.ps1'

    # First preserve legacy mono-server compatibility. A stable source-script
    # process is external to this Worker and must not become owned by it.
    $existingBan = Find-ExistingPowerShellTool -ScriptPath $sourceBan

    if ($existingBan) {
        $Children.Add([PSCustomObject]@{
            Name = 'Ban Service'
            ProcessId = [int]$existingBan.ProcessId
            Owned = $false
            StoppedReported = $false
        }) | Out-Null
        Write-SupervisorLog -Level 'INFO' -Message (
            "Existing Ban Service attached | pid=$($existingBan.ProcessId)"
        )
        return
    }

    # A previous Worker can have died while its per-instance child survived.
    # Adopt that exact runtime process instead of spawning a duplicate that
    # immediately loses the instance mutex and kills this Worker startup.
    $existingRuntimeBan = Find-ExistingPowerShellTool -ScriptPath $runtimeBan

    if ($existingRuntimeBan) {
        $Children.Add([PSCustomObject]@{
            Name = 'Ban Service'
            ProcessId = [int]$existingRuntimeBan.ProcessId
            Owned = $true
            StoppedReported = $false
        }) | Out-Null
        Write-SupervisorLog -Level 'INFO' -Message (
            "Existing managed Ban Service adopted | pid=$($existingRuntimeBan.ProcessId)"
        )
        return
    }

    New-PatchedToolCopy `
        -SourcePath $sourceBan `
        -DestinationPath $runtimeBan `
        -OldMutex 'Global\PinteMod_v2_1_BanService' `
        -NewMutex ("Global\PinteMod_v2_1_BanService_" + $script:InstanceToken) `
        -HardenBanAtomicWrite

    $banOut = Join-Path $script:ServerRuntimeRoot 'PinteMod_Ban_Service.out.log'
    $banErr = Join-Path $script:ServerRuntimeRoot 'PinteMod_Ban_Service.error.log'
    $banProcess = Start-ChildPowerShell `
        -Name 'Ban Service' `
        -ScriptPath $runtimeBan `
        -Arguments @('-ServerRoot', ('"' + $script:ServerRoot + '"')) `
        -OutputLog $banOut `
        -ErrorLog $banErr

    $Children.Add([PSCustomObject]@{
        Name = 'Ban Service'
        ProcessId = [int]$banProcess.Id
        Owned = $true
        StoppedReported = $false
    }) | Out-Null
    Write-SupervisorLog -Level 'INFO' -Message "Ban Service started | pid=$($banProcess.Id)"
}

function Ensure-GeoIpBridge {
    param([System.Collections.Generic.List[object]]$Children)

    if (-not $LaunchGeoIP) {
        return
    }

    if (Get-TrackedChild -Children $Children -Name 'GeoIP Bridge') {
        return
    }

    Remove-StoppedTrackedChildren -Children $Children

    $sourceGeo = Join-Path $script:ToolsRoot 'PinteMod_GeoIP_Bridge.ps1'
    $runtimeGeo = Join-Path $script:InstanceRuntimeRoot 'PinteMod_GeoIP_Bridge.multi.ps1'

    $existingGeo = Find-ExistingPowerShellTool -ScriptPath $sourceGeo

    if ($existingGeo) {
        $Children.Add([PSCustomObject]@{
            Name = 'GeoIP Bridge'
            ProcessId = [int]$existingGeo.ProcessId
            Owned = $false
            StoppedReported = $false
        }) | Out-Null
        Write-SupervisorLog -Level 'INFO' -Message (
            "Existing GeoIP Bridge attached | pid=$($existingGeo.ProcessId)"
        )
        return
    }

    $existingRuntimeGeo = Find-ExistingPowerShellTool -ScriptPath $runtimeGeo

    if ($existingRuntimeGeo) {
        $Children.Add([PSCustomObject]@{
            Name = 'GeoIP Bridge'
            ProcessId = [int]$existingRuntimeGeo.ProcessId
            Owned = $true
            StoppedReported = $false
        }) | Out-Null
        Write-SupervisorLog -Level 'INFO' -Message (
            "Existing managed GeoIP Bridge adopted | pid=$($existingRuntimeGeo.ProcessId)"
        )
        return
    }

    Prepare-GeoIpRuntime `
        -SourceToolsRoot $script:ToolsRoot `
        -RuntimeRoot $script:InstanceRuntimeRoot `
        -SecretPath $SharedSecretPath `
        -Address $ServerAddress `
        -Port $ServerPort

    New-PatchedToolCopy `
        -SourcePath $sourceGeo `
        -DestinationPath $runtimeGeo `
        -OldMutex 'Global\PinteMod_v2_1_GeoIPBridge' `
        -NewMutex ("Global\PinteMod_v2_1_GeoIPBridge_" + $script:InstanceToken)

    $geoOut = Join-Path $script:ServerRuntimeRoot 'PinteMod_GeoIP_Bridge.out.log'
    $geoErr = Join-Path $script:ServerRuntimeRoot 'PinteMod_GeoIP_Bridge.error.log'
    $geoProcess = Start-ChildPowerShell `
        -Name 'GeoIP Bridge' `
        -ScriptPath $runtimeGeo `
        -Arguments @(
            '-ServerRoot', ('"' + $script:ServerRoot + '"'),
            '-ServerAddress', ('"' + $ServerAddress + '"'),
            '-ServerPort', [string]$ServerPort
        ) `
        -OutputLog $geoOut `
        -ErrorLog $geoErr

    $Children.Add([PSCustomObject]@{
        Name = 'GeoIP Bridge'
        ProcessId = [int]$geoProcess.Id
        Owned = $true
        StoppedReported = $false
    }) | Out-Null
    Write-SupervisorLog -Level 'INFO' -Message "GeoIP Bridge started | pid=$($geoProcess.Id)"
}

function Ensure-ConfiguredServices {
    param([System.Collections.Generic.List[object]]$Children)

    Ensure-BanService -Children $Children
    Ensure-GeoIpBridge -Children $Children
}

try {
    Write-SupervisorLog -Level 'INFO' -Message (
        "Worker starting | display=$DisplayName | port=$ServerPort | " +
        "ban=$([bool]$LaunchBanService) | geoip=$([bool]$LaunchGeoIP)"
    )

    if (-not $DisableSupervisorHeartbeat) {
        Write-SupervisorHeartbeat -State 'waiting'
    }

    Ensure-ConfiguredServices -Children $children

    $serverProcessId = 0
    $serverProcessMissingSince = $null
    $portTemporarilyMissing = $false
    $serverOfflineConfirmed = $false
    $startedAt = Get-Date
    $lastHeartbeat = [DateTime]::MinValue
    $lastErrorCode = ''

    while ($true) {
        $currentOwner = Get-UdpPortOwnerProcessId -Port $ServerPort

        if ($currentOwner -gt 0) {
            $serverReturned = $serverOfflineConfirmed

            if ($serverProcessId -ne $currentOwner) {
                $serverProcessId = $currentOwner
                Write-SupervisorLog -Level 'INFO' -Message (
                    "BOIII UDP port detected: $ServerPort | pid=$serverProcessId"
                )
            }

            if ($portTemporarilyMissing) {
                Write-SupervisorLog -Level 'INFO' -Message (
                    "BOIII UDP port restored: $ServerPort | pid=$serverProcessId"
                )
            }

            $portTemporarilyMissing = $false
            $serverProcessMissingSince = $null
            $serverOfflineConfirmed = $false
            $lastErrorCode = ''

            if ($serverReturned) {
                Write-SupervisorLog -Level 'INFO' -Message (
                    "BOIII returned on UDP $ServerPort | pid=$serverProcessId | " +
                    "restarting/re-attaching configured services"
                )
                if (-not $DisableSupervisorHeartbeat) {
                    $lastHeartbeat = Get-Date
                    Write-SupervisorHeartbeat -State 'restarting'
                }
                Ensure-ConfiguredServices -Children $children
                Write-SupervisorLog -Level 'INFO' -Message (
                    'Configured services reconciled after BOIII return.'
                )
            }
        }
        elseif ($serverProcessId -gt 0) {
            # BOIII can temporarily unbind/rebind its UDP socket during map
            # loading. Once its PID is known, a missing port alone is not an
            # outage while that process still exists.
            $serverProcess = Get-Process -Id $serverProcessId -ErrorAction SilentlyContinue

            if ($serverProcess) {
                if (-not $portTemporarilyMissing) {
                    $portTemporarilyMissing = $true
                    Write-SupervisorLog -Level 'INFO' -Message (
                        "BOIII UDP port temporarily unavailable during runtime: $ServerPort | " +
                        "pid=$serverProcessId | keeping services alive"
                    )
                }
                $serverProcessMissingSince = $null
            }
            else {
                if ($null -eq $serverProcessMissingSince) {
                    $serverProcessMissingSince = Get-Date
                    Write-SupervisorLog -Level 'WARN' -Message (
                        "BOIII process disappeared: pid=$serverProcessId | " +
                        "waiting up to 20s for a replacement on UDP $ServerPort"
                    )
                }
                elseif (((Get-Date) - $serverProcessMissingSince).TotalSeconds -ge 20) {
                    Write-SupervisorLog -Level 'WARN' -Message (
                        "BOIII process remained absent for 20s | " +
                        "stopping owned services but KEEPING worker alive"
                    )

                    Stop-OwnedServices -Children $children

                    $serverProcessId = 0
                    $serverProcessMissingSince = $null
                    $portTemporarilyMissing = $false
                    $serverOfflineConfirmed = $true
                    $lastErrorCode = ''

                    Write-SupervisorLog -Level 'INFO' -Message (
                        "Worker is waiting for BOIII to return on UDP $ServerPort."
                    )
                }
            }
        }
        elseif ($serverOfflineConfirmed) {
            # Intentional steady state: BOIII is down, but the worker remains
            # alive indefinitely so a later BOIII process can be adopted and
            # the owned services can be restored automatically.
            $lastErrorCode = ''
        }
        elseif (((Get-Date) - $startedAt).TotalSeconds -gt $StartupGraceSeconds) {
            $lastErrorCode = 'SERVER_PORT_NOT_BOUND'
        }

        foreach ($child in $children) {
            $process = Get-Process -Id ([int]$child.ProcessId) -ErrorAction SilentlyContinue
            if (-not $process -and -not $child.StoppedReported) {
                $child.StoppedReported = $true
                $code = (($child.Name -replace '[^A-Za-z0-9]+', '_').ToUpperInvariant() + '_STOPPED')
                $lastErrorCode = $code
                Write-SupervisorLog -Level 'ERROR' -Message "$($child.Name) stopped unexpectedly."
            }
        }

        if (-not $DisableSupervisorHeartbeat -and
            ((Get-Date) - $lastHeartbeat).TotalSeconds -ge 2) {
            $lastHeartbeat = Get-Date

            if (-not [string]::IsNullOrWhiteSpace($lastErrorCode)) {
                Write-SupervisorHeartbeat -State 'error' -LastErrorCode $lastErrorCode
            }
            elseif ($null -ne $serverProcessMissingSince) {
                Write-SupervisorHeartbeat -State 'restarting'
            }
            elseif ($serverProcessId -gt 0) {
                Write-SupervisorHeartbeat -State 'monitoring'
            }
            else {
                Write-SupervisorHeartbeat -State 'waiting'
            }
        }

        Start-Sleep -Seconds 2
    }
}
catch {
    Write-SupervisorLog -Level 'ERROR' -Message $_.Exception.Message
    try {
        Write-SupervisorHeartbeat -State 'error' -LastErrorCode 'WORKER_ERROR'
    }
    catch { }
    throw
}
finally {
    foreach ($child in $children) {
        if (-not $child.Owned) {
            continue
        }

        try {
            $process = Get-Process -Id ([int]$child.ProcessId) -ErrorAction SilentlyContinue
            if ($process) {
                Stop-Process -Id ([int]$child.ProcessId) -Force -ErrorAction SilentlyContinue
            }
        }
        catch { }
    }

    try {
        Write-SupervisorHeartbeat -State 'stopped'
    }
    catch { }

    try {
        Write-SupervisorLog -Level 'INFO' -Message 'Worker stopped.'
    }
    catch { }

    if ($mutex) {
        try {
            if ($mutexOwned) {
                $mutex.ReleaseMutex() | Out-Null
            }
        }
        catch { }
        $mutex.Dispose()
    }
}
