@echo off
setlocal
cd /d "%~dp0"
echo.
echo ===== PINTE MOD MULTI - AUDIT =====
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cleanup_PinteMod_Multi_Safe.ps1"
if errorlevel 1 goto :error
echo.
choice /C ON /N /M "Appliquer ce nettoyage ? [O/N] "
if errorlevel 2 goto :done
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cleanup_PinteMod_Multi_Safe.ps1" -Apply
if errorlevel 1 goto :error
:done
echo.
echo Termine.
pause
exit /b 0
:error
echo.
echo Le nettoyage a rencontre une erreur. Aucun secret DPAPI ne doit etre supprime manuellement.
pause
exit /b 1
