// ============================================================
// PinteMod — Heathcliff Messages v0.1
// Fichier : ezz_admin_heathcliff.gsc
//
// Message opérateur volontaire uniquement.
// Aucun message automatique, aucun historique en jeu, aucun HUD custom.
// ============================================================

#using custom_scripts\ezz_admin_storage;

function heathcliff_log_operator(message)
{
    if (!isdefined(message) || message == "")
        return;

    if (!ezz_admin_storage::append_managed_log(
        "pintemod/logs/operator.log",
        "ANNOUNCE | " + message + "\n"
    ))
    {
        println("^1[PinteMod][Heathcliff]^7 ANNOUNCE_LOG_WRITE_FAILED");
    }
}

function heathcliff_join_args(args)
{
    message = "";

    for (i = 0; i < args.size; i++)
    {
        if (message != "")
            message = message + " ";

        message = message + args[i];
    }

    return message;
}

function heathcliff_display(message)
{
    self endon("disconnect");

    // Native BO3 iprintln only.
    // Three displays spaced by 2 seconds leave enough time to read
    // without creating a persistent HUD element.
    for (repeat = 0; repeat < 3; repeat++)
    {
        self iprintln("^3Heathcliff:^7 " + message);

        if (repeat < 2)
            wait 2;
    }
}

function cmd_ezzannounce(args)
{
    if (!isdefined(args) || args.size <= 0)
    {
        println("^3[PinteMod]^7 Usage: ezzannounce <message>");
        return;
    }

    message = heathcliff_join_args(args);

    if (!isdefined(message) || message == "")
    {
        println("^1[PinteMod]^7 Message is empty.");
        return;
    }

    // Keep operator messages compact and safe for the in-game display.
    max_length = 180;

    if (message.size > max_length)
    {
        message = GetSubStr(message, 0, max_length);
        println(
            "^3[PinteMod][Heathcliff]^7 Message truncated to " +
            max_length + " characters."
        );
    }

    println("^5[PinteMod][Heathcliff]^7 " + message);
    heathcliff_log_operator(message);

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (isdefined(player))
            player thread heathcliff_display(message);
    }
}

autoexec function init()
{
    addcommand("ezzannounce", ::cmd_ezzannounce);

    println("^5[PinteMod]^7 Heathcliff Messages v0.1 loaded");
}
