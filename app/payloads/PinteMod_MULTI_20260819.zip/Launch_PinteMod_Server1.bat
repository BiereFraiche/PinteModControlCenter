@echo off
setlocal
cd /d "%~dp0"
rem ------------------------------------------------------------
rem PinteMod RecordHub - demarrage automatique, non bloquant.
rem Le mutex du Hub empeche tout doublon si plusieurs launchers
rem sont utilises successivement (All-in-One / Server1 / 2 / 3).
rem ------------------------------------------------------------
set "PINTEMOD_HUB_PS=%~dp0PinteMod_RecordHub.ps1"
set "PINTEMOD_HUB_CFG=%~dp0START_3_ALL_IN_ONE.local.json"
if not exist "%PINTEMOD_HUB_CFG%" set "PINTEMOD_HUB_CFG=%~dp0PinteMod_MultiServer.local.json"
if exist "%PINTEMOD_HUB_PS%" if exist "%PINTEMOD_HUB_CFG%" (
    start "" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%PINTEMOD_HUB_PS%" -ConfigPath "%PINTEMOD_HUB_CFG%" -HubRoot "%~dp0PinteModRecordHub" -IntervalSeconds 10
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PinteMod_Launch_SingleInstance.ps1" -InstanceName Server1
set "rc=%errorlevel%"
if not "%rc%"=="0" (
    echo.
    echo PinteMod Server1 launcher finished with code %rc%.
    pause
)
endlocal
