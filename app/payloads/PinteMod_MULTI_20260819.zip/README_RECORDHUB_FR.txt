PINTE MOD RECORDHUB v1 — DEPLOIEMENT 3 SERVEURS

OBJECTIF
- Server1/2/3 continuent d'ecrire leurs records LOCAUX normalement.
- RecordHub lit uniquement les Top 5 locaux valides.
- RecordHub calcule un Top 5 GLOBAL pour les records de manches et Easter Egg.
- Les fichiers officiels locaux ne sont JAMAIS remplaces par le Hub.
- Le Hub publie ses snapshots sous pintemod/global_records_v1/.
- Les deux GSC fournis preferent le snapshot GLOBAL pour l'affichage joueur,
  avec retour automatique au record LOCAL si aucun snapshot global valide n'existe.

SECURITE / RESILIENCE
- Aucun RCON, aucun port, aucun web, aucun secret.
- Aucune recherche recursive d'installation.
- Le Hub lit uniquement les server_root explicites du JSON MultiServer local.
- Un seul writer central grace a un mutex.
- Ecritures temporaires + remplacement atomique quand possible.
- Cache du dernier snapshot source valide par serveur.
- Un serveur indisponible n'efface pas ses derniers records valides.
- XUID complet conserve uniquement dans les donnees privees de record; jamais dans RecordHub.log.

FICHIERS A DEPLOYER
1. Dans le dossier MultiServer, a cote de START_3_ALL_IN_ONE.local.json :
   - PinteMod_RecordHub.ps1
   - Launch_PinteMod_RecordHub.bat
   - TEST_RecordHub_Once.bat
   - Stop_PinteMod_RecordHub.bat

2. Deploiement GSC recommande :
   - double-cliquer DEPLOY_RecordHub_GSC_3_SERVERS.bat apres avoir arrete les serveurs.
   - le BAT sauvegarde puis remplace uniquement ezz_admin_ranks.gsc et ezz_admin_ee_records.gsc.

VALIDATION CONSEILLEE
A. Arreter completement les 3 serveurs avant remplacement des GSC.
B. Remplacer les deux GSC sur les 3 serveurs.
C. Relancer les serveurs normalement.
D. Double-cliquer TEST_RecordHub_Once.bat.
E. Verifier qu'il affiche [OK] et que PinteModRecordHub/hub_status.json est state=OK ou DEGRADED explicable.
F. En jeu, ouvrir les Records : le titre contient GLOBAL si le snapshot a ete lu.
G. Si tout est bon, double-cliquer Launch_PinteMod_RecordHub.bat.

ARRET
- Double-cliquer Stop_PinteMod_RecordHub.bat.

IMPORTANT
- Ne pas mettre PinteModRecordHub/ dans Git public : les snapshots internes contiennent les BOIII_XUID necessaires a l'identite des records.
- Le Hub ne centralise PAS les profils/ranks personnels : uniquement les Top 5 records de manches et EE.
- Les detecteurs EE et leur activation OFFICIAL restent locaux et valides map par map.
