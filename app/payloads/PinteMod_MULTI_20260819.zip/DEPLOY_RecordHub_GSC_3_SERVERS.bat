@echo off
setlocal
cd /d "%~dp0"
set "CFG=%~dp0START_3_ALL_IN_ONE.local.json"
if not exist "%CFG%" set "CFG=%~dp0PinteMod_MultiServer.local.json"
if not exist "%CFG%" (
  echo [ERREUR] Configuration locale MultiServer introuvable.
  pause
  exit /b 1
)
echo.
echo Ce deploiement remplace UNIQUEMENT :
echo - ezz_admin_ranks.gsc
echo - ezz_admin_ee_records.gsc
echo sur les serveurs locaux actifs du JSON MultiServer.
echo Un backup est cree avant chaque remplacement.
echo.
choice /C ON /N /M "Les serveurs sont-ils completement arretes ? [O/N] "
if errorlevel 2 exit /b 1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy_PinteMod_RecordHub.ps1" -ConfigPath "%CFG%" -PackageDir "%~dp0"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo [OK] GSC RecordHub deployes. Relance maintenant les serveurs normalement.
) else (
  echo [ERREUR] Deploiement incomplet. Consulte les lignes ci-dessus.
)
pause
exit /b %RC%
