﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigPath,

    [string]$HubRoot = "",

    [ValidateRange(5, 3600)]
    [int]$IntervalSeconds = 10,

    [switch]$Once
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:HubSchema = 1
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:Mutex = $null
$script:MutexOwned = $false

function Get-UtcStamp {
    return [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
}

function Ensure-Directory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-TextAtomic {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text
    )

    $directory = Split-Path -Parent $Path
    Ensure-Directory -Path $directory
    $temp = $Path + '.tmp.' + $PID + '.' + [Guid]::NewGuid().ToString('N')
    $backup = $Path + '.bak'

    try {
        [System.IO.File]::WriteAllText($temp, $Text, $script:Utf8NoBom)

        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            try {
                [System.IO.File]::Replace($temp, $Path, $backup, $true)
                if (Test-Path -LiteralPath $backup -PathType Leaf) {
                    Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
                }
            }
            catch {
                Copy-Item -LiteralPath $temp -Destination $Path -Force
                Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            }
        }
        else {
            Move-Item -LiteralPath $temp -Destination $Path -Force
        }
    }
    finally {
        if (Test-Path -LiteralPath $temp -PathType Leaf) {
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        }
    }
}

function Write-JsonAtomic {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)]$Value
    )
    $json = $Value | ConvertTo-Json -Depth 12 -Compress
    Write-TextAtomic -Path $Path -Text $json
}

function Write-HubLog {
    param(
        [Parameter(Mandatory = $true)][string]$Level,
        [Parameter(Mandatory = $true)][string]$Event,
        [string]$Details = ''
    )

    if ([string]::IsNullOrWhiteSpace($Details)) {
        $line = '[' + (Get-UtcStamp) + '] ' + $Level + ' | ' + $Event
    }
    else {
        $line = '[' + (Get-UtcStamp) + '] ' + $Level + ' | ' + $Event + ' | ' + $Details
    }

    $logPath = Join-Path $script:HubRoot 'RecordHub.log'
    Ensure-Directory -Path (Split-Path -Parent $logPath)
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

function Get-PropValue {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) { return $Default }
    if ($null -eq $property.Value) { return $Default }
    return $property.Value
}

function Get-IntValue {
    param($Object, [string]$Name, [int]$Default = 0)
    $value = Get-PropValue -Object $Object -Name $Name -Default $Default
    $parsed = 0
    if ([int]::TryParse([string]$value, [ref]$parsed)) { return $parsed }
    return $Default
}

function Get-StringValue {
    param($Object, [string]$Name, [string]$Default = '')
    $value = Get-PropValue -Object $Object -Name $Name -Default $Default
    if ($null -eq $value) { return $Default }
    return [string]$value
}

function Read-JsonFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    try {
        $raw = [System.IO.File]::ReadAllText($Path)
        if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
        return $raw | ConvertFrom-Json
    }
    catch {
        return $null
    }
}

function Get-SafeServerId {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return 'server' }
    $safe = [regex]::Replace($Value, '[^A-Za-z0-9_.-]', '_')
    if ($safe.Length -gt 48) { $safe = $safe.Substring(0, 48) }
    if ([string]::IsNullOrWhiteSpace($safe)) { return 'server' }
    return $safe
}

function Test-MapFileName {
    param([string]$Name)
    return $Name -match '^zm_[A-Za-z0-9_\-]+\.json$'
}

function Test-RoundMapJson {
    param($Json, [string]$ExpectedMap)
    if ($null -eq $Json) { return $false }
    if ((Get-IntValue $Json 'schema_version' 0) -ne 4) { return $false }
    if ((Get-StringValue $Json 'identity_kind' '') -ne 'BOIII_XUID') { return $false }
    if ((Get-StringValue $Json 'map' '') -ne $ExpectedMap) { return $false }
    return $true
}

function Test-EeMapJson {
    param($Json, [string]$ExpectedMap)
    if ($null -eq $Json) { return $false }
    if ((Get-IntValue $Json 'schema_version' 0) -ne 2) { return $false }
    if ((Get-StringValue $Json 'identity_kind' '') -ne 'BOIII_XUID') { return $false }
    if ((Get-StringValue $Json 'mode' '') -ne 'official') { return $false }
    if ((Get-StringValue $Json 'map' '') -ne $ExpectedMap) { return $false }
    return $true
}

function Sync-SourceCacheDirectory {
    param(
        [Parameter(Mandatory = $true)][string]$ServerId,
        [Parameter(Mandatory = $true)][string]$SourceDir,
        [Parameter(Mandatory = $true)][string]$CacheDir,
        [Parameter(Mandatory = $true)][ValidateSet('rounds','ee')][string]$Kind,
        [Parameter(Mandatory = $true)][System.Collections.Generic.List[string]]$Errors
    )

    Ensure-Directory -Path $CacheDir

    if (-not (Test-Path -LiteralPath $SourceDir -PathType Container)) {
        $Errors.Add($ServerId + ':' + $Kind + ':source_unavailable')
        return
    }

    $seen = @{}
    foreach ($file in @(Get-ChildItem -LiteralPath $SourceDir -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        if (-not (Test-MapFileName -Name $file.Name)) { continue }
        $map = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
        $json = Read-JsonFile -Path $file.FullName
        $valid = $false
        if ($Kind -eq 'rounds') { $valid = Test-RoundMapJson -Json $json -ExpectedMap $map }
        else { $valid = Test-EeMapJson -Json $json -ExpectedMap $map }

        if (-not $valid) {
            $Errors.Add($ServerId + ':' + $Kind + ':' + $map + ':invalid_source_kept_last_good')
            continue
        }

        $seen[$file.Name.ToLowerInvariant()] = $true
        $raw = [System.IO.File]::ReadAllText($file.FullName)
        Write-TextAtomic -Path (Join-Path $CacheDir $file.Name) -Text $raw
    }

    # If the source directory is available, deletion is authoritative.
    foreach ($cached in @(Get-ChildItem -LiteralPath $CacheDir -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        if (-not $seen.ContainsKey($cached.Name.ToLowerInvariant())) {
            Remove-Item -LiteralPath $cached.FullName -Force -ErrorAction SilentlyContinue
        }
    }
}

function Add-RoundRecordsFromCache {
    param(
        [string]$ServerId,
        [string]$CacheDir,
        [hashtable]$ByMap
    )

    if (-not (Test-Path -LiteralPath $CacheDir -PathType Container)) { return }

    foreach ($file in @(Get-ChildItem -LiteralPath $CacheDir -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        if (-not (Test-MapFileName -Name $file.Name)) { continue }
        $map = [IO.Path]::GetFileNameWithoutExtension($file.Name)
        $json = Read-JsonFile -Path $file.FullName
        if (-not (Test-RoundMapJson -Json $json -ExpectedMap $map)) { continue }

        if (-not $ByMap.ContainsKey($map)) {
            $ByMap[$map] = New-Object System.Collections.ArrayList
        }

        $display = Get-StringValue $json 'display' $map
        for ($team = 1; $team -le 4; $team++) {
            for ($pos = 1; $pos -le 5; $pos++) {
                $suffix = $team.ToString() + 'p_' + $pos.ToString()
                $round = Get-IntValue $json ('round_' + $suffix) 0
                if ($round -le 0) { continue }
                $seconds = Get-IntValue $json ('seconds_' + $suffix) 0
                $holders = Get-StringValue $json ('holders_' + $suffix) ''
                $xuids = Get-StringValue $json ('holder_xuids_' + $suffix) ''
                $nativeId = Get-StringValue $json ('match_id_' + $suffix) ''
                if ([string]::IsNullOrWhiteSpace($holders) -or [string]::IsNullOrWhiteSpace($xuids)) { continue }
                if ([string]::IsNullOrWhiteSpace($nativeId)) {
                    $nativeId = 'fallback-' + $map + '-' + $team + '-' + $round + '-' + $seconds + '-' + $xuids
                }
                [void]$ByMap[$map].Add([PSCustomObject]@{
                    kind='rounds'; map=$map; display=$display; team=$team; round=$round; seconds=$seconds;
                    holders=$holders; holder_xuids=$xuids; source_server=$ServerId; source_id=$nativeId
                })
            }
        }
    }
}

function Add-EeRecordsFromCache {
    param(
        [string]$ServerId,
        [string]$CacheDir,
        [hashtable]$ByMap
    )

    if (-not (Test-Path -LiteralPath $CacheDir -PathType Container)) { return }

    foreach ($file in @(Get-ChildItem -LiteralPath $CacheDir -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        if (-not (Test-MapFileName -Name $file.Name)) { continue }
        $map = [IO.Path]::GetFileNameWithoutExtension($file.Name)
        $json = Read-JsonFile -Path $file.FullName
        if (-not (Test-EeMapJson -Json $json -ExpectedMap $map)) { continue }

        if (-not $ByMap.ContainsKey($map)) {
            $ByMap[$map] = New-Object System.Collections.ArrayList
        }

        $display = Get-StringValue $json 'display' $map
        for ($team = 1; $team -le 4; $team++) {
            for ($pos = 1; $pos -le 5; $pos++) {
                $suffix = $team.ToString() + 'p_' + $pos.ToString()
                $seconds = Get-IntValue $json ('seconds_' + $suffix) 0
                if ($seconds -le 0) { continue }
                $holders = Get-StringValue $json ('holders_' + $suffix) ''
                $xuids = Get-StringValue $json ('holder_xuids_' + $suffix) ''
                $nativeId = Get-StringValue $json ('run_id_' + $suffix) ''
                $round = Get-IntValue $json ('round_' + $suffix) 0
                $source = Get-StringValue $json ('source_' + $suffix) ''
                if ([string]::IsNullOrWhiteSpace($holders) -or [string]::IsNullOrWhiteSpace($xuids)) { continue }
                if ([string]::IsNullOrWhiteSpace($nativeId)) {
                    $nativeId = 'fallback-' + $map + '-' + $team + '-' + $seconds + '-' + $xuids
                }
                [void]$ByMap[$map].Add([PSCustomObject]@{
                    kind='ee'; map=$map; display=$display; team=$team; round=$round; seconds=$seconds;
                    holders=$holders; holder_xuids=$xuids; source=$source;
                    source_server=$ServerId; source_id=$nativeId
                })
            }
        }
    }
}

function Get-UniqueRecords {
    param([object[]]$Records)
    $seen = @{}
    $result = New-Object System.Collections.ArrayList
    foreach ($record in @($Records)) {
        $key = ([string]$record.source_server) + '|' + ([string]$record.source_id) + '|' + ([string]$record.team)
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = $true
        [void]$result.Add($record)
    }
    return @($result)
}

function New-RoundGlobalJson {
    param([string]$Map, [object[]]$Records, [int]$ServerCount, [string]$GeneratedAt)
    $display = $Map
    if (@($Records).Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]$Records[0].display)) {
        $display = [string]$Records[0].display
    }

    $o = [ordered]@{
        schema_version='4'; identity_kind='BOIII_XUID'; map=$Map; display=$display; next_run_id='1';
        hub_schema_version='1'; hub_scope='GLOBAL'; hub_generated_at_utc=$GeneratedAt; hub_server_count=[string]$ServerCount
    }

    for ($team = 1; $team -le 4; $team++) {
        $teamRecords = @(Get-UniqueRecords -Records @($Records | Where-Object { $_.team -eq $team }))
        $sorted = @($teamRecords | Sort-Object -Property `
            @{Expression={$_.round};Descending=$true}, `
            @{Expression={if ($_.seconds -le 0) {[int]::MaxValue} else {$_.seconds}}}, `
            @{Expression={$_.source_server}}, `
            @{Expression={$_.source_id}} | Select-Object -First 5)

        for ($pos = 1; $pos -le 5; $pos++) {
            $suffix = $team.ToString() + 'p_' + $pos.ToString()
            $o['round_' + $suffix] = '0'; $o['seconds_' + $suffix] = '0'; $o['holders_' + $suffix] = ''
            $o['holder_xuids_' + $suffix] = ''; $o['match_id_' + $suffix] = ''; $o['source_server_' + $suffix] = ''
            $o['source_match_id_' + $suffix] = ''
            if ($pos -le $sorted.Count) {
                $r = $sorted[$pos - 1]
                $o['round_' + $suffix] = [string]$r.round
                $o['seconds_' + $suffix] = [string]$r.seconds
                $o['holders_' + $suffix] = [string]$r.holders
                $o['holder_xuids_' + $suffix] = [string]$r.holder_xuids
                $o['match_id_' + $suffix] = 'hub|' + [string]$r.source_server + '|' + [string]$r.source_id
                $o['source_server_' + $suffix] = [string]$r.source_server
                $o['source_match_id_' + $suffix] = [string]$r.source_id
            }
        }
    }
    return [PSCustomObject]$o
}

function New-EeGlobalJson {
    param([string]$Map, [object[]]$Records, [int]$ServerCount, [string]$GeneratedAt)
    $display = $Map
    if (@($Records).Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]$Records[0].display)) {
        $display = [string]$Records[0].display
    }

    $o = [ordered]@{
        schema_version='2'; storage_generation='2'; identity_kind='BOIII_XUID'; mode='official'; map=$Map; display=$display; next_run_id='1';
        hub_schema_version='1'; hub_scope='GLOBAL'; hub_generated_at_utc=$GeneratedAt; hub_server_count=[string]$ServerCount
    }

    for ($team = 1; $team -le 4; $team++) {
        $teamRecords = @(Get-UniqueRecords -Records @($Records | Where-Object { $_.team -eq $team }))
        $sorted = @($teamRecords | Sort-Object -Property `
            @{Expression={$_.seconds}}, `
            @{Expression={$_.source_server}}, `
            @{Expression={$_.source_id}} | Select-Object -First 5)

        for ($pos = 1; $pos -le 5; $pos++) {
            $suffix = $team.ToString() + 'p_' + $pos.ToString()
            $o['seconds_' + $suffix] = '0'; $o['holders_' + $suffix] = ''; $o['holder_xuids_' + $suffix] = ''
            $o['run_id_' + $suffix] = ''; $o['round_' + $suffix] = '0'; $o['source_' + $suffix] = ''
            $o['source_server_' + $suffix] = ''; $o['source_run_id_' + $suffix] = ''
            if ($pos -le $sorted.Count) {
                $r = $sorted[$pos - 1]
                $o['seconds_' + $suffix] = [string]$r.seconds
                $o['holders_' + $suffix] = [string]$r.holders
                $o['holder_xuids_' + $suffix] = [string]$r.holder_xuids
                $o['run_id_' + $suffix] = 'hub|' + [string]$r.source_server + '|' + [string]$r.source_id
                $o['round_' + $suffix] = [string]$r.round
                $o['source_' + $suffix] = [string]$r.source
                $o['source_server_' + $suffix] = [string]$r.source_server
                $o['source_run_id_' + $suffix] = [string]$r.source_id
            }
        }
    }
    return [PSCustomObject]$o
}

function Remove-StaleJsonFiles {
    param([string]$Directory, [hashtable]$ValidNames)
    Ensure-Directory -Path $Directory
    foreach ($file in @(Get-ChildItem -LiteralPath $Directory -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        if (-not $ValidNames.ContainsKey($file.Name.ToLowerInvariant())) {
            Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue
        }
    }
}

function Invoke-RecordHubSync {
    $errors = New-Object 'System.Collections.Generic.List[string]'
    $generatedAt = Get-UtcStamp
    $config = Read-JsonFile -Path $script:ConfigPath
    if ($null -eq $config) { throw 'Configuration JSON unreadable.' }

    $servers = New-Object System.Collections.ArrayList
    foreach ($server in @($config.servers)) {
        $enabled = [bool](Get-PropValue $server 'enabled' $false)
        $mode = [string](Get-PropValue $server 'mode' '')
        $root = [string](Get-PropValue $server 'server_root' '')
        if (-not $enabled -or $mode -ne 'local' -or [string]::IsNullOrWhiteSpace($root)) { continue }
        $idRaw = [string](Get-PropValue $server 'id' 'server')
        $id = Get-SafeServerId $idRaw
        [void]$servers.Add([PSCustomObject]@{ id=$id; root=$root })
    }

    if ($servers.Count -lt 1) { throw 'No enabled local server roots in configuration.' }

    foreach ($server in @($servers)) {
        $cacheBase = Join-Path (Join-Path $script:HubRoot 'sources') $server.id
        $roundCache = Join-Path $cacheBase 'rounds\maps'
        $eeCache = Join-Path $cacheBase 'easter_eggs\maps'
        $roundSource = Join-Path $server.root 'boiii\scriptdata\pintemod\ranks_v2\maps'
        $eeSource = Join-Path $server.root 'boiii\scriptdata\pintemod\easter_eggs_v2\maps'
        Sync-SourceCacheDirectory -ServerId $server.id -SourceDir $roundSource -CacheDir $roundCache -Kind rounds -Errors $errors
        Sync-SourceCacheDirectory -ServerId $server.id -SourceDir $eeSource -CacheDir $eeCache -Kind ee -Errors $errors
    }

    $roundByMap = @{}
    $eeByMap = @{}
    foreach ($server in @($servers)) {
        $cacheBase = Join-Path (Join-Path $script:HubRoot 'sources') $server.id
        Add-RoundRecordsFromCache -ServerId $server.id -CacheDir (Join-Path $cacheBase 'rounds\maps') -ByMap $roundByMap
        Add-EeRecordsFromCache -ServerId $server.id -CacheDir (Join-Path $cacheBase 'easter_eggs\maps') -ByMap $eeByMap
    }

    $centralRound = Join-Path $script:HubRoot 'central\rounds\maps'
    $centralEe = Join-Path $script:HubRoot 'central\easter_eggs\maps'
    Ensure-Directory $centralRound; Ensure-Directory $centralEe
    $roundNames = @{}; $eeNames = @{}

    foreach ($map in @($roundByMap.Keys | Sort-Object)) {
        $name = $map + '.json'; $roundNames[$name.ToLowerInvariant()] = $true
        $value = New-RoundGlobalJson -Map $map -Records @($roundByMap[$map]) -ServerCount $servers.Count -GeneratedAt $generatedAt
        Write-JsonAtomic -Path (Join-Path $centralRound $name) -Value $value
    }
    foreach ($map in @($eeByMap.Keys | Sort-Object)) {
        $name = $map + '.json'; $eeNames[$name.ToLowerInvariant()] = $true
        $value = New-EeGlobalJson -Map $map -Records @($eeByMap[$map]) -ServerCount $servers.Count -GeneratedAt $generatedAt
        Write-JsonAtomic -Path (Join-Path $centralEe $name) -Value $value
    }
    Remove-StaleJsonFiles -Directory $centralRound -ValidNames $roundNames
    Remove-StaleJsonFiles -Directory $centralEe -ValidNames $eeNames

    $publishedServers = 0
    foreach ($server in @($servers)) {
        $boiii = Join-Path $server.root 'boiii'
        if (-not (Test-Path -LiteralPath $boiii -PathType Container)) {
            $errors.Add($server.id + ':publish:server_root_unavailable')
            continue
        }
        $destRound = Join-Path $server.root 'boiii\scriptdata\pintemod\global_records_v1\rounds\maps'
        $destEe = Join-Path $server.root 'boiii\scriptdata\pintemod\global_records_v1\easter_eggs\maps'
        Ensure-Directory $destRound; Ensure-Directory $destEe

        foreach ($file in @(Get-ChildItem -LiteralPath $centralRound -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
            Write-TextAtomic -Path (Join-Path $destRound $file.Name) -Text ([IO.File]::ReadAllText($file.FullName))
        }
        foreach ($file in @(Get-ChildItem -LiteralPath $centralEe -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
            Write-TextAtomic -Path (Join-Path $destEe $file.Name) -Text ([IO.File]::ReadAllText($file.FullName))
        }
        Remove-StaleJsonFiles -Directory $destRound -ValidNames $roundNames
        Remove-StaleJsonFiles -Directory $destEe -ValidNames $eeNames
        $publishedServers++
    }

    $status = [ordered]@{
        schema_version='1'; state='OK'; generated_at_utc=$generatedAt;
        configured_local_servers=[string]$servers.Count; published_servers=[string]$publishedServers;
        round_maps=[string]$roundByMap.Count; easter_egg_maps=[string]$eeByMap.Count;
        errors=@($errors)
    }
    if ($errors.Count -gt 0) { $status.state = 'DEGRADED' }
    Write-JsonAtomic -Path (Join-Path $script:HubRoot 'hub_status.json') -Value ([PSCustomObject]$status)
    Write-HubLog -Level 'INFO' -Event 'SYNC' -Details ('servers=' + $servers.Count + ' published=' + $publishedServers + ' round_maps=' + $roundByMap.Count + ' ee_maps=' + $eeByMap.Count + ' errors=' + $errors.Count)

    return [PSCustomObject]@{ Servers=$servers.Count; Published=$publishedServers; RoundMaps=$roundByMap.Count; EeMaps=$eeByMap.Count; Errors=$errors.Count }
}

try {
    $script:ConfigPath = [IO.Path]::GetFullPath($ConfigPath.Trim('"'))
    if (-not (Test-Path -LiteralPath $script:ConfigPath -PathType Leaf)) { throw 'Configuration file not found.' }
    if ([string]::IsNullOrWhiteSpace($HubRoot)) { $HubRoot = Join-Path $PSScriptRoot 'PinteModRecordHub' }
    $script:HubRoot = [IO.Path]::GetFullPath($HubRoot.Trim('"'))
    Ensure-Directory $script:HubRoot

    $script:Mutex = New-Object -TypeName System.Threading.Mutex -ArgumentList $false, 'Global\PinteMod_RecordHub_v1'
    try { $script:MutexOwned = $script:Mutex.WaitOne(0, $false) } catch [System.Threading.AbandonedMutexException] { $script:MutexOwned = $true }
    if (-not $script:MutexOwned) {
        Write-HubLog -Level 'INFO' -Event 'ALREADY_RUNNING'
        exit 2
    }

    $stopFile = Join-Path $script:HubRoot 'stop.request'
    Remove-Item -LiteralPath $stopFile -Force -ErrorAction SilentlyContinue
    Write-HubLog -Level 'INFO' -Event 'START' -Details ('interval=' + $IntervalSeconds + 's')

    do {
        try {
            $result = Invoke-RecordHubSync
            if ($Once) {
                Write-Host ('RecordHub OK | servers=' + $result.Servers + ' | published=' + $result.Published + ' | round maps=' + $result.RoundMaps + ' | EE maps=' + $result.EeMaps + ' | errors=' + $result.Errors)
            }
        }
        catch {
            Write-HubLog -Level 'ERROR' -Event 'SYNC_FAILED' -Details $_.Exception.Message
            if ($Once) { throw }
        }

        if ($Once) { break }
        for ($i = 0; $i -lt $IntervalSeconds; $i++) {
            if (Test-Path -LiteralPath $stopFile -PathType Leaf) { break }
            Start-Sleep -Seconds 1
        }
        if (Test-Path -LiteralPath $stopFile -PathType Leaf) { break }
    } while ($true)

    Remove-Item -LiteralPath $stopFile -Force -ErrorAction SilentlyContinue
    Write-HubLog -Level 'INFO' -Event 'STOP'
}
finally {
    if ($script:MutexOwned -and $null -ne $script:Mutex) {
        try { $script:Mutex.ReleaseMutex() } catch {}
    }
    if ($null -ne $script:Mutex) { try { $script:Mutex.Dispose() } catch {} }
}
