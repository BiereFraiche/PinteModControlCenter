param(
    [string]$ConfigPath = "",
    [switch]$ValidateOnly
)

$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'PinteMod v2.1.1 - Multi-Server Control v0.3'

function Ensure-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-SafeId {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        throw 'Empty server id.'
    }

    $safe = ($Value.Trim() -replace '[^A-Za-z0-9_.-]', '_')
    if ([string]::IsNullOrWhiteSpace($safe)) {
        throw 'Invalid server id.'
    }

    return $safe
}

function Get-ConfigBool {
    param(
        $Value,
        [bool]$DefaultValue
    )

    if ($null -eq $Value) {
        return $DefaultValue
    }

    return [bool]$Value
}

function Get-ConsoleColor {
    param(
        [string]$RequestedColor,
        [int]$Index
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedColor)) {
        return $RequestedColor.Trim()
    }

    $palette = @(
        'DarkBlue',
        'DarkGreen',
        'DarkMagenta',
        'DarkCyan',
        'DarkRed',
        'DarkGray'
    )

    return $palette[$Index % $palette.Count]
}

function Quote-Argument {
    param([string]$Value)

    if ($null -eq $Value) {
        return '""'
    }

    return '"' + ($Value -replace '"', '\"') + '"'
}

function Resolve-LocalServerRoot {
    param([string]$Root)

    if ([string]::IsNullOrWhiteSpace($Root)) {
        throw 'server_root is required for local mode.'
    }

    try {
        $clean = [System.IO.Path]::GetFullPath($Root.Trim('"'))
    }
    catch {
        throw "Invalid server_root: $Root"
    }

    if (-not (Test-Path -LiteralPath (Join-Path $clean 'boiii') -PathType Container)) {
        throw "server_root does not contain boiii: $clean"
    }

    return $clean
}

function Resolve-ServerLauncher {
    param(
        [string]$ServerRoot,
        [string]$RequestedLauncher
    )

    if ([string]::IsNullOrWhiteSpace($RequestedLauncher)) {
        throw 'server_launcher is required when launch_server=true.'
    }

    $candidate = $RequestedLauncher.Trim('"')
    if (-not [System.IO.Path]::IsPathRooted($candidate)) {
        $candidate = Join-Path $ServerRoot $candidate
    }

    try {
        $candidate = [System.IO.Path]::GetFullPath($candidate)
    }
    catch {
        throw "Invalid server_launcher: $RequestedLauncher"
    }

    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        throw "Server launcher not found: $candidate"
    }

    return $candidate
}

function Test-RemoteDataRoot {
    param([string]$Root)

    if ([string]::IsNullOrWhiteSpace($Root)) {
        return $false
    }

    $clean = $Root.Trim('"')
    if (-not (Test-Path -LiteralPath $clean)) {
        return $false
    }

    return Test-Path -LiteralPath (Join-Path $clean 'logs')
}

function Test-UdpPortBound {
    param([int]$Port)

    try {
        $endpoint = Get-NetUDPEndpoint -LocalPort $Port -ErrorAction Stop |
            Select-Object -First 1
        if ($endpoint) {
            return $true
        }
    }
    catch { }

    try {
        $pattern = '[:\.]' + [regex]::Escape([string]$Port) + '\s'
        $match = netstat -ano -p udp 2>$null |
            Select-String -Pattern $pattern |
            Select-Object -First 1
        return [bool]$match
    }
    catch {
        return $false
    }
}

function Test-NamedMutexExists {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return $false
    }

    $existing = $null
    try {
        $existing = [System.Threading.Mutex]::OpenExisting($Name)
        return $true
    }
    catch [System.Threading.WaitHandleCannotBeOpenedException] {
        return $false
    }
    catch {
        # If Windows reports an access/inspection issue, fail closed and
        # assume the tool already exists rather than spawning a duplicate.
        return $true
    }
    finally {
        if ($existing) {
            try { $existing.Dispose() } catch { }
        }
    }
}

function Test-WorkerMutexExists {
    param([string]$InstanceId)
    return Test-NamedMutexExists -Name ("Global\PinteMod_v2_1_MultiWorker_{0}" -f $InstanceId)
}

function Test-LiveConsoleMutexExists {
    param([string]$InstanceId)
    return Test-NamedMutexExists -Name ("Global\PinteMod_v2_1_LiveConsole_{0}" -f $InstanceId)
}

function Test-RemoteRconMutexExists {
    param([string]$InstanceId)
    return Test-NamedMutexExists -Name ("Global\PinteMod_v2_1_RemoteRCON_{0}" -f $InstanceId)
}


function Stop-AllStandaloneConsoleProcesses {
    $targets = @(
        'PinteMod_LiveConsole.ps1',
        'PinteMod_Remote_RCON.ps1',
        'PinteMod_Remote_Tools_Launcher.ps1',
        'PinteMod_Server_Launcher.ps1',
        'PinteMod_Launch_SingleInstance.ps1'
    )

    $stopped = 0
    try {
        $processes = @(Get-CimInstance Win32_Process -ErrorAction Stop |
            Where-Object { $_.Name -in @('powershell.exe','pwsh.exe') })
    }
    catch {
        return 0
    }

    foreach ($process in $processes) {
        $commandLine = [string]$process.CommandLine
        if ([string]::IsNullOrWhiteSpace($commandLine)) { continue }
        $matched = $false
        foreach ($target in $targets) {
            if ($commandLine.IndexOf($target, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                $matched = $true
                break
            }
        }
        if (-not $matched) { continue }

        try {
            Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction Stop
            $stopped++
        }
        catch { }
    }

    if ($stopped -gt 0) { Start-Sleep -Milliseconds 350 }
    return $stopped
}

function Disable-LegacyStandaloneConsoleConfig {
    param([string]$ServerRoot)

    if ([string]::IsNullOrWhiteSpace($ServerRoot)) { return $false }
    $path = Join-Path $ServerRoot 'boiii\tools\PinteMod_Server_Launcher.local.json'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $false }

    try {
        $config = Get-Content -LiteralPath $path -Raw -ErrorAction Stop |
            ConvertFrom-Json -ErrorAction Stop
        $changed = $false
        if (-not $config.PSObject.Properties['launch_live_console'] -or [bool]$config.launch_live_console) {
            if ($config.PSObject.Properties['launch_live_console']) {
                $config.launch_live_console = $false
            }
            else {
                $config | Add-Member -NotePropertyName launch_live_console -NotePropertyValue $false
            }
            $changed = $true
        }

        if ($changed) {
            $temp = '{0}.manager.{1}.{2}.tmp' -f $path, $PID, ([Guid]::NewGuid().ToString('N'))
            try {
                $json = $config | ConvertTo-Json -Depth 8
                [System.IO.File]::WriteAllText($temp, $json, [System.Text.UTF8Encoding]::new($false))
                [void](Get-Content -LiteralPath $temp -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
                Move-Item -LiteralPath $temp -Destination $path -Force
            }
            finally {
                Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            }
        }
        return $changed
    }
    catch {
        return $false
    }
}

function Stop-LegacyStandaloneTool {
    param(
        [string]$ScriptFileName,
        [string]$InstanceId,
        [string]$ServerRoot,
        [int]$ServerPort
    )

    $stopped = 0
    try {
        $processes = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop)
    }
    catch {
        return 0
    }

    $instancePattern = '(?i)-InstanceId\s+["'']?' + [regex]::Escape($InstanceId) + '["'']?(?:\s|$)'
    $portPattern = '(?i)-ServerPort\s+["'']?' + [regex]::Escape([string]$ServerPort) + '["'']?(?:\s|$)'

    foreach ($process in $processes) {
        $commandLine = [string]$process.CommandLine
        if ([string]::IsNullOrWhiteSpace($commandLine) -or
            $commandLine.IndexOf($ScriptFileName, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
            continue
        }

        $matchesInstance = $commandLine -match $instancePattern
        $matchesPort = $ServerPort -gt 0 -and $commandLine -match $portPattern
        $matchesRoot = -not [string]::IsNullOrWhiteSpace($ServerRoot) -and
            $commandLine.IndexOf($ServerRoot, [System.StringComparison]::OrdinalIgnoreCase) -ge 0

        if (-not ($matchesInstance -or $matchesPort -or $matchesRoot)) {
            continue
        }

        try {
            Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction Stop
            $stopped++
        }
        catch { }
    }

    return $stopped
}

function Stop-ConflictingWorkersForRoot {
    param(
        [string]$ServerRoot,
        [string]$DesiredInstanceId
    )

    if ([string]::IsNullOrWhiteSpace($ServerRoot)) {
        return 0
    }

    $stopped = 0
    try {
        $processes = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop)
    }
    catch {
        return 0
    }

    $desiredPattern = '(?i)-InstanceId\s+["'']?' + [regex]::Escape($DesiredInstanceId) + '["'']?(?:\s|$)'

    foreach ($process in $processes) {
        $commandLine = [string]$process.CommandLine
        if ([string]::IsNullOrWhiteSpace($commandLine) -or
            $commandLine.IndexOf('PinteMod_MultiServer_Worker.ps1', [System.StringComparison]::OrdinalIgnoreCase) -lt 0 -or
            $commandLine.IndexOf($ServerRoot, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
            continue
        }

        # Same desired worker is handled by its named mutex. Only retire a
        # legacy/different instance such as "primary" on the same server root.
        if ($commandLine -match $desiredPattern) {
            continue
        }

        try {
            Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction Stop
            $stopped++
        }
        catch { }
    }

    if ($stopped -gt 0) {
        Start-Sleep -Milliseconds 500
    }
    return $stopped
}

function Test-FreshInstanceSupervisor {
    param(
        [string]$ServerRoot,
        [string]$InstanceId,
        [int]$MaxAgeSeconds = 12
    )

    if ([string]::IsNullOrWhiteSpace($ServerRoot) -or
        [string]::IsNullOrWhiteSpace($InstanceId)) {
        return $false
    }

    $heartbeatPath = Join-Path $ServerRoot 'boiii\scriptdata\pintemod\health\supervisor.json'
    if (-not (Test-Path -LiteralPath $heartbeatPath -PathType Leaf)) {
        return $false
    }

    try {
        $heartbeat = Get-Content -LiteralPath $heartbeatPath -Raw -ErrorAction Stop |
            ConvertFrom-Json -ErrorAction Stop

        if (-not [string]::Equals(
            ([string]$heartbeat.instance_id).Trim(),
            $InstanceId.Trim(),
            [System.StringComparison]::OrdinalIgnoreCase
        )) {
            return $false
        }

        $state = ([string]$heartbeat.state).Trim().ToLowerInvariant()
        if ($state -notin @('waiting','monitoring','restarting','running','connected','online','configured')) {
            return $false
        }

        if ([string]::IsNullOrWhiteSpace([string]$heartbeat.updated_utc)) {
            return $false
        }

        $updated = [DateTimeOffset]::Parse([string]$heartbeat.updated_utc).UtcDateTime
        $ageSeconds = ([DateTime]::UtcNow - $updated).TotalSeconds
        return ($ageSeconds -ge -5 -and $ageSeconds -le $MaxAgeSeconds)
    }
    catch {
        return $false
    }
}

function Ensure-DpapiSecret {
    param(
        [string]$Path,
        [string]$Label
    )

    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        return
    }

    Ensure-Directory (Split-Path -Parent $Path)

    Write-Host ''
    Write-Host ("RCON secret required for: {0}" -f $Label) -ForegroundColor Yellow
    Write-Host 'It is encrypted locally with Windows DPAPI and never written to JSON.' -ForegroundColor DarkGray

    $secure = Read-Host 'RCON password' -AsSecureString
    if ($secure.Length -le 0) {
        throw 'Empty RCON password.'
    }

    $encrypted = $secure | ConvertFrom-SecureString
    [System.IO.File]::WriteAllText(
        $Path,
        $encrypted,
        [System.Text.UTF8Encoding]::new($false)
    )

    Write-Host 'Encrypted local secret created.' -ForegroundColor Green
}

function Start-PowerShellTool {
    param(
        [string]$ScriptPath,
        [string[]]$Arguments,
        [switch]$Hidden,
        [string]$OutputLog = "",
        [string]$ErrorLog = ""
    )

    $allArgs = @(
        '-NoLogo',
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        (Quote-Argument $ScriptPath)
    ) + $Arguments

    $start = @{
        FilePath = 'powershell.exe'
        ArgumentList = $allArgs
        PassThru = $true
    }

    if ($Hidden) {
        $start.WindowStyle = 'Hidden'
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputLog)) {
        Ensure-Directory (Split-Path -Parent $OutputLog)
        Remove-Item -LiteralPath $OutputLog -Force -ErrorAction SilentlyContinue
        $start.RedirectStandardOutput = $OutputLog
    }

    if (-not [string]::IsNullOrWhiteSpace($ErrorLog)) {
        Ensure-Directory (Split-Path -Parent $ErrorLog)
        Remove-Item -LiteralPath $ErrorLog -Force -ErrorAction SilentlyContinue
        $start.RedirectStandardError = $ErrorLog
    }

    return Start-Process @start
}

function Start-ServerLauncher {
    param(
        [string]$LauncherPath
    )

    $working = Split-Path -Parent $LauncherPath
    $command = '"' + $LauncherPath + '"'

    # /c closes the temporary cmd wrapper as soon as Server.bat has handed
    # BOIII off. /k left an empty black command prompt open for every server.
    return Start-Process `
        -FilePath 'cmd.exe' `
        -ArgumentList @('/c', $command) `
        -WorkingDirectory $working `
        -PassThru
}

function Show-ConfigTemplateHelp {
    param([string]$LocalPath)

    Write-Host ''
    Write-Host '[SETUP] Multi-server local configuration is missing.' -ForegroundColor Yellow
    Write-Host ("Created: {0}" -f $LocalPath) -ForegroundColor Gray
    Write-Host 'Edit this .local.json, then relaunch the BAT.' -ForegroundColor Gray
    Write-Host 'Never put an RCON password in the JSON.' -ForegroundColor DarkGray

    try {
        Start-Process notepad.exe -ArgumentList (Quote-Argument $LocalPath)
    }
    catch { }
}

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $PSScriptRoot 'PinteMod_MultiServer.local.json'
}

$examplePath = Join-Path $PSScriptRoot 'PinteMod_MultiServer.example.json'

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    if (-not (Test-Path -LiteralPath $examplePath)) {
        throw "Missing configuration and example file: $ConfigPath"
    }

    Copy-Item -LiteralPath $examplePath -Destination $ConfigPath -Force
    Show-ConfigTemplateHelp -LocalPath $ConfigPath
    exit 2
}

try {
    $config = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop |
        ConvertFrom-Json -ErrorAction Stop
}
catch {
    throw "Invalid multi-server JSON: $ConfigPath"
}

if ($null -eq $config.schema_version -or [int]$config.schema_version -ne 4) {
    throw 'Unsupported multi-server schema. Expected schema_version=4.'
}

if ($null -eq $config.servers -or @($config.servers).Count -lt 1) {
    throw 'No servers are defined in the multi-server configuration.'
}

$liveScript = Join-Path $PSScriptRoot 'PinteMod_LiveConsole.ps1'
$rconScript = Join-Path $PSScriptRoot 'PinteMod_Remote_RCON.ps1'
$workerScript = Join-Path $PSScriptRoot 'PinteMod_MultiServer_Worker.ps1'

foreach ($required in @($liveScript, $rconScript, $workerScript)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "Missing multi-server dependency: $required"
    }
}

$runtimeRoot = Join-Path $PSScriptRoot 'runtime'
$secretsRoot = Join-Path $runtimeRoot 'secrets'
$controllerInstancesRoot = Join-Path $runtimeRoot 'instances'

foreach ($path in @($runtimeRoot, $secretsRoot, $controllerInstancesRoot)) {
    Ensure-Directory $path
}

$seenIds = @{}
$seenRconTargets = @{}
$seenLocalRoots = @{}

$serverIndex = 0
$enabledServers = 0
$serverLaunches = 0
$workersStarted = 0
$liveStarted = 0
$rconStarted = 0
$skippedTools = 0
$configErrors = 0

if (-not $ValidateOnly) {
    $closedStandalone = Stop-AllStandaloneConsoleProcesses
    if ($closedStandalone -gt 0) {
        Write-Host ("[CLEANUP] Closed {0} standalone Live/RCON console process(es)." -f $closedStandalone) -ForegroundColor DarkGray
    }
}

Clear-Host
Write-Host '============================================================' -ForegroundColor DarkCyan
Write-Host ' PinteMod v2.1.1 - Modular Multi-Server Control v0.3' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor DarkCyan
Write-Host (" Config : {0}" -f $ConfigPath) -ForegroundColor DarkGray
if ($ValidateOnly) {
    Write-Host ' Mode   : VALIDATE ONLY' -ForegroundColor DarkGray
}
else {
    Write-Host ' Mode   : LAUNCH' -ForegroundColor DarkGray
}
Write-Host ''

foreach ($server in @($config.servers)) {
    $currentIndex = $serverIndex
    $serverIndex++

    try {
        $enabled = Get-ConfigBool -Value $server.enabled -DefaultValue $true
        if (-not $enabled) {
            Write-Host ("[DISABLED] {0}" -f ([string]$server.id)) -ForegroundColor DarkGray
            continue
        }

        $enabledServers++

        $id = Get-SafeId ([string]$server.id)
        if ($seenIds.ContainsKey($id)) {
            throw "Duplicate server id: $id"
        }
        $seenIds[$id] = $true

        $name = [string]$server.name
        if ([string]::IsNullOrWhiteSpace($name)) {
            $name = $id
        }

        $mode = ([string]$server.mode).Trim().ToLowerInvariant()
        if ($mode -notin @('local', 'remote', 'rcon-only')) {
            throw "Invalid mode '$mode'. Expected local, remote or rcon-only."
        }

        $port = [int]$server.server_port
        if ($port -le 0 -or $port -gt 65535) {
            throw "Invalid UDP/RCON port for ${id}: $port"
        }

        $address = [string]$server.server_address
        if ([string]::IsNullOrWhiteSpace($address) -and $mode -eq 'local') {
            $address = '127.0.0.1'
        }

        $wantLaunchServer = Get-ConfigBool -Value $server.launch_server -DefaultValue $false
        $wantSupervisor = Get-ConfigBool -Value $server.supervisor -DefaultValue $false
        $wantBan = Get-ConfigBool -Value $server.ban_service -DefaultValue $false
        $wantGeo = Get-ConfigBool -Value $server.geoip -DefaultValue $false
        $wantLive = $false # Manager 3K: standalone Live Console retired; integrated Control Center replaces it
        $wantRcon = $false # Manager 3K: standalone Remote RCON retired; integrated Control Center replaces it

        if ($mode -eq 'rcon-only') {
            $wantLaunchServer = $false
            $wantSupervisor = $false
            $wantBan = $false
            $wantGeo = $false
            $wantLive = $false
        }

        if ($mode -ne 'local' -and
            ($wantLaunchServer -or $wantSupervisor -or $wantBan -or $wantGeo)) {
            throw 'Server launch, Supervisor, Ban Service and GeoIP are local-mode features.'
        }

        if ($wantRcon -or $wantGeo) {
            if ([string]::IsNullOrWhiteSpace($address)) {
                throw "Missing server_address for ${id}."
            }
        }

        if ($wantRcon) {
            $target = ("{0}:{1}" -f $address.ToLowerInvariant(), $port)
            if ($seenRconTargets.ContainsKey($target)) {
                throw "Duplicate enabled RCON target: $target"
            }
            $seenRconTargets[$target] = $true
        }

        $background = Get-ConsoleColor `
            -RequestedColor ([string]$server.console_background) `
            -Index $currentIndex

        $foreground = [string]$server.console_foreground
        if ([string]::IsNullOrWhiteSpace($foreground)) {
            $foreground = 'White'
        }

        $showHistory = Get-ConfigBool -Value $server.show_initial_history -DefaultValue $false
        $criticalSound = Get-ConfigBool -Value $server.enable_critical_sound -DefaultValue $false

        $secretGroup = [string]$server.rcon_secret_group
        $secretName = ''
        $secretPath = ''

        if ($wantRcon -or $wantGeo) {
            if ([string]::IsNullOrWhiteSpace($secretGroup)) {
                $secretName = 'server_' + $id
            }
            else {
                $secretName = 'group_' + (Get-SafeId $secretGroup)
            }
            $secretPath = Join-Path $secretsRoot ($secretName + '.secret.txt')
        }

        $serverRoot = ''
        $localDataRoot = ''
        $remoteDataRoot = ''
        $remoteRootValid = $false

        if ($mode -eq 'local') {
            $serverRoot = Resolve-LocalServerRoot -Root ([string]$server.server_root)
            $rootKey = $serverRoot.ToLowerInvariant()
            if ($seenLocalRoots.ContainsKey($rootKey)) {
                throw "Duplicate enabled local server_root: $serverRoot"
            }
            $seenLocalRoots[$rootKey] = $true
            $localDataRoot = Join-Path $serverRoot 'boiii\scriptdata\pintemod'
        }
        elseif ($mode -eq 'remote') {
            $remoteDataRoot = [string]$server.remote_data_root
            $remoteRootValid = Test-RemoteDataRoot $remoteDataRoot
            if ($remoteRootValid) {
                $remoteDataRoot = $remoteDataRoot.Trim('"')
            }
        }

        Write-Host ("[{0}] {1} | {2} | {3}:{4}" -f $id, $name, $mode, $address, $port) -ForegroundColor Gray

        if (-not $ValidateOnly -and $mode -eq 'local') {
            if (Disable-LegacyStandaloneConsoleConfig -ServerRoot $serverRoot) {
                Write-Host '  LEGACY : launch_live_console forced to false in existing local config' -ForegroundColor DarkGray
            }
            Stop-AllStandaloneConsoleProcesses | Out-Null
        }

        if ($wantLaunchServer) {
            $launcherPath = Resolve-ServerLauncher `
                -ServerRoot $serverRoot `
                -RequestedLauncher ([string]$server.server_launcher)

            if ($ValidateOnly) {
                Write-Host ("  SERVER : launcher valid | {0}" -f $launcherPath) -ForegroundColor Green
            }
            elseif (Test-UdpPortBound -Port $port) {
                Write-Host ("  SERVER : already bound on UDP {0}; launch skipped" -f $port) -ForegroundColor Yellow
            }
            else {
                # An already-running worker is expected to survive BOIII loss.
                # It must NOT prevent a later manual server relaunch. The
                # worker will adopt the returning UDP owner and reconcile its
                # owned Ban/GeoIP services.
                Start-ServerLauncher -LauncherPath $launcherPath | Out-Null
                $serverLaunches++
                Write-Host ("  SERVER : launcher started | UDP {0}" -f $port) -ForegroundColor Green
                Start-Sleep -Milliseconds 500
            }
        }

        if (($wantRcon -or $wantGeo) -and -not $ValidateOnly) {
            Ensure-DpapiSecret -Path $secretPath -Label $secretName
        }

        $wantWorker = ($wantSupervisor -or $wantBan -or $wantGeo)

        if (-not $ValidateOnly) {
            if (-not $wantLive) {
                $closedLive = Stop-LegacyStandaloneTool `
                    -ScriptFileName 'PinteMod_LiveConsole.ps1' `
                    -InstanceId $id `
                    -ServerRoot $serverRoot `
                    -ServerPort $port
                if ($closedLive -gt 0) {
                    Write-Host ("  LIVE   : closed {0} legacy standalone process(es)" -f $closedLive) -ForegroundColor DarkGray
                }
            }

            if (-not $wantRcon) {
                $closedRcon = Stop-LegacyStandaloneTool `
                    -ScriptFileName 'PinteMod_Remote_RCON.ps1' `
                    -InstanceId $id `
                    -ServerRoot $serverRoot `
                    -ServerPort $port
                $closedRemoteTools = Stop-LegacyStandaloneTool `
                    -ScriptFileName 'PinteMod_Remote_Tools_Launcher.ps1' `
                    -InstanceId $id `
                    -ServerRoot $serverRoot `
                    -ServerPort $port
                $closedRcon += $closedRemoteTools
                if ($closedRcon -gt 0) {
                    Write-Host ("  RCON   : closed {0} legacy standalone process(es)" -f $closedRcon) -ForegroundColor DarkGray
                }
            }

            if ($wantWorker -and $mode -eq 'local') {
                # Retire the historical mono-server supervisor as well. It can
                # respawn the old visible Live Console and compete for Ban/GeoIP
                # status files. Stopping it does NOT stop BOIII itself; its
                # finally block only stops first-party child tools.
                $closedLegacySupervisor = Stop-LegacyStandaloneTool `
                    -ScriptFileName 'PinteMod_Server_Launcher.ps1' `
                    -InstanceId $id `
                    -ServerRoot $serverRoot `
                    -ServerPort $port
                if ($closedLegacySupervisor -gt 0) {
                    Write-Host ("  SUPERVISOR : retired {0} legacy mono-server controller(s)" -f $closedLegacySupervisor) -ForegroundColor Yellow
                    Start-Sleep -Milliseconds 500
                }
                Stop-AllStandaloneConsoleProcesses | Out-Null

                $retiredWorkers = Stop-ConflictingWorkersForRoot `
                    -ServerRoot $serverRoot `
                    -DesiredInstanceId $id
                if ($retiredWorkers -gt 0) {
                    Write-Host ("  WORKER : retired {0} conflicting first-party worker(s) for this server root" -f $retiredWorkers) -ForegroundColor Yellow
                }
            }
        }

        if ($wantWorker) {
            $workerArgs = @(
                '-InstanceId', (Quote-Argument $id),
                '-DisplayName', (Quote-Argument $name),
                '-ServerRoot', (Quote-Argument $serverRoot),
                '-ServerAddress', (Quote-Argument $address),
                '-ServerPort', [string]$port
            )

            if (-not [string]::IsNullOrWhiteSpace($secretPath)) {
                $workerArgs += @('-SharedSecretPath', (Quote-Argument $secretPath))
            }
            if ($wantBan) {
                $workerArgs += '-LaunchBanService'
            }
            if ($wantGeo) {
                $workerArgs += '-LaunchGeoIP'
            }
            if (-not $wantSupervisor) {
                $workerArgs += '-DisableSupervisorHeartbeat'
            }

            $workerAlreadyActive = $false
            if ($mode -eq 'local' -and -not $ValidateOnly) {
                # The worker's named mutex is authoritative. Do not use the
                # heartbeat as the duplicate gate: its atomic rewrite can
                # create a tiny read race, and a recently stopped worker can
                # leave a fresh heartbeat behind for a few seconds.
                $workerAlreadyActive = Test-WorkerMutexExists -InstanceId $id
            }

            if ($ValidateOnly) {
                $serverTools = Join-Path $serverRoot 'boiii\tools'
                if ($wantBan -and
                    -not (Test-Path -LiteralPath (Join-Path $serverTools 'PinteMod_Ban_Service.ps1') -PathType Leaf)) {
                    throw "Stable Ban Service missing for ${id}."
                }
                if ($wantGeo) {
                    if (-not (Test-Path -LiteralPath (Join-Path $serverTools 'PinteMod_GeoIP_Bridge.ps1') -PathType Leaf)) {
                        throw "Stable GeoIP Bridge missing for ${id}."
                    }
                    if (-not (
                        (Test-Path -LiteralPath (Join-Path $serverTools 'PinteMod_GeoIP_Bridge.local.json') -PathType Leaf) -or
                        (Test-Path -LiteralPath (Join-Path $serverTools 'PinteMod_GeoIP_Bridge.example.json') -PathType Leaf)
                    )) {
                        throw "GeoIP local/example config missing for ${id}."
                    }
                }
                Write-Host '  WORKER : configuration valid' -ForegroundColor Green
            }
            elseif ($workerAlreadyActive) {
                Write-Host '  WORKER : already active for this instance; duplicate start skipped' -ForegroundColor Yellow
            }
            else {
                $instanceRuntime = Join-Path $controllerInstancesRoot $id
                Ensure-Directory $instanceRuntime
                $workerOut = Join-Path $instanceRuntime 'PinteMod_MultiServer_Worker.out.log'
                $workerErr = Join-Path $instanceRuntime 'PinteMod_MultiServer_Worker.error.log'

                Start-PowerShellTool `
                    -ScriptPath $workerScript `
                    -Arguments $workerArgs `
                    -Hidden `
                    -OutputLog $workerOut `
                    -ErrorLog $workerErr | Out-Null

                $workersStarted++
                Write-Host ("  WORKER : started | supervisor={0} ban={1} geoip={2}" -f `
                    $wantSupervisor, $wantBan, $wantGeo) -ForegroundColor Green
                Start-Sleep -Milliseconds 300
            }
        }

        if ($wantLive) {
            try {
                $liveArgs = @(
                    '-InstanceId', (Quote-Argument $id),
                    '-DisplayName', (Quote-Argument $name),
                    '-ServerPort', [string]$port,
                    '-ConsoleBackground', $background,
                    '-ConsoleForeground', $foreground
                )

                if ($showHistory) {
                    $liveArgs += '-ShowInitialHistory'
                }
                if ($criticalSound) {
                    $liveArgs += '-EnableCriticalSound'
                }

                if ($mode -eq 'local') {
                    $liveArgs += @('-ServerRoot', (Quote-Argument $serverRoot))
                }
                elseif ($mode -eq 'remote') {
                    if (-not $remoteRootValid) {
                        throw "Live Console remote data root is invalid/unreachable for ${id}: $remoteDataRoot"
                    }
                    $liveArgs += @('-RemoteDataRoot', (Quote-Argument $remoteDataRoot))
                }
                else {
                    throw 'Live Console is not available in rcon-only mode.'
                }

                if ($ValidateOnly) {
                    Write-Host '  LIVE   : configuration valid' -ForegroundColor Green
                }
                elseif (Test-LiveConsoleMutexExists -InstanceId $id) {
                    Write-Host '  LIVE   : already active for this instance; duplicate start skipped' -ForegroundColor Yellow
                }
                else {
                    Start-PowerShellTool -ScriptPath $liveScript -Arguments $liveArgs | Out-Null
                    $liveStarted++
                    Write-Host '  LIVE   : started' -ForegroundColor Green
                    Start-Sleep -Milliseconds 150
                }
            }
            catch {
                $skippedTools++
                Write-Host ("  LIVE   : skipped | {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            }
        }

        if ($wantRcon) {
            try {
                $rconArgs = @(
                    '-ServerAddress', (Quote-Argument $address),
                    '-ServerPort', [string]$port,
                    '-InstanceId', (Quote-Argument $id),
                    '-DisplayName', (Quote-Argument $name),
                    '-ConsoleBackground', $background,
                    '-ConsoleForeground', $foreground,
                    '-SecretPath', (Quote-Argument $secretPath)
                )

                $feedbackAvailable = $false
                if ($mode -eq 'local' -and
                    (Test-Path -LiteralPath $localDataRoot -PathType Container)) {
                    $rconArgs += @('-RemoteDataRoot', (Quote-Argument $localDataRoot))
                    $feedbackAvailable = $true
                }
                elseif ($mode -eq 'remote' -and $remoteRootValid) {
                    $rconArgs += @('-RemoteDataRoot', (Quote-Argument $remoteDataRoot))
                    $feedbackAvailable = $true
                }

                if (-not $feedbackAvailable) {
                    $rconArgs += '-NoFeedbackLookup'
                }

                if ($ValidateOnly) {
                    Write-Host ("  RCON   : configuration valid | secret={0}" -f $secretName) -ForegroundColor Green
                }
                elseif (Test-RemoteRconMutexExists -InstanceId $id) {
                    Write-Host ("  RCON   : already active for this instance; duplicate start skipped | secret={0}" -f $secretName) -ForegroundColor Yellow
                }
                else {
                    Start-PowerShellTool -ScriptPath $rconScript -Arguments $rconArgs | Out-Null
                    $rconStarted++
                    Write-Host ("  RCON   : started | secret={0}" -f $secretName) -ForegroundColor Green
                    Start-Sleep -Milliseconds 150
                }
            }
            catch {
                $skippedTools++
                Write-Host ("  RCON   : skipped | {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            }
        }
    }
    catch {
        $configErrors++
        Write-Host ("[SERVER ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
        continue
    }
}

Write-Host ''
Write-Host '---------------- SUMMARY ----------------' -ForegroundColor DarkCyan
Write-Host ("Enabled servers : {0}" -f $enabledServers) -ForegroundColor Gray

if ($ValidateOnly) {
    Write-Host ("Config errors    : {0}" -f $configErrors) -ForegroundColor $(if ($configErrors -eq 0) { 'Green' } else { 'Red' })
    Write-Host ("Tool warnings    : {0}" -f $skippedTools) -ForegroundColor $(if ($skippedTools -eq 0) { 'Green' } else { 'Yellow' })

    if ($configErrors -eq 0 -and $skippedTools -eq 0) {
        Write-Host '[PASS] Multi-server configuration is valid.' -ForegroundColor Green
        exit 0
    }

    Write-Host '[WARN] Review the messages above.' -ForegroundColor Yellow
    exit 1
}

Write-Host ("Server launches  : {0}" -f $serverLaunches) -ForegroundColor Gray
Write-Host ("Workers          : {0}" -f $workersStarted) -ForegroundColor Gray
Write-Host ("Live Consoles    : {0}" -f $liveStarted) -ForegroundColor Gray
Write-Host ("RCON Consoles(disabled): {0}" -f $rconStarted) -ForegroundColor Gray
Write-Host ("Skipped tools    : {0}" -f $skippedTools) -ForegroundColor $(if ($skippedTools -eq 0) { 'Green' } else { 'Yellow' })
Write-Host ("Config errors    : {0}" -f $configErrors) -ForegroundColor $(if ($configErrors -eq 0) { 'Green' } else { 'Red' })
Write-Host ''
Write-Host 'DPAPI secrets stay local under boiii\tools\runtime\secrets.' -ForegroundColor DarkGray
Write-Host 'The JSON never stores the RCON password.' -ForegroundColor DarkGray
Write-Host 'Local workers reuse the existing stable GeoIP/Ban logic; only the runtime mutex is isolated per server.' -ForegroundColor DarkGray
Start-Sleep -Seconds 5
