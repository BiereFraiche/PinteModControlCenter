// ============================================================
// PinteMod — Zombie Counter HUD v0.2
// File: ezz_admin_zombie_hud.gsc
//
// Discreet BO3 Zombies-inspired counter:
//   remaining / round total
//
// "remaining" is derived from:
//   living AI + level.zombie_total + level.zombie_respawns
// when those native counters are available.
//
// The round total is the highest reliable remaining count observed for the
// current round. It stays fixed while remaining decreases.
//
// This module is read-only: it does not alter round/spawn state.
// ============================================================

#using scripts\shared\hud_util_shared;


autoexec function init()
{
    level.pintemod_zombie_hud_version = "0.2";
    level.pintemod_zombie_hud_alive = 0;
    level.pintemod_zombie_hud_remaining = 0;
    level.pintemod_zombie_hud_round_total = 0;
    level.pintemod_zombie_hud_round_number = -1;
    level.pintemod_zombie_hud_round_total_lock_at = 0;
    level.pintemod_zombie_hud_queue_known = false;

    level thread zombie_hud_count_monitor();
    level thread zombie_hud_connection_monitor();

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        if (isdefined(players[i]))
            players[i] thread zombie_hud_player_monitor();
    }

    println("^5[PinteMod]^7 Zombie Counter HUD v0.2 loaded");
}


// ------------------------------------------------------------
// Shared count — one GetAIArray pass for the whole server
// ------------------------------------------------------------

function zombie_hud_count_living_ai()
{
    all_ai = GetAIArray();
    alive = 0;

    for (i = 0; i < all_ai.size; i++)
    {
        ai = all_ai[i];

        if (isdefined(ai) && IsAlive(ai))
            alive++;
    }

    return alive;
}


function zombie_hud_count_monitor()
{
    for (;;)
    {
        alive = zombie_hud_count_living_ai();
        remaining = alive;
        queue_known = false;

        if (isdefined(level.zombie_total))
        {
            remaining += level.zombie_total;
            queue_known = true;
        }

        if (isdefined(level.zombie_respawns))
        {
            remaining += level.zombie_respawns;
            queue_known = true;
        }

        if (remaining < alive)
            remaining = alive;

        current_round = -1;

        if (isdefined(level.round_number))
            current_round = level.round_number;

        if (current_round != level.pintemod_zombie_hud_round_number)
        {
            level.pintemod_zombie_hud_round_number = current_round;
            level.pintemod_zombie_hud_round_total = 0;
            level.pintemod_zombie_hud_round_total_lock_at =
                GetTime() + 5000;
        }

        // Native counters can populate just after the round changes. Capture
        // the highest reliable remaining value during a short 5-second settle
        // window, then freeze it as the total for the rest of the round.
        if (current_round > 0 &&
            (GetTime() <= level.pintemod_zombie_hud_round_total_lock_at ||
             level.pintemod_zombie_hud_round_total <= 0) &&
            remaining > level.pintemod_zombie_hud_round_total)
        {
            level.pintemod_zombie_hud_round_total = remaining;
        }

        level.pintemod_zombie_hud_alive = alive;
        level.pintemod_zombie_hud_remaining = remaining;
        level.pintemod_zombie_hud_queue_known = queue_known;

        wait 0.25;
    }
}


// ------------------------------------------------------------
// Player lifecycle
// ------------------------------------------------------------

function zombie_hud_connection_monitor()
{
    for (;;)
    {
        level waittill("connected", player);

        if (isdefined(player))
            player thread zombie_hud_player_monitor();
    }
}


function zombie_hud_create()
{
    if (!isdefined(self))
        return;

    if (isdefined(self.pintemod_zombie_hud_number))
        return;

    // Top-right avoids the chat, menu and native round counter.
    // The large warm number + dark offset shadow gives a Zombies-like feel
    // while using BOIII's validated "default" HUD font.
    self.pintemod_zombie_hud_shadow =
        self hud::createFontString("default", 1.55);
    self.pintemod_zombie_hud_shadow.horzAlign = "right";
    self.pintemod_zombie_hud_shadow.vertAlign = "top";
    self.pintemod_zombie_hud_shadow.alignX = "right";
    self.pintemod_zombie_hud_shadow.alignY = "top";
    self.pintemod_zombie_hud_shadow.x = -27;
    self.pintemod_zombie_hud_shadow.y = 61;
    self.pintemod_zombie_hud_shadow.sort = 995;
    self.pintemod_zombie_hud_shadow.alpha = 0;
    self.pintemod_zombie_hud_shadow.color = (0.05, 0.05, 0.05);
    self.pintemod_zombie_hud_shadow SetText("");

    self.pintemod_zombie_hud_number =
        self hud::createFontString("default", 1.55);
    self.pintemod_zombie_hud_number.horzAlign = "right";
    self.pintemod_zombie_hud_number.vertAlign = "top";
    self.pintemod_zombie_hud_number.alignX = "right";
    self.pintemod_zombie_hud_number.alignY = "top";
    self.pintemod_zombie_hud_number.x = -29;
    self.pintemod_zombie_hud_number.y = 59;
    self.pintemod_zombie_hud_number.sort = 996;
    self.pintemod_zombie_hud_number.alpha = 0;
    self.pintemod_zombie_hud_number.color = (0.92, 0.22, 0.12);
    self.pintemod_zombie_hud_number SetText("");

    self.pintemod_zombie_hud_label =
        self hud::createFontString("default", 1.0);
    self.pintemod_zombie_hud_label.horzAlign = "right";
    self.pintemod_zombie_hud_label.vertAlign = "top";
    self.pintemod_zombie_hud_label.alignX = "right";
    self.pintemod_zombie_hud_label.alignY = "top";
    self.pintemod_zombie_hud_label.x = -29;
    self.pintemod_zombie_hud_label.y = 82;
    self.pintemod_zombie_hud_label.sort = 996;
    self.pintemod_zombie_hud_label.alpha = 0;
    self.pintemod_zombie_hud_label.color = (0.82, 0.82, 0.82);
    self.pintemod_zombie_hud_label SetText("ZOMBIES");
}


function zombie_hud_hide()
{
    if (isdefined(self.pintemod_zombie_hud_shadow))
        self.pintemod_zombie_hud_shadow.alpha = 0;

    if (isdefined(self.pintemod_zombie_hud_number))
        self.pintemod_zombie_hud_number.alpha = 0;

    if (isdefined(self.pintemod_zombie_hud_label))
        self.pintemod_zombie_hud_label.alpha = 0;
}


function zombie_hud_show()
{
    if (isdefined(self.pintemod_zombie_hud_shadow))
        self.pintemod_zombie_hud_shadow.alpha = 0.72;

    if (isdefined(self.pintemod_zombie_hud_number))
        self.pintemod_zombie_hud_number.alpha = 1;

    if (isdefined(self.pintemod_zombie_hud_label))
        self.pintemod_zombie_hud_label.alpha = 0.78;
}


function zombie_hud_player_monitor()
{
    self endon("disconnect");

    if (isdefined(self.pintemod_zombie_hud_thread_started) &&
        self.pintemod_zombie_hud_thread_started)
    {
        return;
    }

    self.pintemod_zombie_hud_thread_started = true;

    wait 1;

    zombie_hud_create();

    last_text = "";

    for (;;)
    {
        hide = false;

        if (isdefined(self.pintemod_menu_open) &&
            self.pintemod_menu_open)
        {
            hide = true;
        }

        if (!isdefined(level.round_number) ||
            level.round_number <= 0)
        {
            hide = true;
        }

        alive = level.pintemod_zombie_hud_alive;
        remaining = level.pintemod_zombie_hud_remaining;
        round_total = level.pintemod_zombie_hud_round_total;

        // Hide between rounds / when the native counters report nothing.
        if (alive <= 0 && remaining <= 0)
            hide = true;

        if (round_total <= 0)
            hide = true;

        if (hide)
        {
            zombie_hud_hide();
            wait 0.25;
            continue;
        }

        // Required display: zombies remaining / total zombies for this round.
        display_text = remaining + " / " + round_total;

        if (display_text != last_text)
        {
            self.pintemod_zombie_hud_shadow SetText(display_text);
            self.pintemod_zombie_hud_number SetText(display_text);
            last_text = display_text;
        }

        zombie_hud_show();

        wait 0.25;
    }
}
