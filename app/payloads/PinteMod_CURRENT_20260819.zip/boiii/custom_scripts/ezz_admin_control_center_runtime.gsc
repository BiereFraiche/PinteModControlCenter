// ============================================================
// PinteMod — Control Center Runtime Bridge v0.1.2
// Fichier : ezz_admin_control_center_runtime.gsc
// Producteur local read-only pour PinteMod Control Center.
// Aucun RCON, aucune commande moteur, aucun affichage joueur.
// ============================================================

#using scripts\shared\laststand_shared;
#using scripts\shared\flag_shared;
#using scripts\zm\_zm_weapons;
#using scripts\zm\_zm_pack_a_punch_util;
#using custom_scripts\ezz_admin_storage;
#using custom_scripts\ezz_admin_identity;

function cc_runtime_heartbeat_path(){ return "pintemod/health/pintemod.json"; }
function cc_runtime_snapshot_path(){ return "pintemod/runtime/control_center_snapshot.json"; }
function cc_runtime_max_players(){ return 4; }
function cc_runtime_max_weapons_per_player(){ return 8; }
function cc_runtime_heartbeat_max_bytes(){ return 4096; }
function cc_runtime_snapshot_max_bytes(){ return 32768; }
function cc_runtime_heartbeat_interval_ms(){ return 5000; }
function cc_runtime_snapshot_interval_ms(){ return 2000; }
function cc_runtime_failure_backoff_ms(){ return 30000; }

function cc_runtime_module_version()
{
    if (isdefined(level.pintemod_core_version) && level.pintemod_core_version != "")
        return "" + level.pintemod_core_version;
    return "2.1.1";
}

function cc_runtime_json_string(json, key_name, default_value)
{
    if (!isdefined(json) || json == "" || jsonvalid(json)) return default_value;
    value = jsonparse(json, key_name);
    if (!isdefined(value) || value == "") return default_value;
    return value;
}

function cc_runtime_json_int(json, key_name, default_value)
{
    value = cc_runtime_json_string(json, key_name, "");
    if (value == "") return default_value;
    return int(value);
}

function cc_runtime_session_started_gettime()
{
    path = "pintemod/logs/current_session.json";
    if (!fileexists(path)) return -1;
    json = readfile(path);
    if (!ezz_admin_storage::storage_json_is_valid(json)) return -1;
    return cc_runtime_json_int(json, "started_gettime", -1);
}

function cc_runtime_session_elapsed_ms()
{
    started = cc_runtime_session_started_gettime();
    if (started < 0) return -1;
    elapsed = GetTime() - started;
    if (elapsed < 0) return -1;
    return elapsed;
}

function cc_runtime_map_code()
{
    map_name = toLower(GetDvarString("mapname"));
    if (!isdefined(map_name) || map_name == "") return "unknown";
    return map_name;
}

function cc_runtime_ranked_status()
{
    if (!isdefined(level.pintemod_ranks_match_ranked)) return "unknown";
    if (level.pintemod_ranks_match_ranked) return "ranked";
    return "unranked";
}

function cc_runtime_power_mode(map_name)
{
    switch (map_name)
    {
        case "zm_prototype":
            return "none";

        case "zm_zod":
            return "local_beast";

        case "zm_island":
            return "dual_generator";

        case "zm_genesis":
            return "corruption";

        case "zm_tomb":
            return "six_generators";

        case "zm_factory":
        case "zm_castle":
        case "zm_stalingrad":
        case "zm_asylum":
        case "zm_sumpf":
        case "zm_theater":
        case "zm_cosmodrome":
        case "zm_temple":
        case "zm_moon":
            return "standard";
    }

    return "unknown";
}

function cc_runtime_pap_mode(map_name)
{
    switch (map_name)
    {
        case "zm_prototype":
        case "zm_asylum":
        case "zm_sumpf":
            return "none";

        case "zm_zod":
            return "rituals";

        case "zm_factory":
            return "three_teleporters";

        case "zm_castle":
            return "map_specific";

        case "zm_island":
            return "machine_parts";

        case "zm_stalingrad":
            return "dragon_access";

        case "zm_genesis":
            return "apothicon_access";

        case "zm_theater":
            return "teleporter";

        case "zm_cosmodrome":
            return "rocket";

        case "zm_temple":
            return "pressure_plates";

        case "zm_moon":
            return "area51";

        case "zm_tomb":
            return "six_generators";
    }

    return "unknown";
}

function cc_runtime_power_state()
{
    mode = cc_runtime_power_mode(cc_runtime_map_code());

    if (mode == "none")
        return "not_applicable";

    // Only BO3's standard global power flag is authoritative here.
    // Map-local and multi-generator systems remain unknown until a
    // dedicated aggregate adapter has been validated.
    if (mode != "standard")
        return "unknown";

    if (!level flag::exists("power_on"))
        return "unknown";

    if (level flag::get("power_on"))
        return "on";

    return "off";
}

function cc_runtime_pap_triggers()
{
    return zm_pap_util::get_triggers();
}

function cc_runtime_pap_powered_count()
{
    triggers = cc_runtime_pap_triggers();
    powered_count = 0;

    for (i = 0; i < triggers.size; i++)
    {
        trigger = triggers[i];

        if (!isdefined(trigger) || !isdefined(trigger.powered))
            continue;

        if (isdefined(trigger.powered.power) && trigger.powered.power)
            powered_count++;
    }

    return powered_count;
}

function cc_runtime_giant_pap_is_unlocked()
{
    if (cc_runtime_map_code() != "zm_factory")
        return true;

    if (!level flag::exists("teleporter_pad_link_3"))
        return false;

    return level flag::get("teleporter_pad_link_3");
}

function cc_runtime_pap_state()
{
    mode = cc_runtime_pap_mode(cc_runtime_map_code());

    if (mode == "none")
        return "not_applicable";

    triggers = cc_runtime_pap_triggers();

    if (!isdefined(triggers) || triggers.size <= 0)
        return "unknown";

    powered = cc_runtime_pap_powered_count();

    if (powered == triggers.size)
    {
        if (!cc_runtime_giant_pap_is_unlocked())
            return "unavailable";

        return "available";
    }

    return "unavailable";
}

function cc_runtime_life_state(player)
{
    if (!isdefined(player)) return "unknown";
    if (isdefined(player.sessionstate) && toLower("" + player.sessionstate) == "spectator") return "spectator";
    if (player laststand::player_is_in_laststand()) return "down";
    if (isdefined(player.health) && player.health > 0) return "alive";
    return "dead";
}

function cc_runtime_weapon_name(weapon)
{
    if (!isdefined(weapon) || weapon == level.weaponNone) return "none";
    if (!isdefined(weapon.name) || weapon.name == "") return "unknown";

    raw_name = "" + weapon.name;
    parts = StrTok(raw_name, "+");

    if (isdefined(parts) && parts.size > 0 && parts[0] != "")
        return parts[0];

    return raw_name;
}

function cc_runtime_weapon_pap_state(weapon)
{
    if (!isdefined(weapon) || weapon == level.weaponNone) return "not_applicable";
    if (zm_weapons::is_weapon_upgraded(weapon)) return "upgraded";
    if (zm_weapons::can_upgrade_weapon(weapon)) return "base";
    return "not_applicable";
}

function cc_runtime_add_known_perks(json, player, prefix)
{
    perks=[]; aliases=[];
    perks[0]="specialty_armorvest"; aliases[0]="jug";
    perks[1]="specialty_quickrevive"; aliases[1]="quick";
    perks[2]="specialty_fastreload"; aliases[2]="speed";
    perks[3]="specialty_doubletap2"; aliases[3]="doubletap";
    perks[4]="specialty_staminup"; aliases[4]="staminup";
    perks[5]="specialty_deadshot"; aliases[5]="deadshot";
    perks[6]="specialty_additionalprimaryweapon"; aliases[6]="mule";
    perks[7]="specialty_electriccherry"; aliases[7]="cherry";
    perks[8]="specialty_widowswine"; aliases[8]="widows";
    count=0;
    for(i=0;i<perks.size;i++)
    {
        if(!player HasPerk(perks[i])) continue;
        count++;
        json=jsonset(json,prefix+"perk_"+count,aliases[i]);
    }
    json=jsonset(json,prefix+"perk_count",""+count);
    return json;
}

function cc_runtime_add_weapons(json, player, prefix)
{
    weapons=player GetWeaponsList(); count=0; truncated=0; max_weapons=cc_runtime_max_weapons_per_player();
    if(!isdefined(weapons))
    {
        json=jsonset(json,prefix+"weapon_count","0");
        json=jsonset(json,prefix+"weapons_truncated","0");
        return json;
    }
    for(i=0;i<weapons.size;i++)
    {
        weapon=weapons[i];
        if(!isdefined(weapon)||weapon==level.weaponNone||!isdefined(weapon.name)||weapon.name=="") continue;
        if(count>=max_weapons){ truncated=1; break; }
        count++; wp=prefix+"weapon_"+count+"_";
        json=jsonset(json,wp+"id",cc_runtime_weapon_name(weapon));
        json=jsonset(json,wp+"pap_state",cc_runtime_weapon_pap_state(weapon));
        json=jsonset(json,wp+"ammo_clip",""+player GetWeaponAmmoClip(weapon));
        json=jsonset(json,wp+"ammo_reserve",""+player GetWeaponAmmoStock(weapon));
    }
    json=jsonset(json,prefix+"weapon_count",""+count);
    json=jsonset(json,prefix+"weapons_truncated",""+truncated);
    return json;
}

function cc_runtime_add_player(json, player, output_index)
{
    prefix="player_"+output_index+"_";
    xuid=ezz_admin_identity::get_player_xuid(player);
    json=jsonset(json,prefix+"xuid",xuid);
    json=jsonset(json,prefix+"display_name",""+player.name);
    json=jsonset(json,prefix+"client_number",""+player GetEntityNumber());
    json=jsonset(json,prefix+"presence","connected");
    json=jsonset(json,prefix+"life_state",cc_runtime_life_state(player));
    god="off"; if(isdefined(player.admin_god)&&player.admin_god) god="on";
    json=jsonset(json,prefix+"godmode_state",god);
    if(isdefined(player.score)) json=jsonset(json,prefix+"points",""+player.score);
    if(isdefined(player.health)) json=jsonset(json,prefix+"health",""+player.health);
    if(isdefined(player.maxhealth)) json=jsonset(json,prefix+"max_health",""+player.maxhealth);
    current=player GetCurrentWeapon();
    json=jsonset(json,prefix+"equipped_weapon",cc_runtime_weapon_name(current));
    json=jsonset(json,prefix+"equipped_weapon_pap_state",cc_runtime_weapon_pap_state(current));
    if(isdefined(current)&&current!=level.weaponNone)
    {
        json=jsonset(json,prefix+"equipped_ammo_clip",""+player GetWeaponAmmoClip(current));
        json=jsonset(json,prefix+"equipped_ammo_reserve",""+player GetWeaponAmmoStock(current));
    }
    json=cc_runtime_add_weapons(json,player,prefix);
    json=cc_runtime_add_known_perks(json,player,prefix);
    return json;
}

function cc_runtime_build_heartbeat()
{
    level.pintemod_cc_heartbeat_sequence++;
    state="running"; error_code="";
    if(isdefined(level.pintemod_cc_last_error_code)&&level.pintemod_cc_last_error_code!="")
    { state="error"; error_code=level.pintemod_cc_last_error_code; }
    json="{}";
    json=jsonset(json,"schema_version","1");
    json=jsonset(json,"module_version",cc_runtime_module_version());
    json=jsonset(json,"session_id",ezz_admin_storage::get_session_id());
    json=jsonset(json,"declared_state",state);
    json=jsonset(json,"last_error_code",error_code);
    json=jsonset(json,"sequence",""+level.pintemod_cc_heartbeat_sequence);
    json=jsonset(json,"generated_gettime",""+GetTime());
    json=jsonset(json,"updated_at_utc","");
    json=jsonset(json,"time_authority","session_gettime_and_file_mtime");
    return json;
}

function cc_runtime_write_heartbeat()
{
    json=cc_runtime_build_heartbeat();
    if(json.size>cc_runtime_heartbeat_max_bytes()) { level.pintemod_cc_last_error_code="HEARTBEAT_SIZE_LIMIT"; return false; }
    if(!ezz_admin_storage::write_json_safe(cc_runtime_heartbeat_path(),json,"control-center-heartbeat"))
    { level.pintemod_cc_last_error_code="HEARTBEAT_WRITE_FAILED"; return false; }
    if(level.pintemod_cc_last_error_code=="HEARTBEAT_WRITE_FAILED") level.pintemod_cc_last_error_code="";
    return true;
}

function cc_runtime_build_snapshot()
{
    level.pintemod_cc_snapshot_sequence++;
    players=GetPlayers(); json="{}";
    json=jsonset(json,"schema_version","1");
    json=jsonset(json,"module_version",cc_runtime_module_version());
    json=jsonset(json,"session_id",ezz_admin_storage::get_session_id());
    json=jsonset(json,"sequence",""+level.pintemod_cc_snapshot_sequence);
    json=jsonset(json,"generated_gettime",""+GetTime());
    json=jsonset(json,"updated_at_utc","");
    json=jsonset(json,"time_authority","session_gettime_and_file_mtime");
    json=jsonset(json,"map_code",cc_runtime_map_code());
    if(isdefined(level.round_number)) json=jsonset(json,"round",""+level.round_number);
    started=cc_runtime_session_started_gettime(); if(started>=0) json=jsonset(json,"session_started_gettime",""+started);
    elapsed=cc_runtime_session_elapsed_ms(); if(elapsed>=0) json=jsonset(json,"session_elapsed_ms",""+elapsed);
    json=jsonset(json,"ranked_status",cc_runtime_ranked_status());
    json=jsonset(json,"power_state",cc_runtime_power_state());
    json=jsonset(json,"pack_a_punch_state",cc_runtime_pap_state());
    json=jsonset(json,"connected_players",""+players.size);
    configured_max=GetDvarInt("sv_maxclients"); if(configured_max>0) json=jsonset(json,"max_players",""+configured_max);
    included=0; invalid_identity=0; truncated_players=0;
    for(i=0;i<players.size;i++)
    {
        player=players[i]; if(!isdefined(player)) continue;
        xuid=ezz_admin_identity::get_player_xuid(player);
        if(!ezz_admin_identity::is_valid_xuid(xuid)){ invalid_identity++; continue; }
        if(included>=cc_runtime_max_players()){ truncated_players=1; continue; }
        included++; json=cc_runtime_add_player(json,player,included);
    }
    json=jsonset(json,"observable_players",""+included);
    json=jsonset(json,"identity_unavailable_players",""+invalid_identity);
    json=jsonset(json,"players_truncated",""+truncated_players);
    return json;
}

function cc_runtime_write_snapshot()
{
    json=cc_runtime_build_snapshot();
    if(json.size>cc_runtime_snapshot_max_bytes()){ level.pintemod_cc_last_error_code="SNAPSHOT_SIZE_LIMIT"; return false; }
    if(!ezz_admin_storage::write_json_safe(cc_runtime_snapshot_path(),json,"control-center-runtime"))
    { level.pintemod_cc_last_error_code="SNAPSHOT_WRITE_FAILED"; return false; }
    if(level.pintemod_cc_last_error_code=="SNAPSHOT_WRITE_FAILED"||level.pintemod_cc_last_error_code=="SNAPSHOT_SIZE_LIMIT") level.pintemod_cc_last_error_code="";
    return true;
}

function cc_runtime_heartbeat_monitor()
{
    wait 2;
    for(;;)
    {
        success=cc_runtime_write_heartbeat();
        if(success) wait cc_runtime_heartbeat_interval_ms()/1000;
        else wait cc_runtime_failure_backoff_ms()/1000;
    }
}

function cc_runtime_snapshot_monitor()
{
    wait 2;
    for(;;)
    {
        success=cc_runtime_write_snapshot();
        if(success) wait cc_runtime_snapshot_interval_ms()/1000;
        else wait cc_runtime_failure_backoff_ms()/1000;
    }
}

autoexec function init()
{
    if(isdefined(level.pintemod_cc_runtime_loaded)&&level.pintemod_cc_runtime_loaded) return;
    level.pintemod_cc_runtime_loaded=true;
    level.pintemod_cc_runtime_version="0.1.0";
    level.pintemod_cc_heartbeat_sequence=0;
    level.pintemod_cc_snapshot_sequence=0;
    level.pintemod_cc_last_error_code="";
    mkdir("pintemod"); mkdir("pintemod/health"); mkdir("pintemod/runtime");
    removefile(cc_runtime_heartbeat_path()); removefile(cc_runtime_heartbeat_path()+".tmp");
    removefile(cc_runtime_snapshot_path()); removefile(cc_runtime_snapshot_path()+".tmp");
    level thread cc_runtime_heartbeat_monitor();
    level thread cc_runtime_snapshot_monitor();
    println("^5[PinteMod]^7 Control Center Runtime v0.1.2 loaded");
}
