@echo off
setlocal
cd /d "%~dp0"
set "CFG=%~dp0START_3_ALL_IN_ONE.local.json"
if not exist "%CFG%" set "CFG=%~dp0PinteMod_MultiServer.local.json"
if not exist "%CFG%" (
  echo [PinteMod RecordHub] Configuration locale introuvable.
  echo Place ce fichier dans le meme dossier que START_3_ALL_IN_ONE.local.json
  echo ou PinteMod_MultiServer.local.json.
  pause
  exit /b 1
)
if not exist "%~dp0PinteMod_RecordHub.ps1" (
  echo [PinteMod RecordHub] PinteMod_RecordHub.ps1 introuvable.
  pause
  exit /b 1
)
start "PinteMod RecordHub" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0PinteMod_RecordHub.ps1" -ConfigPath "%CFG%" -HubRoot "%~dp0PinteModRecordHub" -IntervalSeconds 10
exit /b 0
