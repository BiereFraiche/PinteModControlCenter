@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0PinteModRecordHub" mkdir "%~dp0PinteModRecordHub" >nul 2>&1
>"%~dp0PinteModRecordHub\stop.request" echo stop
 echo [PinteMod RecordHub] Arret demande. Le processus se fermera sous quelques secondes.
timeout /t 3 /nobreak >nul
exit /b 0
