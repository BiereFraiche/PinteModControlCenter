// ============================================================
// PinteMod — Player State / Inventory v0.1
// Fichier : ezz_admin_player_state.gsc
//
// Snapshot lecture seule pour Control Center / outils opérateur.
//
// COMMANDES CONSOLE / RCON
// ------------------------------------------------------------
// ezzplayerstate <PlayerName|BOIII_XUID|ClientNumber>
// ezzplayerstateall
// ezzmapinventory
// ezzplayerstatestatus
//
// Comportement volontairement silencieux :
// - succès : AUCUN println()
// - requête trop rapide : ignorée silencieusement
// - seules les erreurs et ezzplayerstatestatus parlent dans la console
//
// Limitation serveur : 1 snapshot max / joueur / 3 secondes.
// Inventaire global craftables : 1 scan max / 3 secondes.
// Aucun thread de polling permanent.
// ============================================================

#using scripts\shared\laststand_shared;
#using scripts\zm\_zm_equipment;
#using scripts\zm\_zm_weapons;

#using custom_scripts\ezz_admin_identity;
#using custom_scripts\ezz_admin_storage;


// ------------------------------------------------------------
// Configuration / helpers
// ------------------------------------------------------------

function state_min_interval_ms()
{
    if (!isdefined(level.pintemod_player_state_min_interval_ms))
        return 3000;

    value = level.pintemod_player_state_min_interval_ms;

    if (value < 1000)
        value = 1000;

    if (value > 15000)
        value = 15000;

    return value;
}


function state_safe_value(value)
{
    if (!isdefined(value))
        return "unknown";

    text = "" + value;
    result = "";
    max_length = 120;

    if (text.size < max_length)
        max_length = text.size;

    for (i = 0; i < max_length; i++)
    {
        character = GetSubStr(text, i, i + 1);

        if (character == "\n" || character == "\r" ||
            character == "|" || character == "=")
        {
            result = result + "_";
        }
        else
        {
            result = result + character;
        }
    }

    if (result == "")
        return "unknown";

    return result;
}


function state_bool(value)
{
    if (!isdefined(value))
        return 0;

    if (value)
        return 1;

    return 0;
}


function state_weapon_name(weapon)
{
    if (!isdefined(weapon))
        return "none";

    if (weapon == level.weaponNone)
        return "none";

    if (!isdefined(weapon.name))
        return "unknown";

    return state_safe_value(weapon.name);
}


function state_weapon_is_pap(weapon)
{
    if (!isdefined(weapon) || weapon == level.weaponNone)
        return 0;

    if (zm_weapons::is_weapon_upgraded(weapon))
        return 1;

    return 0;
}


function state_string_in_array(values, wanted)
{
    for (i = 0; i < values.size; i++)
    {
        if (values[i] == wanted)
            return true;
    }

    return false;
}


function state_get_target(args)
{
    players = GetPlayers();

    if (args.size > 0)
        return ezz_admin_identity::identity_find_player(args[0]);

    if (players.size == 1)
        return players[0];

    return undefined;
}


function state_snapshot_path(player)
{
    return "pintemod/logs/player_state_client_" +
        player GetEntityNumber() + ".state";
}


function state_map_snapshot_path()
{
    return "pintemod/logs/map_inventory.state";
}


// ------------------------------------------------------------
// Perks
// ------------------------------------------------------------

function state_add_perk_line(output, player, perk, alias, index)
{
    if (!player HasPerk(perk))
        return output;

    output = output +
        "perk_" + index + "=" + alias + "\n";

    return output;
}


function state_append_perks(output, player)
{
    perks = [];
    perks[perks.size] = "specialty_armorvest";
    perks[perks.size] = "specialty_quickrevive";
    perks[perks.size] = "specialty_fastreload";
    perks[perks.size] = "specialty_doubletap2";
    perks[perks.size] = "specialty_staminup";
    perks[perks.size] = "specialty_deadshot";
    perks[perks.size] = "specialty_additionalprimaryweapon";
    perks[perks.size] = "specialty_electriccherry";
    perks[perks.size] = "specialty_widowswine";

    aliases = [];
    aliases[aliases.size] = "jug";
    aliases[aliases.size] = "quick";
    aliases[aliases.size] = "speed";
    aliases[aliases.size] = "doubletap";
    aliases[aliases.size] = "staminup";
    aliases[aliases.size] = "deadshot";
    aliases[aliases.size] = "mule";
    aliases[aliases.size] = "cherry";
    aliases[aliases.size] = "widows";

    count = 0;

    for (i = 0; i < perks.size; i++)
    {
        if (!player HasPerk(perks[i]))
            continue;

        count++;
        output = output +
            "perk_" + count + "=" + aliases[i] + "\n";
    }

    output = output + "perk_count=" + count + "\n";
    return output;
}


// ------------------------------------------------------------
// Weapons / equipment
// ------------------------------------------------------------

function state_append_weapons(output, player)
{
    weapons = player GetWeaponsList();
    count = 0;
    max_weapons = 24;

    if (!isdefined(weapons))
    {
        output = output + "weapon_count=0\n";
        return output;
    }

    for (i = 0; i < weapons.size && count < max_weapons; i++)
    {
        weapon = weapons[i];

        if (!isdefined(weapon) || weapon == level.weaponNone)
            continue;

        if (!isdefined(weapon.name))
            continue;

        count++;

        output = output +
            "weapon_" + count + "=" +
            state_weapon_name(weapon) +
            "|pap=" + state_weapon_is_pap(weapon) + "\n";
    }

    output = output + "weapon_count=" + count + "\n";
    return output;
}


function state_append_equipment(output, player)
{
    equipment = player zm_equipment::get_player_equipment();

    output = output +
        "equipment_current=" + state_weapon_name(equipment) + "\n";

    deployed_count = 0;

    if (isdefined(player.deployed_equipment))
    {
        max_deployed = 8;

        for (i = 0;
            i < player.deployed_equipment.size &&
            deployed_count < max_deployed;
            i++)
        {
            deployed = player.deployed_equipment[i];

            if (!isdefined(deployed) || deployed == level.weaponNone)
                continue;

            deployed_count++;

            output = output +
                "equipment_deployed_" + deployed_count + "=" +
                state_weapon_name(deployed) + "\n";
        }
    }

    output = output +
        "equipment_deployed_count=" + deployed_count + "\n";

    return output;
}


// ------------------------------------------------------------
// Player-carried craftable pieces
// ------------------------------------------------------------

function state_append_carried_pieces(output, player)
{
    carried_count = 0;
    max_slots = 8;

    if (!isdefined(player.current_craftable_pieces))
    {
        output = output + "carried_piece_count=0\n";
        return output;
    }

    slot_count = player.current_craftable_pieces.size;

    if (slot_count > max_slots)
        slot_count = max_slots;

    for (slot = 0; slot < slot_count; slot++)
    {
        piece = player.current_craftable_pieces[slot];

        if (!isdefined(piece))
            continue;

        carried_count++;

        craftable_name = "unknown";
        piece_name = "unknown";

        if (isdefined(piece.craftablename))
            craftable_name = state_safe_value(piece.craftablename);
        else if (isdefined(piece.craftableName))
            craftable_name = state_safe_value(piece.craftableName);

        if (isdefined(piece.pieceName))
            piece_name = state_safe_value(piece.pieceName);

        output = output +
            "carried_piece_" + carried_count + "=" +
            craftable_name +
            "|piece=" + piece_name +
            "|slot=" + slot + "\n";
    }

    output = output +
        "carried_piece_count=" + carried_count + "\n";

    return output;
}


// ------------------------------------------------------------
// Player snapshot
// ------------------------------------------------------------

function state_build_player_snapshot(player)
{
    current_weapon = player GetCurrentWeapon();
    xuid = ezz_admin_identity::get_player_xuid(player);

    session_state = "unknown";

    if (isdefined(player.sessionstate))
        session_state = state_safe_value(player.sessionstate);

    health = 0;
    max_health = 0;
    points = 0;

    if (isdefined(player.health))
        health = player.health;

    if (isdefined(player.maxhealth))
        max_health = player.maxhealth;

    if (isdefined(player.score))
        points = player.score;

    downed = 0;

    if (player laststand::player_is_in_laststand())
        downed = 1;

    godmode = 0;
    ignore = 0;

    if (isdefined(player.admin_god) && player.admin_god)
        godmode = 1;

    if (isdefined(player.admin_ignore) && player.admin_ignore)
        ignore = 1;

    output = "";
    output = output + "PINTEMOD_PLAYER_STATE_V1\n";
    output = output + "generated_gettime=" + GetTime() + "\n";
    output = output + "map=" + state_safe_value(GetDvarString("mapname")) + "\n";
    output = output + "client=" + player GetEntityNumber() + "\n";
    output = output + "xuid=" + state_safe_value(xuid) + "\n";
    output = output + "display=" + state_safe_value(player.name) + "\n";
    output = output + "sessionstate=" + session_state + "\n";
    output = output + "downed=" + downed + "\n";
    output = output + "health=" + health + "\n";
    output = output + "maxhealth=" + max_health + "\n";
    output = output + "points=" + points + "\n";
    output = output +
        "current_weapon=" + state_weapon_name(current_weapon) + "\n";
    output = output +
        "current_weapon_pap=" + state_weapon_is_pap(current_weapon) + "\n";
    output = output + "admin_god=" + godmode + "\n";
    output = output + "admin_ignore=" + ignore + "\n";

    output = state_append_weapons(output, player);
    output = state_append_perks(output, player);
    output = state_append_equipment(output, player);
    output = state_append_carried_pieces(output, player);

    output = output + "END\n";
    return output;
}


function state_capture_player(player)
{
    if (!isdefined(player))
        return false;

    now = GetTime();
    min_interval = state_min_interval_ms();

    if (isdefined(player.pintemod_player_state_last_capture) &&
        now - player.pintemod_player_state_last_capture < min_interval)
    {
        // Intentional silence: Control Center may ask too quickly.
        return false;
    }

    player.pintemod_player_state_last_capture = now;
    snapshot = state_build_player_snapshot(player);

    // Managed per-session file, intentionally NOT community.log:
    // the Live Console does not get spammed by inventory refreshes.
    return ezz_admin_storage::write_managed_log(
        state_snapshot_path(player),
        snapshot
    );
}


// ------------------------------------------------------------
// Global native craftables snapshot
// ------------------------------------------------------------

function state_craftable_is_complete(uts, craftable_spawn, name)
{
    if (isdefined(craftable_spawn.crafted) &&
        craftable_spawn.crafted)
    {
        return 1;
    }

    if (isdefined(uts.crafted) && uts.crafted)
        return 1;

    if (isdefined(level.craftables_crafted) &&
        isdefined(level.craftables_crafted[name]) &&
        level.craftables_crafted[name])
    {
        return 1;
    }

    return 0;
}


function state_piece_state(piece)
{
    if (!isdefined(piece))
        return "unknown";

    if (isdefined(piece.crafted) && piece.crafted)
        return "crafted";

    if (isdefined(piece.is_shared) && piece.is_shared &&
        isdefined(piece.in_shared_inventory) &&
        piece.in_shared_inventory)
    {
        return "shared_inventory";
    }

    if (isdefined(piece.crafting) && piece.crafting)
        return "crafting";

    if (isdefined(piece.is_shared) && piece.is_shared)
        return "world_or_uncollected";

    // A non-shared piece can be in the world OR currently carried by a
    // player; ownership is reported in that player's carried_piece_* lines.
    return "world_or_carried";
}


function state_build_map_inventory_snapshot()
{
    output = "";
    output = output + "PINTEMOD_MAP_INVENTORY_V1\n";
    output = output + "generated_gettime=" + GetTime() + "\n";
    output = output + "map=" +
        state_safe_value(GetDvarString("mapname")) + "\n";

    if (!isdefined(level.a_uts_craftables))
    {
        output = output + "craftable_system=0\n";
        output = output + "craftable_count=0\n";
        output = output + "END\n";
        return output;
    }

    output = output + "craftable_system=1\n";

    seen_names = [];
    craftable_count = 0;
    total_piece_lines = 0;
    max_craftables = 24;
    max_piece_lines = 96;

    for (i = 0;
        i < level.a_uts_craftables.size &&
        craftable_count < max_craftables &&
        total_piece_lines < max_piece_lines;
        i++)
    {
        uts = level.a_uts_craftables[i];

        if (!isdefined(uts) ||
            !isdefined(uts.craftableStub) ||
            !isdefined(uts.craftableStub.name) ||
            !isdefined(uts.craftableSpawn))
        {
            continue;
        }

        name = state_safe_value(uts.craftableStub.name);

        if (name == "open_table")
            continue;

        if (state_string_in_array(seen_names, name))
            continue;

        seen_names[seen_names.size] = name;
        craftable_count++;

        spawn = uts.craftableSpawn;
        complete = state_craftable_is_complete(uts, spawn, name);
        piece_count = 0;
        shared_collected = 0;
        crafted_pieces = 0;

        if (isdefined(spawn.a_pieceSpawns))
        {
            piece_count = spawn.a_pieceSpawns.size;

            for (p = 0;
                p < spawn.a_pieceSpawns.size &&
                total_piece_lines < max_piece_lines;
                p++)
            {
                piece = spawn.a_pieceSpawns[p];

                if (!isdefined(piece))
                    continue;

                if (isdefined(piece.is_shared) && piece.is_shared &&
                    isdefined(piece.in_shared_inventory) &&
                    piece.in_shared_inventory)
                {
                    shared_collected++;
                }

                if (isdefined(piece.crafted) && piece.crafted)
                    crafted_pieces++;
            }
        }

        output = output +
            "craftable_" + craftable_count + "=" + name +
            "|complete=" + complete +
            "|pieces=" + piece_count +
            "|shared_collected=" + shared_collected +
            "|crafted_pieces=" + crafted_pieces + "\n";

        if (!isdefined(spawn.a_pieceSpawns))
            continue;

        local_piece_index = 0;

        for (p = 0;
            p < spawn.a_pieceSpawns.size &&
            total_piece_lines < max_piece_lines;
            p++)
        {
            piece = spawn.a_pieceSpawns[p];

            if (!isdefined(piece))
                continue;

            local_piece_index++;
            total_piece_lines++;

            piece_name = "unknown";

            if (isdefined(piece.pieceName))
                piece_name = state_safe_value(piece.pieceName);

            output = output +
                "craftable_" + craftable_count +
                "_piece_" + local_piece_index + "=" +
                piece_name +
                "|shared=" + state_bool(piece.is_shared) +
                "|state=" + state_piece_state(piece) + "\n";
        }
    }

    output = output + "craftable_count=" + craftable_count + "\n";
    output = output + "piece_line_count=" + total_piece_lines + "\n";
    output = output + "END\n";

    return output;
}


function state_capture_map_inventory()
{
    now = GetTime();
    min_interval = state_min_interval_ms();

    if (isdefined(level.pintemod_map_inventory_last_capture) &&
        now - level.pintemod_map_inventory_last_capture < min_interval)
    {
        return false;
    }

    level.pintemod_map_inventory_last_capture = now;
    snapshot = state_build_map_inventory_snapshot();

    return ezz_admin_storage::write_managed_log(
        state_map_snapshot_path(),
        snapshot
    );
}


// ------------------------------------------------------------
// Commands — silent on success / throttle
// ------------------------------------------------------------

function cmd_ezzplayerstate(args)
{
    player = state_get_target(args);

    if (!isdefined(player))
    {
        if (args.size > 0)
        {
            println(
                "^1[PinteMod PlayerState]^7 Player not found: " +
                args[0]
            );
        }
        else
        {
            println(
                "^3[PinteMod PlayerState]^7 Usage: " +
                "ezzplayerstate <PlayerName|BOIII_XUID|ClientNumber>"
            );
        }

        return;
    }

    state_capture_player(player);
    state_capture_map_inventory();
}


function cmd_ezzplayerstateall(args)
{
    now = GetTime();
    min_interval = state_min_interval_ms();

    if (isdefined(level.pintemod_player_state_last_all_capture) &&
        now - level.pintemod_player_state_last_all_capture < min_interval)
    {
        return;
    }

    level.pintemod_player_state_last_all_capture = now;

    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        if (isdefined(players[i]))
            state_capture_player(players[i]);
    }

    state_capture_map_inventory();
}


function cmd_ezzmapinventory(args)
{
    state_capture_map_inventory();
}


function cmd_ezzplayerstatestatus(args)
{
    println("^5===== PINTEMOD PLAYER STATE v0.1 =====");
    println("^7Mode: on-demand / read-only");
    println(
        "^7Minimum interval: " +
        state_min_interval_ms() + " ms"
    );
    println("^7Success console output: SILENT");
    println("^7Throttled request output: SILENT");
    println("^7Permanent inventory polling thread: NONE");
    println("^7Player file: player_state_client_<n>.state");
    println("^7Map file: map_inventory.state");
    println("^7Native craftables cap: 24 craftables / 96 piece lines");
    println("^5=======================================");
}


autoexec function init()
{
    if (isdefined(level.pintemod_player_state_loaded) &&
        level.pintemod_player_state_loaded)
    {
        return;
    }

    level.pintemod_player_state_loaded = true;
    level.pintemod_player_state_version = "0.1";
    level.pintemod_player_state_min_interval_ms = 3000;

    addcommand("ezzplayerstate", ::cmd_ezzplayerstate);
    addcommand("ezzplayerstateall", ::cmd_ezzplayerstateall);
    addcommand("ezzmapinventory", ::cmd_ezzmapinventory);
    addcommand("ezzplayerstatestatus", ::cmd_ezzplayerstatestatus);

    println("^5[PinteMod]^7 Player State v0.1 loaded");
}
