@echo off
setlocal
title PinteMod - Nettoyage sur Server3
echo.
echo ============================================================
echo  PinteMod - Nettoyage sur Server3
echo ============================================================
echo.
echo Ce BAT commence par un AUDIT. Rien n'est supprime a cette etape.
echo Il refuse l'application si le BOIII de Server3 semble encore actif.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cleanup_PinteMod_Safe.ps1"
if errorlevel 1 (
    echo.
    echo L'audit a echoue. Aucun nettoyage n'a ete applique.
    pause
    exit /b 1
)
echo.
choice /C ON /N /M "Appliquer uniquement ce nettoyage verifie ? [O/N] "
if errorlevel 2 (
    echo.
    echo Annule. Aucun fichier supprime.
    pause
    exit /b 0
)
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Cleanup_PinteMod_Safe.ps1" -Apply
if errorlevel 1 (
    echo.
    echo Le nettoyage a rencontre une erreur.
    pause
    exit /b 1
)
echo.
echo Nettoyage termine.
pause
endlocal
