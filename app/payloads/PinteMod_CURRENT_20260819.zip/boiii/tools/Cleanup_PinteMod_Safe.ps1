param(
    [switch]$Apply
)

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "PinteMod - Nettoyage sur Server3"

function Get-BoiiiRoot {
    $toolsRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
    $boiiiRoot = Split-Path -Parent $toolsRoot

    if (-not (Test-Path -LiteralPath (Join-Path $boiiiRoot "custom_scripts") -PathType Container) -or
        -not (Test-Path -LiteralPath (Join-Path $boiiiRoot "scriptdata") -PathType Container)) {
        throw "Ce script doit rester dans boiii\tools."
    }

    return $boiiiRoot
}

function Test-TreeEquivalent {
    param([string]$SourceRoot, [string]$ArchiveRoot)

    if (-not (Test-Path -LiteralPath $SourceRoot -PathType Container) -or
        -not (Test-Path -LiteralPath $ArchiveRoot -PathType Container)) {
        return $false
    }

    $sourceFiles = @(Get-ChildItem -LiteralPath $SourceRoot -File -Recurse -ErrorAction SilentlyContinue)
    $archiveFiles = @(Get-ChildItem -LiteralPath $ArchiveRoot -File -Recurse -ErrorAction SilentlyContinue)

    if ($sourceFiles.Count -ne $archiveFiles.Count) { return $false }

    foreach ($sourceFile in $sourceFiles) {
        $relativePath = $sourceFile.FullName.Substring($SourceRoot.Length).TrimStart('\')
        $archiveFile = Join-Path $ArchiveRoot $relativePath

        if (-not (Test-Path -LiteralPath $archiveFile -PathType Leaf)) { return $false }

        $archiveItem = Get-Item -LiteralPath $archiveFile -ErrorAction SilentlyContinue
        if (-not $archiveItem -or $archiveItem.Length -ne $sourceFile.Length) { return $false }

        $sourceHash = (Get-FileHash -LiteralPath $sourceFile.FullName -Algorithm SHA256).Hash
        $archiveHash = (Get-FileHash -LiteralPath $archiveFile -Algorithm SHA256).Hash
        if ($sourceHash -ne $archiveHash) { return $false }
    }

    return $true
}

$boiiiRoot = Get-BoiiiRoot
$serverRoot = Split-Path -Parent $boiiiRoot
$logRoot = Join-Path $boiiiRoot "scriptdata\pintemod\logs"
$sessionsRoot = Join-Path $logRoot "sessions"
$archiveRoot = Join-Path $logRoot "archive"
$currentManifest = Join-Path $logRoot "current_session.json"

$currentSessionId = ""
if (Test-Path -LiteralPath $currentManifest -PathType Leaf) {
    try {
        $manifest = Get-Content -LiteralPath $currentManifest -Raw | ConvertFrom-Json -ErrorAction Stop
        $currentSessionId = [string]$manifest.session_id
    }
    catch {
        Write-Host "[WARN] current_session.json illisible : la session active ne sera jamais supprimee par nom." -ForegroundColor Yellow
    }
}

$archiveBySession = @{}
if (Test-Path -LiteralPath $archiveRoot -PathType Container) {
    foreach ($day in @(Get-ChildItem -LiteralPath $archiveRoot -Directory -ErrorAction SilentlyContinue)) {
        foreach ($session in @(Get-ChildItem -LiteralPath $day.FullName -Directory -ErrorAction SilentlyContinue)) {
            if (-not $archiveBySession.ContainsKey($session.Name)) {
                $archiveBySession[$session.Name] = $session.FullName
            }
        }
    }
}

$duplicateSessions = @()
$emptyBootstraps = @()

if (Test-Path -LiteralPath $sessionsRoot -PathType Container) {
    foreach ($session in @(Get-ChildItem -LiteralPath $sessionsRoot -Directory -ErrorAction SilentlyContinue)) {
        if ($session.Name -like "bootstrap_*") {
            $items = @(Get-ChildItem -LiteralPath $session.FullName -Force -ErrorAction SilentlyContinue)
            if ($items.Count -eq 0) {
                $emptyBootstraps += $session.FullName
            }
            continue
        }

        if ($session.Name -eq $currentSessionId) { continue }

        if ($archiveBySession.ContainsKey($session.Name)) {
            $archived = [string]$archiveBySession[$session.Name]
            if (Test-TreeEquivalent -SourceRoot $session.FullName -ArchiveRoot $archived) {
                $duplicateSessions += $session.FullName
            }
        }
    }
}

$legacyChatLog = Join-Path $boiiiRoot "scriptdata\ezz_admin\chat_commands.log"
$currentChatGsc = Join-Path $boiiiRoot "custom_scripts\ezz_admin_chat.gsc"
$legacyChatSafe = $false

if ((Test-Path -LiteralPath $legacyChatLog -PathType Leaf) -and
    (Test-Path -LiteralPath $currentChatGsc -PathType Leaf)) {
    $chatCode = Get-Content -LiteralPath $currentChatGsc -Raw -ErrorAction SilentlyContinue
    if ($chatCode -notmatch 'ezz_admin/chat_commands\.log') {
        $legacyChatSafe = $true
    }
}


$legacyRootCustomScripts = Join-Path $serverRoot "custom_scripts"
$canonicalCustomScripts = Join-Path $boiiiRoot "custom_scripts"
$rootCustomScriptsDuplicate = $false
if ((Test-Path -LiteralPath $legacyRootCustomScripts -PathType Container) -and
    (Test-Path -LiteralPath $canonicalCustomScripts -PathType Container)) {
    $rootCustomScriptsDuplicate = Test-TreeEquivalent -SourceRoot $legacyRootCustomScripts -ArchiveRoot $canonicalCustomScripts
}

$legacyRootGamesettings = Join-Path $serverRoot "gamesettings"
$canonicalGamesettings = Join-Path $boiiiRoot "gamesettings"
$rootGamesettingsDuplicate = $false
if ((Test-Path -LiteralPath $legacyRootGamesettings -PathType Container) -and
    (Test-Path -LiteralPath $canonicalGamesettings -PathType Container)) {
    $rootGamesettingsDuplicate = Test-TreeEquivalent -SourceRoot $legacyRootGamesettings -ArchiveRoot $canonicalGamesettings
}

$runtimeRoot = Join-Path $boiiiRoot "tools\runtime"
$transientRuntimeLogs = @()
if (Test-Path -LiteralPath $runtimeRoot -PathType Container) {
    $transientRuntimeLogs = @(
        Get-ChildItem -LiteralPath $runtimeRoot -File -Filter '*.log' -ErrorAction SilentlyContinue
    )
}

function Get-PinteModToolProcessesForThisRoot {
    param([string]$RootPath)

    $result = @()
    try {
        $escapedRoot = [regex]::Escape([System.IO.Path]::GetFullPath($RootPath))
        $result = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction Stop |
            Where-Object {
                [int]$_.ProcessId -ne $PID -and
                $_.CommandLine -and
                $_.CommandLine -match $escapedRoot -and
                $_.CommandLine -match '(?i)PinteMod_(?:MultiServer_Worker|Ban_Service|GeoIP_Bridge|LiveConsole|Remote_RCON)'
            })
    }
    catch { }
    return $result
}

$serverProcessForThisRoot = $false
try {
    $escapedRoot = [regex]::Escape([System.IO.Path]::GetFullPath($serverRoot))
    $serverProcessForThisRoot = [bool](Get-CimInstance Win32_Process -Filter "Name='boiii.exe'" -ErrorAction Stop |
        Where-Object {
            ([string]$_.ExecutablePath -match $escapedRoot) -or
            ([string]$_.CommandLine -match $escapedRoot)
        } |
        Select-Object -First 1)
}
catch { }

$pinteModToolProcesses = @(Get-PinteModToolProcessesForThisRoot -RootPath $serverRoot)

Write-Host ""
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host " PinteMod - Audit de nettoyage sur" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor DarkCyan
Write-Host ("Dossiers de sessions dupliques et verifies : {0}" -f $duplicateSessions.Count) -ForegroundColor Gray
Write-Host ("Dossiers bootstrap vides                    : {0}" -f $emptyBootstraps.Count) -ForegroundColor Gray
Write-Host ("Ancien log ezz_admin inutilise              : {0}" -f ($(if ($legacyChatSafe) { "OUI" } else { "NON / ABSENT" }))) -ForegroundColor Gray
Write-Host ("Copie racine custom_scripts identique        : {0}" -f ($(if ($rootCustomScriptsDuplicate) { "OUI" } else { "NON / ABSENTE" }))) -ForegroundColor Gray
Write-Host ("Logs runtime transitoires (hors multi)       : {0}" -f $transientRuntimeLogs.Count) -ForegroundColor Gray
Write-Host ("Copie racine gamesettings identique          : {0}" -f ($(if ($rootGamesettingsDuplicate) { "OUI - SIGNALEE SEULEMENT" } else { "NON / ABSENTE" }))) -ForegroundColor Gray
Write-Host ("Outils PinteMod encore attaches a Server3    : {0}" -f $pinteModToolProcesses.Count) -ForegroundColor Gray
if ($serverProcessForThisRoot) {
    Write-Host "[WARN] Un processus BOIII rattache a cette racine semble encore actif." -ForegroundColor Yellow
}
Write-Host ""
Write-Host "PROTEGE : profils Ranks, bans, langues, EE, .bak, secrets DPAPI, health, runtime/multi." -ForegroundColor DarkGray
Write-Host "NOTE : gamesettings racine n'est jamais supprime automatiquement." -ForegroundColor DarkGray

if (-not $Apply) {
    Write-Host ""
    Write-Host "[AUDIT UNIQUEMENT] Aucun fichier n'a ete supprime." -ForegroundColor Yellow
    exit 0
}

if ($serverProcessForThisRoot) {
    throw "Nettoyage refuse : le BOIII de cette racine semble encore actif. Arrete Server3 puis relance le BAT."
}

if ($pinteModToolProcesses.Count -gt 0) {
    Write-Host ''
    Write-Host '[INFO] Arret des outils PinteMod attaches uniquement a cette racine Server3...' -ForegroundColor Yellow
    foreach ($processInfo in $pinteModToolProcesses) {
        try {
            Stop-Process -Id ([int]$processInfo.ProcessId) -Force -ErrorAction Stop
            Write-Host ("  [STOP] PID {0}" -f $processInfo.ProcessId) -ForegroundColor DarkGray
        }
        catch {
            Write-Host ("  [WARN] PID {0} non arrete : {1}" -f $processInfo.ProcessId, $_.Exception.Message) -ForegroundColor Yellow
        }
    }
    Start-Sleep -Seconds 1
}

$removedSessions = 0
$removedBootstraps = 0
$removedLegacy = 0
$removedRootCustomScripts = 0
$removedRuntimeLogs = 0

foreach ($path in $duplicateSessions) {
    try {
        Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop
        $removedSessions++
    }
    catch {
        Write-Host ("[WARN] Impossible de supprimer une session dupliquee : {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}

foreach ($path in $emptyBootstraps) {
    try {
        Remove-Item -LiteralPath $path -Force -ErrorAction Stop
        $removedBootstraps++
    }
    catch {
        Write-Host ("[WARN] Impossible de supprimer un bootstrap vide : {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}

if ($legacyChatSafe) {
    try {
        Remove-Item -LiteralPath $legacyChatLog -Force -ErrorAction Stop
        $legacyRoot = Split-Path -Parent $legacyChatLog
        $remaining = @(Get-ChildItem -LiteralPath $legacyRoot -Force -ErrorAction SilentlyContinue)
        if ($remaining.Count -eq 0) {
            Remove-Item -LiteralPath $legacyRoot -Force -ErrorAction SilentlyContinue
        }
        $removedLegacy = 1
    }
    catch {
        Write-Host ("[WARN] Impossible de supprimer l'ancien log ezz_admin : {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}


if ($rootCustomScriptsDuplicate) {
    try {
        Remove-Item -LiteralPath $legacyRootCustomScripts -Recurse -Force -ErrorAction Stop
        $removedRootCustomScripts = 1
    }
    catch {
        Write-Host ("[WARN] Impossible de supprimer la copie racine custom_scripts : {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}

foreach ($runtimeLog in $transientRuntimeLogs) {
    try {
        Remove-Item -LiteralPath $runtimeLog.FullName -Force -ErrorAction Stop
        $removedRuntimeLogs++
    }
    catch {
        Write-Host ("[WARN] Impossible de supprimer un log runtime : {0}" -f $_.Exception.Message) -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host ("[OK] Sessions dupliquees supprimees : {0}" -f $removedSessions) -ForegroundColor Green
Write-Host ("[OK] Bootstrap vides supprimes        : {0}" -f $removedBootstraps) -ForegroundColor Green
Write-Host ("[OK] Ancien log ezz_admin supprime    : {0}" -f $removedLegacy) -ForegroundColor Green
Write-Host ("[OK] Copie racine custom_scripts retiree: {0}" -f $removedRootCustomScripts) -ForegroundColor Green
Write-Host ("[OK] Logs runtime transitoires supprimes: {0}" -f $removedRuntimeLogs) -ForegroundColor Green
Write-Host ""
Write-Host "Le dossier archive reste intact et la session active n'est jamais supprimee." -ForegroundColor DarkGray
