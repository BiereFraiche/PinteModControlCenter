// ============================================================
// PinteMod — Operator Bridge v0.1
// Fichier : ezz_admin_operator_bridge.gsc
//
// Pont léger vers la Live Console :
// - écoute l'événement commun pintemod_gameplay_command_used
// - écrit une seule ligne structurée dans community.log
// - surveille uniquement l'état PinteMod de la musique, toutes les 2 s,
//   afin de couvrir ezzmusicplayall/ezzmusicstopall sans modifier Music.
//
// Aucun affichage joueur.
// Aucun polling inventaire.
// Aucun spam console sur les événements normaux.
// ============================================================

#using custom_scripts\ezz_admin_storage;


function operator_bridge_safe_text(value)
{
    if (!isdefined(value))
        return "unknown";

    text = "" + value;
    result = "";
    max_length = 96;

    if (text.size < max_length)
        max_length = text.size;

    for (i = 0; i < max_length; i++)
    {
        character = GetSubStr(text, i, i + 1);

        if (character == "\n" || character == "\r" || character == "|")
            result = result + "_";
        else
            result = result + character;
    }

    if (result == "")
        return "unknown";

    return result;
}


function operator_bridge_append(event_text)
{
    return ezz_admin_storage::append_managed_log(
        "pintemod/logs/community.log",
        "[" + GetTime() + "] " + event_text + "\n"
    );
}


function operator_bridge_gameplay_monitor()
{
    for (;;)
    {
        level waittill(
            "pintemod_gameplay_command_used",
            command_name,
            target_name
        );

        command_name = operator_bridge_safe_text(command_name);
        target_name = operator_bridge_safe_text(target_name);

        operator_bridge_append(
            "GAMEPLAY_ACTION" +
            " | command=" + command_name +
            " | target=" + target_name
        );
    }
}


function operator_bridge_get_music_state()
{
    players = GetPlayers();

    for (i = 0; i < players.size; i++)
    {
        player = players[i];

        if (!isdefined(player))
            continue;

        if (!isdefined(player.pintemod_music_state))
            continue;

        return "" + player.pintemod_music_state;
    }

    return "";
}


function operator_bridge_music_monitor()
{
    level.pintemod_operator_bridge_last_music_state = "";

    for (;;)
    {
        wait 2;

        current_state = operator_bridge_get_music_state();

        if (current_state == "")
            continue;

        if (current_state ==
            level.pintemod_operator_bridge_last_music_state)
        {
            continue;
        }

        level.pintemod_operator_bridge_last_music_state = current_state;

        operator_bridge_append(
            "MUSIC_STATE" +
            " | state=" + operator_bridge_safe_text(current_state)
        );
    }
}


function cmd_ezzoperatorbridgestatus(args)
{
    println("^5===== PINTEMOD OPERATOR BRIDGE v0.1 =====");
    println("^7Gameplay event -> community.log: ON");
    println("^7Music state watcher: ON (2s, change-only)");
    println("^7Inventory polling: OFF");
    println("^7Normal event console output: SILENT");
    println("^5=========================================");
}


autoexec function init()
{
    if (isdefined(level.pintemod_operator_bridge_loaded) &&
        level.pintemod_operator_bridge_loaded)
    {
        return;
    }

    level.pintemod_operator_bridge_loaded = true;
    level.pintemod_operator_bridge_version = "0.1";

    addcommand(
        "ezzoperatorbridgestatus",
        ::cmd_ezzoperatorbridgestatus
    );

    level thread operator_bridge_gameplay_monitor();
    level thread operator_bridge_music_monitor();

    println("^5[PinteMod]^7 Operator Bridge v0.1 loaded");
}
